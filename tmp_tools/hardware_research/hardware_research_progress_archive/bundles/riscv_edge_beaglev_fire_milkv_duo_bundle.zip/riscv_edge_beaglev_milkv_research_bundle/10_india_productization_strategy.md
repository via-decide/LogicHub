# 10 — India Productization Strategy

## Best India-facing products

| Rank | Product | Board path | Why |
|---:|---|---|---|
| 1 | Local-first agricultural camera node | Milk-V Duo S | farms, nurseries, warehouses, edge AI |
| 2 | RISC-V education kit | Milk-V Duo + BeagleV-Fire | colleges, labs, training |
| 3 | Industrial sensor gateway | Milk-V Duo S / Module01 | factories need local logging |
| 4 | FPGA deterministic IO trainer | BeagleV-Fire | electronics/FPGA education |
| 5 | Privacy-preserving CCTV prototype | Milk-V Duo S | no-cloud camera value proposition |

## India constraints

- Imports and local sourcing need alternate BOMs.
- Wireless products need applicable India approvals.
- Finished electronics need EMC/safety review.
- Camera products need privacy/security policy.
- Educational kits should expose low-voltage safe interfaces only.
- Avoid mains-connected accessories in first product line.

## Recommended first commercial package

**RISC-V Edge Lab Starter Kit**

Contents:
- Milk-V Duo S or Duo 256M board.
- Optional BeagleV-Fire advanced kit tier.
- pre-flashed microSD.
- UART/USB debug cable.
- safe GPIO breakout.
- camera module for Milk-V tier.
- printed enclosure or acrylic plate.
- 10 lab exercises.
- LogicHub-compatible validation receipts.
- local-first dashboard.

## Pricing model

| Tier | Contents | Revenue model |
|---|---|---|
| Starter | Milk-V board + camera + lessons | hardware margin + course |
| Pro | Starter + BeagleV-Fire | high-margin lab kit |
| Institution | 10–25 kits + workshop | training + support |
| Industry | custom edge gateway | consulting + service |
| LogicHub add-on | source/evidence validation | SaaS/on-prem license |

## Go-to-market

1. Publish ViaDecide teardown article.
2. Make Daxini.space product page.
3. Offer Hanuman.solutions workshop.
4. Use LogicHub.app as source-manifest/evidence demo.
5. Create local-first camera demo video.
6. Build college lab curriculum.
