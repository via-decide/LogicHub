# 04 — Hardware, CAD, BOM, and Manufacturing Intake Plan

## Objective

Build a deterministic source bundle for BeagleV-Fire and Milk-V Duo-family engineering evaluation.

Every accepted file must have:
- source URL
- version/commit/release
- upstream filename
- local filename
- SHA-256
- license status
- use classification
- review status
- fabrication eligibility

## BeagleV-Fire intake checklist

| Asset | Required? | Notes |
|---|---:|---|
| Schematic PDF | Yes | official design repo |
| EDA source files | Yes | exact format depends on upstream repository |
| PCB manufacturing files | Yes if fabricating | hash-only first, review before ordering |
| BOM | Yes | part lifecycle and alternates required |
| Power tree | Yes | SoC rails, sequencing, expansion limits |
| Gateware source/TCL | Yes | must pin Libero/tool versions |
| Bitstreams | If flashing | hash, board revision, provenance |
| Linux image | If booting | hash release and boot logs |
| Mechanical outline | Yes for enclosure/capes | board dimensions, connector keepouts |
| Expansion pinout | Yes | P8/P9, SYZYGY, M.2, CSI, power limits |

## Milk-V Duo intake checklist

| Asset | Required? | Notes |
|---|---:|---|
| Model selection | Yes | Duo 256M / Duo S / Duo Module 01 preferred |
| Schematic PDF | Yes | official hardware files |
| Pinout | Yes | must separate 3.3V/5V/power/ADC/camera pins |
| SoC datasheet | Yes | CV1800B/SG2002/SG2000 as applicable |
| Buildroot SDK | Yes | pin commit and toolchain |
| Example repo | Yes | peripheral smoke-test baseline |
| Boot images | If flashing | hash before use |
| Camera sensor docs | If using vision | sensor pinout, FPC, driver support |
| eMMC/microSD layout | Yes | boot/update/recovery plan |
| Wireless docs | Duo S/Module only | Wi-Fi/BT certification and firmware blobs |

## Source intake commands

```bash
mkdir -p sources/beaglev-fire sources/milkv-duo manifests evidence

# Clone source repos with commit capture
git clone https://github.com/beagleboard/beaglev-fire.git sources/beaglev-fire/github-mirror
git -C sources/beaglev-fire/github-mirror rev-parse HEAD

git clone https://github.com/milkv-duo/duo-buildroot-sdk-v2.git sources/milkv-duo/duo-buildroot-sdk-v2
git -C sources/milkv-duo/duo-buildroot-sdk-v2 rev-parse HEAD

git clone https://github.com/milkv-duo/duo-examples.git sources/milkv-duo/duo-examples
git -C sources/milkv-duo/duo-examples rev-parse HEAD
```

## Manufacturing decision gate

Do not order PCBs, modules, or derivative hardware until:
1. exact board revision is known
2. source files are hashed
3. license status is recorded
4. supplier part status is checked
5. critical rails/power sequencing are reviewed
6. thermal and EMC assumptions are documented
7. factory outputs are regenerated from source where possible
8. design owner and license obligations are visible in BOM notes

## Hardware risk highlights

- BeagleV-Fire FPGA/gateware work depends on Microchip Libero tooling.
- SYZYGY and M.2 high-speed routing is not beginner-safe.
- Milk-V camera and TPU pipelines may depend on vendor SDK layers.
- Original Duo EOL makes it a poor production anchor.
- All camera products need privacy/update/security policy before sale.
