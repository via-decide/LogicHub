# 07 — Validation Plan

## Stage 0 — Source intake validation

- Download official docs, schematics, BOMs, CAD, SDKs, images.
- Record source URL, timestamp, version, and hash.
- Reject unversioned third-party mirrors unless official source is unavailable.
- Separate source files from generated files.

## Stage 1 — Board bring-up

### BeagleV-Fire
- Inspect board revision.
- Capture serial boot log.
- Verify Linux image version.
- Verify eMMC/microSD boot.
- Verify Ethernet.
- Verify USB-C.
- Verify P8/P9 pins with safe low-current tests.
- Verify JTAG access.
- Verify gateware version.
- Read/write known APB register if available.
- Validate thermal profile under CPU + FPGA load.

### Milk-V Duo
- Confirm model: Duo / Duo256M / DuoS / Module01.
- Avoid original Duo for new-product anchor.
- Flash official image.
- Capture UART/SSH boot log.
- Verify architecture mode: RISC-V64 or ARM64 where applicable.
- Run `hello-world`.
- Run GPIO blink.
- Run I2C test.
- Run SPI test.
- Run ADC test.
- Run camera capture where applicable.
- Verify network and update path.

## Stage 2 — Application validation

| Application | Tests |
|---|---|
| Local camera node | boot, frame capture, inference, event publish, storage, restart |
| FPGA IO gateway | gateware version, APB/AXI test, IO loopback, latency test, error injection |
| Sensor gateway | sensor read, calibration, logging, offline mode, power loss |
| Education kit | reproducible lesson scripts, reset image, student-safe electrical limits |

## Stage 3 — Reliability testing

- 100 boot cycles.
- 24h continuous operation.
- Network disconnect/reconnect.
- Power loss during write.
- Thermal soak.
- SD/eMMC corruption recovery.
- Watchdog behavior.
- Update rollback.
- Peripheral disconnect.
- Timestamp/log integrity.
- Tamper-evident enclosure inspection if productized.

## Stage 4 — Evidence receipt

Every successful test should emit:

```json
{
  "project": "riscv-edge-lab",
  "board": "beaglev-fire-or-milkv-duo-s",
  "source_manifest_sha256": "...",
  "image_sha256": "...",
  "test_name": "...",
  "result": "pass",
  "operator": "...",
  "timestamp_utc": "...",
  "artifacts": ["boot.log", "dmesg.txt", "photo.jpg"]
}
```
