#!/usr/bin/env python3
import argparse, csv, hashlib
from pathlib import Path

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser(description="Hash all source files for RISC-V edge intake.")
    ap.add_argument("root", help="Root directory containing downloaded official sources")
    ap.add_argument("--out", default="file_hashes.csv")
    args = ap.parse_args()
    root = Path(args.root)
    rows = [["path","size_bytes","sha256"]]
    for p in sorted(root.rglob("*")):
        if p.is_file():
            rows.append([str(p.relative_to(root)), p.stat().st_size, sha256(p)])
    with open(args.out, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(rows)
    print(f"Wrote {args.out} with {len(rows)-1} files.")

if __name__ == "__main__":
    main()
