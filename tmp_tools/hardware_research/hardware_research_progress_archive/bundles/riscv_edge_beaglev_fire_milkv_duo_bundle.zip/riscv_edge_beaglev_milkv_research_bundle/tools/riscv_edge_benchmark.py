#!/usr/bin/env python3
import json, platform, subprocess, time, hashlib, os
from pathlib import Path

def run(cmd):
    t0 = time.time()
    p = subprocess.run(cmd, shell=True, text=True, capture_output=True)
    return {"cmd": cmd, "returncode": p.returncode, "seconds": time.time()-t0, "stdout": p.stdout[-4000:], "stderr": p.stderr[-4000:]}

def main():
    out = {
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "tests": []
    }
    for cmd in ["uname -a", "cat /proc/cpuinfo | head -80", "cat /proc/meminfo | head -20", "python3 --version"]:
        out["tests"].append(run(cmd))
    Path("riscv_edge_benchmark_receipt.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print("Wrote riscv_edge_benchmark_receipt.json")

if __name__ == "__main__":
    main()
