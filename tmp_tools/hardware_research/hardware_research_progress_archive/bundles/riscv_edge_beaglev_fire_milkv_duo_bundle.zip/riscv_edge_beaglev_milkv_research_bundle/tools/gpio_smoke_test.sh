#!/usr/bin/env bash
set -euo pipefail

# Generic Linux GPIO smoke scaffold.
# Use only on known-safe GPIO pins at correct voltage.
# For Milk-V Duo, prefer adapting official duo-examples blink code.

GPIO_NUM="${1:-}"
if [ -z "$GPIO_NUM" ]; then
  echo "Usage: $0 <linux_gpio_number>"
  exit 1
fi

if [ ! -d /sys/class/gpio/gpio"$GPIO_NUM" ]; then
  echo "$GPIO_NUM" > /sys/class/gpio/export
fi
echo out > /sys/class/gpio/gpio"$GPIO_NUM"/direction
for i in 1 2 3; do
  echo 1 > /sys/class/gpio/gpio"$GPIO_NUM"/value
  sleep 0.5
  echo 0 > /sys/class/gpio/gpio"$GPIO_NUM"/value
  sleep 0.5
done
echo "GPIO $GPIO_NUM smoke test complete."
