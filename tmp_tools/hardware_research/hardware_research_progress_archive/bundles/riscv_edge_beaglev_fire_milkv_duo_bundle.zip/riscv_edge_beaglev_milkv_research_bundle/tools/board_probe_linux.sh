#!/usr/bin/env bash
set -euo pipefail

OUT="${1:-evidence}"
mkdir -p "$OUT"

date -u +"%Y-%m-%dT%H:%M:%SZ" | tee "$OUT/timestamp_utc.txt"
uname -a | tee "$OUT/uname.txt"
cat /proc/cpuinfo | tee "$OUT/cpuinfo.txt" || true
cat /proc/meminfo | tee "$OUT/meminfo.txt" || true
df -h | tee "$OUT/df.txt" || true
ip addr | tee "$OUT/ip_addr.txt" || true
dmesg | tail -n 300 | tee "$OUT/dmesg_tail.txt" || true

echo "Probe complete. Hash the evidence directory before filing a validation receipt."
