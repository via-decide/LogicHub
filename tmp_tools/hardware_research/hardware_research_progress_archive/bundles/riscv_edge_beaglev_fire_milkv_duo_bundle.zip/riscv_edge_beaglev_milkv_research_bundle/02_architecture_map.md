# 02 — Architecture Map

## Two-board edge architecture

```mermaid
flowchart TB
  subgraph MilkV[Milk-V Duo 256M / Duo S / Duo Module 01]
    MLinux[Buildroot Linux]
    MRTOS[RTOS / secondary core path]
    MCamera[MIPI CSI camera]
    MTPU[TPU / CV runtime]
    MGpio[GPIO/I2C/SPI/ADC]
    MApp[Local edge app]
    MCamera --> MTPU --> MApp
    MGpio --> MApp
    MLinux --> MApp
    MRTOS -. optional .-> MApp
  end

  subgraph Beagle[BeagleV-Fire]
    BCPU[RISC-V Linux cores]
    BFPGA[PolarFire FPGA fabric]
    BAPB[APB control/status]
    BAXI[AXI high-throughput path]
    BConn[P8/P9, M.2, SYZYGY, CSI, cape IO]
    BCPU --> BAPB --> BFPGA
    BCPU --> BAXI --> BFPGA
    BFPGA --> BConn
  end

  MApp --> EdgeBus[Local network / MQTT / HTTP / files]
  BCPU --> EdgeBus
  EdgeBus --> Dashboard[Local-first dashboard / validation collector]
  Dashboard --> LogicHub[LogicHub source/evidence graph]
```

## BeagleV-Fire internal control split

```mermaid
flowchart LR
  App[User service] --> Driver[Linux driver]
  Driver --> CSR[APB CSR registers]
  Driver --> DMA[AXI/DMA buffer]
  CSR --> IP[Gateware IP block]
  DMA --> IP
  IP --> IO[External connector]
  IO --> Device[Sensor / motor / industrial interface]
```

Rule: application code should never assume deterministic behavior from Linux userspace. Deterministic timing belongs in FPGA gateware or dedicated hardware.

## Milk-V Duo internal control split

```mermaid
flowchart LR
  Camera[Camera sensor] --> ISP[ISP + video encoder]
  ISP --> CV[CV/TPU runtime]
  SensorBus[I2C/SPI/GPIO/ADC] --> App[Linux edge app]
  CV --> App
  App --> LocalStore[microSD/eMMC]
  App --> Network[USB-NCM/Ethernet/Wi-Fi depending model]
```

Rule: use Milk-V for low-cost camera/sensor products, not hard real-time FPGA-style IO.

## Source authority graph

```mermaid
flowchart TB
  OfficialDocs[Official board docs] --> SourceManifest[source_manifest.csv]
  GitRepos[GitHub/GitLab source repos] --> SourceManifest
  Schematics[Schematics / EDA files] --> Hashes[file_hashes.csv]
  CAD[CAD / STEP / DXF / board outlines] --> Hashes
  SDK[Buildroot SDK / examples / kernels / U-Boot] --> Hashes
  Hashes --> Evidence[validation receipts]
  SourceManifest --> Evidence
  Evidence --> ProductDecision[Go / Change / No-Go]
```
