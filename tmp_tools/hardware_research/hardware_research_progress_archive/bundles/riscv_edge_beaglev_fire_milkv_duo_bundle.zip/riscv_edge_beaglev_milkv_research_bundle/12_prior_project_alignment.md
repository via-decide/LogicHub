# 12 — Prior Project Alignment

## Alignment with generated research bundles so far

| Prior bundle | Linkage to RISC-V edge bundle |
|---|---|
| Air-gapped 8MB storage module | teaches manifest, local state, integrity, and constrained hardware productization |
| Drone CAD implementation bundle | shows embedded sensor/control stack and safety-first validation |
| Pupper V3 research bundle | maps ROS2/high-level robot architecture; RISC-V boards can become edge co-processors |
| FarmBot bundle | agriculture automation target for camera/sensor nodes and deterministic motion validation |
| OpenFlexure bundle | lab instrument control and imaging; Milk-V can be a camera/control node, BeagleV-Fire can be deterministic stage/IO controller |
| SatNOGS bundle | RF/space ground-station edge Linux + signal processing; BeagleV-Fire is useful for FPGA SDR/control experiments |
| Voron bundle | machine-control/thermal/logging; BeagleV-Fire can be deterministic IO gateway, Milk-V can be camera QA monitor |
| OpenEVSE bundle | safety split pattern: UI/API separated from safety-critical controller; apply same principle to edge products |
| OpenMV + OpenIPC bundle | local-first vision appliance path; Milk-V Duo S is a low-cost Linux camera hardware candidate |

## Unified architecture pattern

SOURCE → ENTRY → INTENT → STATE/LOGIC → ACTIONS → OUTPUT/METRICS

For RISC-V edge:

SOURCE:
- BeagleV-Fire docs/repos/gateware.
- Milk-V docs/SDK/examples.
- official schematics, pinouts, images.

ENTRY:
- source manifest.
- board variant.
- image hash.
- gateware hash.
- validation receipt.

INTENT:
- local-first camera node.
- FPGA IO gateway.
- RISC-V education lab.
- edge AI sensor product.

STATE/LOGIC:
- board state.
- boot state.
- peripheral state.
- gateware register state.
- image/update state.

ACTIONS:
- boot, test, capture, infer, publish, control, log, update.

OUTPUT/METRICS:
- boot time.
- inference fps.
- peripheral pass/fail.
- latency.
- power.
- thermal.
- source hash.
- validation decision.

## Brand fit

| Brand | Use |
|---|---|
| LogicHub.app | source/evidence graph for boards, SDKs, gateware, and product claims |
| Daxini OS | local-first runtime for edge devices |
| Daxini.space | education and kit marketplace |
| Viadecide.com | open-source hardware teardown content |
| Hanuman.solutions | integration, validation, and workshops |
| Aporaksha | physical auth and local vision devices after privacy/security design |
