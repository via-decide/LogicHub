# 05 — Firmware and Software Stack Analysis

## BeagleV-Fire stack

```mermaid
flowchart TB
  Boot[Boot ROM / monitor path] --> Firmware[OpenSBI / boot firmware]
  Firmware --> UBoot[U-Boot]
  UBoot --> Linux[Linux kernel + device tree]
  Linux --> Services[userspace services]
  Services --> GatewareAPI[gateware control API]
  GatewareAPI --> APBAXI[APB/AXI interfaces]
  APBAXI --> FPGA[FPGA IP blocks]
```

### Engineering model

- Linux handles non-real-time orchestration, files, network, UI/API, telemetry, and validation logs.
- Gateware handles deterministic hardware interfaces, low-latency capture, protocol adapters, counters, triggers, PWM, encoder capture, and hardware safety interlocks.
- Device tree and gateware must be versioned together.
- Any update that changes FPGA register maps must change the software contract and validation receipt schema.

### Gateware validation layers

| Layer | Test |
|---|---|
| RTL | lint/simulation where possible |
| Libero project | reproducible build notes |
| bitstream | SHA-256, board revision, gateware version |
| register map | APB read/write tests |
| throughput | AXI/DMA test |
| connector | loopback/signal-integrity check |
| Linux integration | device-tree + driver probe + userspace smoke test |

## Milk-V Duo stack

```mermaid
flowchart TB
  BootROM[Boot ROM] --> FSBL[FSBL / vendor boot stage]
  FSBL --> OpenSBI[OpenSBI]
  OpenSBI --> UBoot[U-Boot]
  UBoot --> Kernel[Linux kernel / Buildroot rootfs]
  Kernel --> App[Local app / C/C++ examples]
  Kernel --> Drivers[GPIO/I2C/SPI/ADC/Camera/TPU drivers]
  App --> API[Local HTTP/MQTT/RTSP/CLI]
```

### Engineering model

- Buildroot image is the practical base.
- `duo-examples` gives first smoke tests for Linux C/C++ development.
- For Duo256M/DuoS, target architecture selection matters: ARM64 vs RISCV64.
- Local application should be packaged with versioned rootfs overlay or container-like deployment if available.
- Use USB-NCM or Ethernet for initial transfer and SSH testing.

### Minimum software validation

| Test | Purpose |
|---|---|
| Boot log capture | prove board boots from exact image |
| `uname -a` and `/proc/cpuinfo` | identify architecture/kernel |
| `sha256sum /boot/*` | boot artifact capture |
| GPIO blink | verify user IO |
| I2C scan | verify sensor bus |
| SPI loopback or module test | verify SPI |
| ADC sample | verify analog input |
| camera frame capture | verify ISP/camera path |
| network ping/SSH | verify deployment path |
| service restart | verify resilience |

## Joint local-first runtime path

A useful product stack can combine:

- Milk-V Duo S as local camera/sensor node.
- BeagleV-Fire as deterministic FPGA gateway.
- A local server app for dashboards and evidence storage.
- No cloud dependency for core operation.
- Optional cloud only for update catalog and docs.

```mermaid
sequenceDiagram
  participant Sensor as Sensor/Camera
  participant MilkV as Milk-V edge node
  participant Beagle as BeagleV-Fire FPGA gateway
  participant Host as Local dashboard
  participant LH as LogicHub evidence graph

  Sensor->>MilkV: frame / sensor sample
  MilkV->>Host: event + evidence receipt
  Beagle->>Host: deterministic IO trace
  Host->>LH: source hash + test receipt
  LH->>Host: pass/fail decision
```
