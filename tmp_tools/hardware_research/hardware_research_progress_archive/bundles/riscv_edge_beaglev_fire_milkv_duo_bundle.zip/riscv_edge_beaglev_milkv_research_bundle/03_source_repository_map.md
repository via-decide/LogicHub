# 03 — Source Repository Map

## BeagleV-Fire

| Source | Type | Role | Intake priority |
|---|---|---|---|
| `beagleboard/beaglev-fire` | GitHub mirror / design metadata | README, license, source pointers, board feature summary | High |
| `git.beagleboard.org/beaglev-fire/beaglev-fire` | Official design repo | Hardware design files, schematic, design materials | Critical |
| BeagleV-Fire docs | Documentation | introduction, quick start, design, expansion, demos, support | High |
| BeagleV-Fire gateware docs | Documentation/tutorials | gateware architecture, APB/AXI paths, cape/SYZYGY/M.2/MIPI notes | High |
| BeagleV-Fire software images | binary release | bootable OS images | Medium, hash-only |

## Milk-V Duo family

| Source | Type | Role | Intake priority |
|---|---|---|---|
| `milkv-duo/duo-buildroot-sdk-v2` | SDK | official Buildroot SDK V2 | Critical |
| `milkv-duo/duo-examples` | examples | C/C++ examples for Linux environment on Duo | High |
| Milk-V Duo docs | documentation | product overview, specs, pinouts, startup, SDK docs | High |
| `milkv-duo/duo-files` or official hardware files | hardware/document files | schematics/datasheets/reference files where available | Critical |
| U-Boot board docs | bootloader docs | upstream boot notes for Milk-V Duo | Medium |
| vendor datasheets | SoC docs | CV1800B/SG200x technical details | Critical before product design |

## What must be captured for LogicHub

| Layer | BeagleV-Fire | Milk-V Duo |
|---|---|---|
| Product metadata | board version, commit, docs version | model: Duo/Duo256M/DuoS/Module01, docs version |
| Hardware | schematics, board EDA, BOM, mechanical | schematics, board files, pinout, module/eval docs |
| Boot chain | SPL/OpenSBI/U-Boot/Linux image | FSBL/OpenSBI/U-Boot/Buildroot image |
| Kernel/device tree | Linux kernel, DTB/DTS, modules | Linux kernel 5.10 tree, DTS, driver configs |
| Application | local app, services, scripts | local app, C/C++ examples, sensor services |
| Firmware/FPGA | gateware bitstreams/TCL/RTL | RTOS firmware if used |
| Evidence | boot logs, hash manifest, benchmark receipts | boot logs, peripheral tests, camera/TPU receipts |

## Repository risk notes

- BeagleV-Fire has an explicit open hardware/design story, but FPGA toolchain dependencies can introduce proprietary-tool friction.
- Milk-V Duo SDK may include vendor trees, binaries, and third-party code. Do not treat “GitHub-visible” as automatically clean for commercial reuse.
- Milk-V original Duo/CV1800B is marked EOL by official docs. Use Duo 256M/Duo S for new product planning.
