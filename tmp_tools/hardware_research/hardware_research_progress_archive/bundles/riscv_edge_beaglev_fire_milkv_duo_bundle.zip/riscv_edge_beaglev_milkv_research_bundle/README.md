# BeagleV-Fire / Milk-V Duo RISC-V Edge Research Bundle

Created: 2026-07-30

This bundle is a source-intake and engineering-research package for two RISC-V edge-compute families:

1. **BeagleV-Fire** — RISC-V Linux + FPGA fabric board based on Microchip PolarFire SoC.
2. **Milk-V Duo family** — low-cost RISC-V/ARM-capable AIoT/video edge boards based on CV1800B, SG2002, and SG2000 families.

## What this ZIP is for

Use this to start:
- LogicHub source-intake planning.
- BOM/CAD/EDA manifest creation.
- Edge Linux and RISC-V software architecture research.
- FPGA/gateware vs low-cost AIoT board comparison.
- India productization planning for embedded Linux / edge AI / local-first devices.
- GN8R task generation for deterministic engineering implementation.

## What this ZIP is not

This ZIP does **not** include official board CAD, schematics, firmware images, FPGA bitstreams, vendor SDK tarballs, Linux images, device trees, or binaries.

Those assets must be downloaded directly from official BeagleBoard/Milk-V repositories, pinned by commit/release, hashed, and added to `source_manifest.csv` before fabrication, flashing, resale, or compliance review.

## Best first product direction

- Use **Milk-V Duo 256M / Duo S** for low-cost local camera, sensor, industrial gateway, AIoT, and education prototypes.
- Use **BeagleV-Fire** for serious FPGA/RISC-V, deterministic IO, soft peripherals, custom accelerators, high-speed expansion, and low-latency control research.
- Avoid building a new product around the original **Milk-V Duo CV1800B** because official Milk-V docs say it is EOL and recommend Duo 256M or Duo S.

## Bundle map

- `01_deep_research_report.md` — complete analysis.
- `02_architecture_map.md` — system diagrams and interfaces.
- `03_source_repository_map.md` — repository/source map.
- `04_hardware_cad_bom_intake_plan.md` — asset collection and hashing plan.
- `05_firmware_software_stack_analysis.md` — Linux, SDK, gateware, examples, U-Boot.
- `06_edge_ai_and_fpga_use_cases.md` — monetizable applications.
- `07_validation_plan.md` — bring-up and verification.
- `08_security_reliability_risk_register.csv` — engineering risks.
- `09_license_and_commercialization.md` — licensing and productization constraints.
- `10_india_productization_strategy.md` — India-focused route to market.
- `11_logichub_gn8r_tasks.md` — task blocks.
- `12_prior_project_alignment.md` — alignment with FarmBot, OpenFlexure, SatNOGS, Voron, OpenEVSE, OpenMV/OpenIPC, Pupper, drone, and 8MB module.
- `13_bibliography_and_sources.md` — cited source list.
- `source_manifest.csv` — intake manifest seed.
- `schemas/` — JSON schemas.
- `tools/` — local validation/probe/hash scaffolds.
- `templates/` — BOM, CAD, compliance, benchmark templates.
