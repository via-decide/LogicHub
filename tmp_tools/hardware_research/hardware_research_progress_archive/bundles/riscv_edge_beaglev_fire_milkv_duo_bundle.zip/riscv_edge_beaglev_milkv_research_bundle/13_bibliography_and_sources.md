# 13 — Bibliography and Sources

## beaglev_fire_docs_index
- Title: BeagleV-Fire — BeagleBoard Documentation
- URL: https://docs.beagle.cc/boards/beaglev/fire/index.html
- Evidence used: BeagleV-Fire is powered by Microchip PolarFire MPFS025T RISC-V SoC with FPGA fabric and has P8/P9 cape headers.
- Accessed: 2026-07-30

## beaglev_fire_design_docs
- Title: BeagleV-Fire Design & Specifications
- URL: https://docs.beagleboard.org/boards/beaglev/fire/03-design.html
- Evidence used: Points to hardware design files/schematic in BeagleV-Fire GitLab repository and maps block/power/I2C/connectivity/memory design sections.
- Accessed: 2026-07-30

## beaglev_fire_github
- Title: beagleboard/beaglev-fire README
- URL: https://github.com/beagleboard/beaglev-fire
- Evidence used: Lists SoC, 2GB LPDDR4, 16GB eMMC, Gigabit Ethernet, M.2, USB-C, CSI, SYZYGY, P8/P9, and goals.
- Accessed: 2026-07-30

## beaglev_fire_gateware
- Title: Gateware Design Introduction — BeagleV-Fire
- URL: https://docs.beagleboard.org/boards/beaglev/fire/demos-and-tutorials/gateware/index.html
- Evidence used: Explains PolarFire SoC FPGA gateware, APB/AXI interfaces, cape, SYZYGY, MIPI-CSI, M.2 gateware roles.
- Accessed: 2026-07-30

## beaglev_fire_license
- Title: beagleboard/beaglev-fire LICENSE
- URL: https://github.com/beagleboard/beaglev-fire/blob/main/LICENSE
- Evidence used: CC-BY-4.0 attribution license text, copyright Seeed and BeagleBoard.org Foundation.
- Accessed: 2026-07-30

## milkv_duo_overview
- Title: Milk-V Duo Overview
- URL: https://milkv.io/docs/duo/overview
- Evidence used: Duo, Duo 256M, Duo S, and Duo Module 01 comparison including SoCs, memory, camera, Ethernet, OS support; notes Duo EOL and recommends Duo 256M or Duo S.
- Accessed: 2026-07-30

## milkv_duo_getting_started
- Title: Milk-V Duo Getting Started
- URL: https://milkv.io/docs/duo/getting-started/duo
- Evidence used: CV1800B overview, Linux/RTOS, CV1800B security and imaging features, GPIO mapping.
- Accessed: 2026-07-30

## milkv_duo_buildroot_sdk_v2
- Title: milkv-duo/duo-buildroot-sdk-v2
- URL: https://github.com/milkv-duo/duo-buildroot-sdk-v2
- Evidence used: Official Buildroot SDK V2 with ./build.sh lunch entry point.
- Accessed: 2026-07-30

## milkv_duo_examples
- Title: milkv-duo/duo-examples
- URL: https://github.com/milkv-duo/duo-examples
- Evidence used: C/C++ Linux examples for Duo with target selection for Duo/Duo256M/DuoS and RISC-V/ARM64 target; includes GPIO/I2C/SPI/ADC examples.
- Accessed: 2026-07-30

## u_boot_milkv_duo
- Title: U-Boot Milk-V Duo board docs
- URL: https://docs.u-boot.org/en/v2026.04/board/sophgo/milkv_duo.html
- Evidence used: Upstream U-Boot board documentation for Milk-V Duo / CV1800B.
- Accessed: 2026-07-30
