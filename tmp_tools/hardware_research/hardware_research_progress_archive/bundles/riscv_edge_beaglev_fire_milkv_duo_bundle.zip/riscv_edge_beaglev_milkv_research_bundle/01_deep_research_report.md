# 01 — Deep Research Report: BeagleV-Fire / Milk-V Duo RISC-V Edge Bundle

## Executive summary

This research bundle studies two complementary RISC-V edge-compute paths.

**BeagleV-Fire** is the higher-assurance engineering platform. It combines Linux-capable RISC-V application cores with FPGA fabric on Microchip PolarFire SoC. It is suitable for deterministic IO, hardware/software co-design, FPGA accelerators, education, industrial gateway prototypes, instrumentation, protocol adapters, and low-latency control.

**Milk-V Duo family** is the low-cost edge AI/video/AIoT platform. It is suitable for camera devices, sensor nodes, local-first vision, simple industrial monitoring, video pipelines, smart locks/peepholes/doorbells, and mass-cost exploration. The current product choice should be **Duo 256M or Duo S**, not original Duo CV1800B, because Milk-V documentation states that CV1800B lifecycle ended and original Duo will no longer be produced.

## Strategic conclusion

These boards should not be evaluated as substitutes.

| Axis | BeagleV-Fire | Milk-V Duo 256M / Duo S |
|---|---|---|
| Core value | RISC-V + FPGA fabric | low-cost AIoT/video edge |
| Best role | deterministic hardware/software co-design | camera/sensor/gateway product prototype |
| Main risk | FPGA/gateware toolchain complexity | vendor SDK/licensing/documentation fragmentation |
| Best first commercial experiment | FPGA control/inspection gateway | local-first camera/sensor appliance |
| LogicHub value | validates gateware + schematic + expansion mapping | validates embedded Linux + camera + GPIO + product BOM mapping |
| Build complexity | high | medium-low |
| New product recommendation | good for specialized engineering products | use Duo 256M/Duo S; avoid original Duo CV1800B for new design |

## BeagleV-Fire technical profile

Source-derived facts:
- BeagleV-Fire is powered by Microchip PolarFire MPFS025T SoC.
- The SoC exposes four RV64GC application cores plus one RV64IMAC monitor/boot core with FPGA fabric.
- The board includes P8/P9 cape headers compatible with BeagleBone Black ecosystem.
- Repository README lists 2GB LPDDR4, 16GB eMMC, Gigabit Ethernet, M.2, USB-C, CSI/FFC, SYZYGY high-speed connector, TagConnect JTAG, and additional power connector.
- The project goals include fully open-source SoC development, low-latency control such as manufacturing machines, and long-term availability for education.

Engineering interpretation:
- Treat BeagleV-Fire as a mixed Linux + FPGA verification target.
- Linux userspace should not be assumed to own deterministic real-time behavior.
- Deterministic peripherals should be placed in FPGA gateware and exposed through clean kernel/user interfaces.
- LogicHub ingestion should track hardware design, FPGA gateware, Linux image, kernel/device tree, and application layers separately.

## BeagleV-Fire gateware architecture

Official documentation explains that the PolarFire SoC contains both the RISC-V processor subsystem and FPGA on the same die. Gateware configures the microprocessor subsystem hardware and FPGA digital logic. The useful control split is:

```mermaid
flowchart LR
  Linux[Linux userspace] --> Kernel[Kernel drivers / mmap / sysfs / char devices]
  Kernel --> AXI[AXI high-throughput path]
  Kernel --> APB[APB control/status path]
  APB --> Gateware[FPGA gateware block]
  AXI --> Gateware
  Gateware --> Connector[P8/P9, SYZYGY, M.2, CSI, custom IO]
```

Important architectural facts from official documentation:
- Gateware blocks are clocked/reset by common clock/reset blocks.
- Documentation mentions 125 MHz and 160 MHz clocks for gateware blocks.
- Each block has AMBA APB target interface for software-accessible control/status registers.
- Some blocks have AMBA AXI interfaces for high-volume movement to/from DDR.
- Cape gateware handles P8/P9 connector signals.
- SYZYGY gateware handles high-speed connector signals.
- M.2 gateware implements PCIe interface and consumes transceiver resources.
- MIPI-CSI gateware is documented as work-in-progress.

## Milk-V Duo family technical profile

Source-derived facts:
- Milk-V Duo is an ultra-compact embedded platform based on CV1800B.
- Duo can run Linux and RTOS.
- Duo 256M uses SG2002 and has 256MB memory.
- Duo S uses SG2000 and has 512MB memory, Wi-Fi 6 / Bluetooth 5 support, USB 2.0 host, 100Mbps Ethernet, dual MIPI CSI connectors, and MIPI DSI.
- Duo Module 01 integrates SG2000, Wi-Fi6/BTDM5.4, and eMMC and is intended to reduce product development time.
- Milk-V’s spec table lists C906@1GHz + C906@700MHz RISC-V cores across Duo-family variants.
- Duo 256M and Duo S also list a Cortex-A53@1GHz option and switchable RISC-V/ARM boot modes.
- OS support is listed as Buildroot and RTOS.
- Official docs state original Duo/CV1800B is EOL and recommend Duo 256M or Duo S.

Engineering interpretation:
- Treat original Duo as a learning board.
- Treat Duo 256M / Duo S / Duo Module 01 as the serious productization path.
- Use Duo for local-first vision, data acquisition, low-cost Linux, GPIO/I2C/SPI/ADC peripherals, RTSP/camera/video, and device-agent experiments.
- Do not assume upstream-mainline completeness. Verify SDK, kernel, bootloader, device-tree, security, and binary dependency chain.

## Milk-V Duo SDK/software profile

Source-derived facts:
- `duo-buildroot-sdk-v2` README identifies itself as “Milk-V Duo series buildroot SDK V2” and uses `./build.sh lunch` as its entry point.
- `duo-examples` provides C/C++ examples for Linux environment on Milk-V Duo.
- The example environment supports selection between Duo (CV1800B) and Duo256M/DuoS (SG2002/SG2000).
- For Duo256M/DuoS the examples allow selecting ARM64 or RISCV64 target.
- Examples cover hello-world, GPIO blink, I2C sensors/displays, SPI thermocouple/RFID, and ADC/SARADC.

## Product architecture options

### Product 1 — Local-first camera/sensor node

Use Milk-V Duo S or Duo Module 01.

```mermaid
flowchart LR
  Camera[MIPI camera] --> ISP[ISP / encoder / CV runtime]
  Sensors[I2C/SPI/ADC sensors] --> App[Local edge app]
  App --> Storage[local microSD/eMMC]
  App --> LAN[LAN API / MQTT / RTSP]
  LAN --> Dashboard[local dashboard]
```

Features:
- no-cloud camera processing
- RTSP/local HTTP only
- small on-device event detector
- optional MQTT/Home Assistant
- appliance enclosure and local configuration app

### Product 2 — FPGA deterministic IO gateway

Use BeagleV-Fire.

```mermaid
flowchart LR
  FieldIO[Industrial IO / encoder / sensor bus] --> FPGA[FPGA gateware]
  FPGA --> APB[APB registers]
  FPGA --> AXI[AXI DMA]
  APB --> Linux[Linux control service]
  AXI --> Linux
  Linux --> API[Local API / logs / dashboard]
```

Features:
- custom protocol capture
- deterministic timing
- high-speed IO through SYZYGY or cape headers
- Linux service for control/configuration
- LogicHub-compatible evidence recorder

### Product 3 — RISC-V education lab kit

Use both boards.

Modules:
- Milk-V: low-cost Linux and peripheral programming.
- BeagleV-Fire: FPGA/gateware and SoC verification.
- Open curriculum: GPIO → I2C/SPI → camera → Linux services → FPGA peripheral → APB/AXI → validation receipts.
- Good fit for Daxini.space education kits and ViaDecide technical content.

## Go / Change / No-Go

### Go
- Research bundle, educational content, source intake, validation scripts.
- Milk-V Duo S local-first camera prototype.
- BeagleV-Fire FPGA/gateware training kit.
- LogicHub ingestion of sources, manifests, license records, and evidence.

### Change
- Do not use original Milk-V Duo CV1800B as a new product base.
- Do not claim full openness for all SDK/binary pieces until dependency inventory is complete.
- Do not use BeagleV-Fire if the application only needs cheap Linux GPIO.

### No-Go
- No production sale without supply-chain, license, thermal, EMC, firmware update, security, and enclosure testing.
- No deployment of camera products without privacy, network hardening, and update/rollback model.
- No derivative hardware release until exact official design assets are downloaded, hashed, license-reviewed, and manufacturability-reviewed.

## Recommended next action

Build a **dual-board RISC-V edge lab**:
1. Milk-V Duo S: local camera + GPIO + MQTT/HTTP demo.
2. BeagleV-Fire: simple APB-controlled FPGA register block + Linux control app.
3. Use LogicHub to ingest source manifests and generate validation receipts for both.
