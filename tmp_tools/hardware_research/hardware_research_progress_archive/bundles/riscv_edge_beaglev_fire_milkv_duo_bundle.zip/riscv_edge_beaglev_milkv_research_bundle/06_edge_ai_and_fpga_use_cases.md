# 06 — Edge AI and FPGA Use Cases

## Highest-value product ideas

| Rank | Product | Best board | Why |
|---:|---|---|---|
| 1 | Local-first camera appliance | Milk-V Duo S / Module 01 | camera + ISP + TPU + Linux + low cost |
| 2 | FPGA industrial IO gateway | BeagleV-Fire | deterministic IO + Linux control |
| 3 | Edge vision + actuator controller | both | Milk-V sees; BeagleV-Fire acts deterministically |
| 4 | RISC-V education kit | both | covers Linux, RTOS, FPGA, RISC-V, camera, GPIO |
| 5 | Protocol analyzer/logger | BeagleV-Fire | FPGA capture + Linux storage |
| 6 | Smart agriculture node | Milk-V Duo S | camera, network, low power, local detection |
| 7 | Privacy camera firmware appliance | Milk-V Duo S + OpenIPC lessons | local-only video pipeline |
| 8 | Factory QA camera | Milk-V Duo S | inspection/event detection |
| 9 | Robotics edge co-processor | Milk-V Duo S | local vision and basic AI inference |
| 10 | Low-latency CNC/robot safety monitor | BeagleV-Fire | FPGA interlocks and timing |

## Best first demo

### Demo A — Milk-V Duo S local camera event node
- Boot Buildroot.
- Capture frame.
- Run lightweight detector or motion threshold.
- Publish local MQTT event.
- Store local image evidence.
- Generate JSON validation receipt.

### Demo B — BeagleV-Fire APB register gateware
- Build or use simple gateware block.
- Expose APB register.
- Write Linux userspace probe.
- Toggle output / read counter.
- Generate source + bitstream + register-map evidence receipt.

## Monetization logic

| Market | Product | Revenue |
|---|---|---|
| Education | RISC-V edge lab | kits, courses, support |
| Industrial | deterministic IO gateway | integration, support, service contracts |
| Agriculture | local camera sensor node | hardware kit + analytics |
| Security/privacy | no-cloud camera appliance | appliance sale + update/support |
| Manufacturing | FPGA protocol capture | consulting + tools |
| LogicHub | source intake / validation | SaaS/on-prem tooling |

## What not to sell first

- RISC-V board clones.
- Cameras with cloud claims without security validation.
- FPGA safety controller without formal verification.
- AI camera claiming medical/surveillance accuracy without dataset and compliance evidence.
