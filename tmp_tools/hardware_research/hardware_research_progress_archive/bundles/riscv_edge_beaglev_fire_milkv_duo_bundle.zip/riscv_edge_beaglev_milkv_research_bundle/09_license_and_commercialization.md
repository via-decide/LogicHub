# 09 — License and Commercialization Notes

## BeagleV-Fire

The GitHub mirror has a root license file labelled CC-BY-4.0 and includes copyright notices for Seeed Technology Co., Ltd and BeagleBoard.org Foundation.

Commercial use may still require:
- attribution compliance
- trademark review
- board design terms and conditions review
- supply-chain review
- third-party component license review
- software image license inventory
- FPGA toolchain license review

Do not assume that all gateware/software/binary images are under the same license as board design documentation.

## Milk-V Duo

The Milk-V Duo repos and SDK components need file-level license review. At least these categories must be inventoried:

- Buildroot packages
- Linux kernel tree
- U-Boot / OpenSBI / boot components
- vendor middleware
- ISP/camera stack
- TPU/CV runtime
- FreeRTOS/RTOS components
- examples
- datasheets
- binary blobs
- camera sensor drivers

If a root `LICENSE` file is missing or a repository is a vendor SDK collection, do not infer permissive licensing.

## Productization rule

For resale:
1. Create `license_inventory.csv`.
2. Record every source file tree and binary component.
3. Mark license as permissive, copyleft, proprietary, unknown, or documentation-only.
4. Separate design files from firmware from documentation.
5. Do not ship unknown-license blobs without permission.
6. Do not use BeagleBoard, Milk-V, Microchip, SOPHGO, CVITEK, or other marks in a way that implies endorsement.

## Good commercialization patterns

- Sell education kits and services, not cloned boards.
- Sell integration and validation reports.
- Build local-first edge appliances using officially sourced modules.
- Use carrier boards/enclosures/accessory HATs where licenses allow.
- Publish your own clean docs and source manifests.
