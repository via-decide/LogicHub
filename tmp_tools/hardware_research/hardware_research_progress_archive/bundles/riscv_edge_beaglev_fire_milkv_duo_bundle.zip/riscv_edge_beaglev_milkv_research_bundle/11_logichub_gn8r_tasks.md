# 11 — LogicHub / GN8R Task Blocks

/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 300
version: 1
depends_on: none
task: Build RISC-V board source-intake domain. Support BeagleV-Fire and Milk-V Duo families. Ingest docs, GitHub/GitLab repos, schematics, BOMs, CAD, SDKs, images, device trees, gateware, and examples. Hash all files. Emit board-source manifest.

CAUSATION:
RISC-V edge projects mix hardware, Linux, bootloaders, gateware, SDKs, docs, and binaries. Without deterministic intake, no build or product claim can be trusted.

CONVERGENCE PROOF:
Variables:
$S$ = source set
$H$ = SHA-256 map
$B$ = board identity
$L$ = license inventory
$M$ = source manifest
$Constraint = same(S,B) => same(H,L,M)$

Why naive fails:
- A: Downloads latest docs without version pin.
- B: Mixes binary images with source files.
- C: Treats vendor SDK as one license.
- D: Ignores board revision and device tree.

EPISTEMIC_BOUNDARIES:
Facts:
- BeagleV-Fire uses RISC-V + FPGA fabric.
- Milk-V Duo family uses Buildroot/RTOS path.
- Original Duo CV1800B is EOL per official docs.

EXECUTION_CONTRACT:
Create schemas, source classifiers, hash pipeline, manifest writer, license fields, and tests with fixture repos.


/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 300
version: 1
depends_on: riscv_board_source_intake_v1
task: Build BeagleV-Fire gateware evidence model. Track Libero tool version, RTL/TCL, bitstream hash, APB register map, AXI paths, device tree, Linux probe logs, connector mapping, and validation receipt.

CAUSATION:
FPGA behavior is not visible from Linux source alone. Gateware changes can silently alter IO semantics while software remains unchanged.

CONVERGENCE PROOF:
Variables:
$G$ = gateware source
$T$ = toolchain version
$R$ = register map
$D$ = device tree
$V$ = validation receipt
$Constraint = accepted gateware requires hash(G,T,R,D,V)$

Why naive fails:
- A: Stores bitstream without source.
- B: Updates device tree without register-map proof.
- C: Confuses APB control path with AXI data path.
- D: Ignores connector conflicts.

EPISTEMIC_BOUNDARIES:
Facts:
- BeagleV-Fire gateware blocks expose APB and sometimes AXI.
- SYZYGY/M.2 transceiver sharing must be modeled.

EXECUTION_CONTRACT:
Create entities GatewareProject, RegisterMap, ConnectorClaim, BitstreamArtifact, GatewareValidationReceipt, and tests.


/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 300
version: 1
depends_on: riscv_board_source_intake_v1
task: Build Milk-V Duo edge-Linux validation model. Track board variant, architecture mode, Buildroot SDK commit, image hash, boot log, kernel/device tree, peripheral tests, camera tests, and app receipts.

CAUSATION:
Milk-V Duo variants differ by SoC, RAM, camera IO, network, boot architecture, and lifecycle. One generic “Duo” import creates false product assumptions.

CONVERGENCE PROOF:
Variables:
$V$ = variant
$A$ = architecture mode
$I$ = image
$K$ = kernel/device tree
$P$ = peripheral tests
$Constraint = product claim valid only if hash(V,A,I,K,P)$

Why naive fails:
- A: Uses EOL original Duo for new product.
- B: Mixes ARM64/RISC-V64 binaries.
- C: Skips camera/TPU binary dependency inventory.
- D: Treats SSH success as product readiness.

EPISTEMIC_BOUNDARIES:
Facts:
- Duo 256M/Duo S support selectable ARM/RISC-V modes.
- Duo examples include GPIO, I2C, SPI, ADC tests.

EXECUTION_CONTRACT:
Create variant schema, boot evidence parser, peripheral receipt schema, camera receipt schema, and failure tests.
