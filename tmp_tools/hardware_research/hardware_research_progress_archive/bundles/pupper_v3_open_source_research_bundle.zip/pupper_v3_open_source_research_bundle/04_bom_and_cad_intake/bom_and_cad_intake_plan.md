# BOM and CAD Intake Plan

## Available from current public docs

The docs confirm that Pupper V3 uses off-the-shelf, custom, and 3D printed parts. They also confirm that the official BOM is an external Google Sheet and that CAD is linked externally through Onshape and Fusion 360.

## Not directly included here

- Google Sheet BOM rows.
- Official PCB manufacturing packages.
- Official Onshape CAD model export.
- Official Fusion 360 model archive.
- Official PiOS image.
- Official motor-driver firmware/settings package.
- Official control-board firmware binary/source package.

## Manual artifact intake checklist

| Artifact | Required action | Output to store |
|---|---|---|
| BOM Google Sheet | Export as XLSX and CSV | `sources/bom/pupper_v3_bom.csv` |
| PCB manufacturing ZIPs | Download from BOM-linked files | `sources/pcba/*.zip` |
| Onshape CAD | Export STEP + STL + drawing PDF | `sources/cad/onshape_export/` |
| Fusion 360 CAD | Export F3D/F3Z + STEP | `sources/cad/fusion_export/` |
| PiOS image | Download image and checksum | `sources/os/pupos_image.sha256` |
| Control-board firmware | Download ELF/bin and source if available | `sources/firmware/control_board/` |
| Motor-driver firmware | Download binary/config | `sources/firmware/motor_driver/` |
| Docs static copy | Export ReadTheDocs HTML/PDF | `sources/docs/` |

## LogicHub ingestion schema

```json
{
  "artifact_type": "bom|cad|pcb|firmware|os_image|docs",
  "source_url": "string",
  "local_path": "string",
  "sha256": "string",
  "license": "string_or_unknown",
  "authority_level": "official|mirror|derived|manual",
  "requires_manual_verification": true
}
```
