# Prior Work Integration — Two Projects Already Generated

## 1. Air-gapped 8MB storage module

Generated earlier:

- Research report.
- CAD implementation bundle.
- KiCad schematic and PCB baseline.
- Preliminary Gerbers and drill files.
- STEP/STL/OpenSCAD enclosure references.
- BOM CSV.
- Firmware object-store scaffold.
- Python validation tool.
- Storage protocol.
- EVT/PCBA/DFM/risk documents.

Use with Pupper:

- Offline robot configuration cartridge.
- Tamper-evident build manifest.
- Calibration profile carrier.
- Local behavior/personality pack.
- Service technician token.

## 2. Drone CAD implementation bundle

Generated earlier:

- Flight-controller CAD implementation bundle.
- KiCad schematic and PCB baseline.
- Preliminary Gerber/drill placeholders.
- STM32G4-class pinmux ledger.
- IMU/barometer/flash/USB/SWD/ESC architecture.
- OpenSCAD enclosure/frame/prop-guard/battery-tray CAD.
- Firmware and Python validation scaffolds.
- Bench/tether/PCBA/DFM/risk documents.

Use with Pupper:

- Reuse hardware-validation discipline.
- Reuse IMU and blackbox logging ideas.
- Reuse tethered safety-test thinking.
- Reuse LogicHub hardware revision methods.

## Nested bundles

When available in `/mnt/data`, the previous generated ZIP files have been copied into:

`07_prior_work_integration/previous_generated_bundles/`
