# Next Phase Task Blocks

/task
repo: via-decide/LogicHub
mode: robotics-source-intake-v0.1
tier: T5
estimated_time: 360
version: 1
depends_on: none
task: Build Pupper V3 source intake. Import repo URLs, docs URLs, BOM export, CAD export, firmware files, OS image checksums. Hash every artifact. Emit source_manifest.json.

CAUSATION:
No source intake = no reproducible robot. No reproducible robot = no product evidence.

CONVERGENCE:
Same official sources + same files => same manifest hash. Missing Google/CAD/firmware artifacts must be explicit blockers.

EXECUTION_CONTRACT:
No network mutation. No guessing BOM rows. No claiming official CAD unless exported and hashed.

/task
repo: via-decide/LogicHub
mode: robotics-bom-cad-graph-v0.1
tier: T5
estimated_time: 480
version: 1
depends_on: robotics-source-intake-v0.1
task: Build Pupper BOM-CAD-PCB graph. Link BOM rows to CAD parts, PCB refs, firmware nodes, ROS2 packages, safety constraints, and test evidence.

CAUSATION:
Robot changes cross mechanical, electrical, firmware, and safety domains. File diff alone cannot show impact.

CONVERGENCE:
Every linked object has source path, semantic ID, hash, and confidence class. Unknown mappings stay unknown.

EXECUTION_CONTRACT:
No heuristic edge promoted to direct. No AI risk score. Evidence-backed graph only.

/task
repo: via-decide/LogicHub
mode: robotics-evt-validation-v0.1
tier: T5
estimated_time: 420
version: 1
depends_on: robotics-bom-cad-graph-v0.1
task: Build Pupper EVT validation plan and evidence schema. Cover power, E-stop, battery, motor heat, IMU, camera, controller, ROS2 launch, tether tests, and maintenance checks.

CAUSATION:
Quadruped safety is physical. Passing software launch is not enough.

CONVERGENCE:
No robot revision enters verified state unless every required test emits replayable evidence.

EXECUTION_CONTRACT:
Fail closed on missing E-stop proof, missing battery policy, missing thermal test, or unverified actuator config.
