# Pupper V3 / Stanford Quadruped Open-Source Research Bundle

This bundle converts the Instagram/GitHub lead into an engineering-research package for product planning.

## What is inside

- `01_deep_research_report/PUPPER_V3_DEEP_RESEARCH_REPORT.md` — main technical and commercial research report.
- `02_source_snapshots/` — source-derived summaries from the StanfordQuadruped repository, Pupper V3 monorepo, and official docs.
- `03_architecture_maps/` — robotics architecture, ROS2 graph, hardware stack, and local-first product integration diagrams.
- `04_bom_and_cad_intake/` — BOM/CAD intake notes and the missing-official-artifact checklist.
- `05_build_and_validation/` — build, safety, bring-up, validation, and test plans.
- `06_productization/` — feasibility, IP/licensing, product wedge, pricing and go/no-go roadmap.
- `07_prior_work_integration/` — what was already produced for the air-gapped 8MB module and drone CAD bundle, plus nested copies of previous generated ZIPs when available.
- `08_tasks_for_next_phase/` — compact task blocks for turning this research into LogicHub/GN8R implementation work.
- `09_sources/` — machine-readable source manifest.
- `99_original_context/` — the uploaded Instagram screenshot that initiated the research request.

## Important limitation

This bundle does not claim to contain the official Pupper V3 Onshape/Fusion CAD model, Google-Sheet BOM, or Google-Drive firmware artifacts. The official documentation points to those external resources, but they were not directly downloadable through the available execution environment. This bundle therefore records the source links, source-derived architecture, implementation plan, and intake checklist required to pull those official artifacts manually before fabrication.

## Immediate use

Use this as a planning and productization dossier. Do not order quadruped PCBs, motors, batteries, or mechanical parts from this bundle alone. First complete the CAD/BOM intake checklist, confirm licensing obligations, and run a safety-focused EVT plan.
