# Build and Validation Plan

## EVT build sequence

1. Source official kit or all BOM parts.
2. Hash and archive all downloaded source files.
3. Assemble mechanical frame with official CAD only.
4. Flash motor drivers.
5. Flash control board using ST-Link V2 and STM32CubeProgrammer.
6. Flash Raspberry Pi 5 USB drive with official custom PiOS image.
7. Pair PS5 controller.
8. Boot robot with legs unloaded.
9. Confirm E-stop kills actuator power.
10. Run calibration sequence.
11. Verify IMU stream.
12. Verify camera stream.
13. Verify motor reported position/velocity/effort.
14. Run simulator first, then physical robot.
15. Run low-speed tether test.

## Safety gate checklist

- E-stop tested before any walking policy.
- No exposed pinch point in assembled revision.
- Motors temperature checked after 5, 10, 20, 40 minute runs.
- Battery voltage monitored because docs warn no hardware low-voltage cutoff.
- Legs-off bench test before floor test.
- Floor test inside exclusion zone.
- Child-facing demonstration only after adult-safe checklist.
- No elevated surface operation.

## Test evidence format

```json
{
  "test_id": "PUPPER-EVT-001",
  "revision_id": "sha256-source-manifest",
  "operator": "name",
  "preconditions": [],
  "steps": [],
  "observations": [],
  "pass": false,
  "artifacts": [],
  "blockers": []
}
```
