# Evidence Table

| Claim | Source |
|---|---|
| Screenshot GitHub link points to old StanfordQuadruped repo | Uploaded Instagram screenshot and repo README |
| Old repo has end-of-life notice for Pupper v1 | StanfordQuadruped README |
| Old repo explains joystick/controller/hardware-interface loop | StanfordQuadruped README and `run_robot.py` |
| Pupper V3 software is in `Nate711/pupperv3-monorepo` | Official Pupper V3 modifying-code docs |
| Pupper V3 uses Raspberry Pi 5 8GB, 12 DOF, GIM4305 actuators, BNO086, fisheye camera | Pupper V3 technical specs |
| Pupper V3 code uses ROS2 and neural_controller | Pupper V3 monorepo README and neural_controller README |
| Safety requires E-stop, protected battery, no pinch points, torque limits | Pupper V3 safety docs |
| Official BOM/CAD/firmware artifacts are external links | Pupper V3 sourcing/build/flashing docs |
