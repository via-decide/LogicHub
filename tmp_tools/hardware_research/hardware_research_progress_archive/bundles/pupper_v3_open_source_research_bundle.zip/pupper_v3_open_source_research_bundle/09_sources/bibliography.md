# Sources and References

## Primary project sources

1. StanfordQuadruped GitHub repository — https://github.com/stanfordroboticsclub/StanfordQuadruped
2. Pupper V3 monorepo — https://github.com/Nate711/pupperv3-monorepo
3. Pupper V3 documentation — https://pupper-v3-documentation.readthedocs.io/en/latest/
4. Pupper V3 sourcing parts docs — https://pupper-v3-documentation.readthedocs.io/en/latest/guide/sourcing_parts.html
5. Pupper V3 building docs — https://pupper-v3-documentation.readthedocs.io/en/latest/guide/building.html
6. Pupper V3 OS installation docs — https://pupper-v3-documentation.readthedocs.io/en/latest/guide/software_installation.html
7. Pupper V3 safety docs — https://pupper-v3-documentation.readthedocs.io/en/latest/using_pupper/safety.html
8. Pupper V3 operation docs — https://pupper-v3-documentation.readthedocs.io/en/latest/using_pupper/operation.html
9. Pupper V3 technical specifications — https://pupper-v3-documentation.readthedocs.io/en/latest/learn_more/tech_specs.html
10. Pupper V3 modifying code docs — https://pupper-v3-documentation.readthedocs.io/en/latest/development/modifying_code.html

## Research references

1. Stanford Pupper: A Low-Cost Agile Quadruped Robot for Benchmarking and Education — https://arxiv.org/abs/2110.00736
2. Stanford Doggo: An Open-Source, Quasi-Direct-Drive Quadruped — https://arxiv.org/abs/1905.04254
3. Sim-to-Real: Learning Agile Locomotion For Quadruped Robots — https://arxiv.org/abs/1804.10332
4. Learning Agile Robotic Locomotion Skills by Imitating Animals — https://arxiv.org/abs/2004.00784
5. GNU GPL FAQ — https://www.gnu.org/licenses/gpl-faq.en.html
