# Architecture Maps

## Pupper V3 product architecture

```mermaid
flowchart TD
    User[Human / PS5 Controller / Voice]
    Pi[Raspberry Pi 5 8GB]
    ROS[ROS2 Workspace]
    NC[neural_controller]
    RT[RTNeural Inference]
    RC[ros2_control]
    MD[Motor Drivers]
    ACT[GIM4305 Actuators]
    IMU[BNO086 IMU]
    CAM[IMX296 Fisheye Camera]
    MIC[Microphone]
    LCD[LCD Face]
    SPK[3W Speaker]
    ESTOP[E-Stop]
    BAG[MCAP Bag Recorder]
    FOX[Foxglove Bridge]

    User --> Pi
    Pi --> ROS
    ROS --> NC
    NC --> RT
    NC --> RC
    RC --> MD
    MD --> ACT
    IMU --> NC
    CAM --> ROS
    MIC --> ROS
    ROS --> LCD
    ROS --> SPK
    ESTOP --> MD
    ROS --> BAG
    ROS --> FOX
```

## Source-intake architecture for LogicHub

```mermaid
flowchart TD
    GH1[StanfordQuadruped repo]
    GH2[pupperv3-monorepo]
    DOCS[Pupper V3 docs]
    BOM[Google Sheet BOM]
    CAD[Onshape/Fusion CAD]
    FW[Control/Motor Firmware]
    HASH[Source Hash + Manifest]
    GRAPH[Engineering Graph]
    REVIEW[Safety/Manufacturing Review]
    RELEASE[Verified Build Release]

    GH1 --> HASH
    GH2 --> HASH
    DOCS --> HASH
    BOM --> HASH
    CAD --> HASH
    FW --> HASH
    HASH --> GRAPH
    GRAPH --> REVIEW
    REVIEW --> RELEASE
```

## ROS2 node map extracted from launch.py

```text
robot_state_publisher
controller_manager / ros2_control_node
  ├─ neural_controller
  ├─ neural_controller_three_legged
  ├─ forward_position_controller
  ├─ forward_kp_controller
  ├─ forward_kd_controller
  ├─ joint_state_broadcaster
  └─ imu_sensor_broadcaster
joy_linux_node
teleop_twist_joy -> teleop_cmd_vel
cmd_vel_mux_node
camera_ros/camera_node
foxglove_bridge
bag_recorder_node
imu_to_tf_node
animation_controller_py
joint_state_throttler
hailo_detection
person_follower
```
