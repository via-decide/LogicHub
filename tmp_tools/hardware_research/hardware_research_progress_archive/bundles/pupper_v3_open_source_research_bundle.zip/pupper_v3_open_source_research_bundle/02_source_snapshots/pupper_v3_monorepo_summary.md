# Source Snapshot — Nate711/pupperv3-monorepo

## Repository role

`Nate711/pupperv3-monorepo` is the Pupper V3 public code monorepo referenced by the official Pupper V3 documentation.

## Repository structure observed from GitHub

Top-level folders/files visible in the GitHub page include:

- `.vscode`
- `ai`
- `analysis`
- `bags`
- `infra/pupper_image_builder`
- `pupper-rs`
- `robot`
- `ros2_ws`
- `scripts`
- `CLAUDE.md`
- `LICENSE`
- `README.md`
- `install_dev_dependencies.sh`
- `llm_logs.sh`
- `stop_all_services.sh`

## Source-derived setup facts

- Real robot deployment follows the official Pupper V3 OS installation docs for flashing a Raspberry Pi 5 custom image.
- Simulation/development target is x86 Ubuntu 24.
- The README instructs users to install Git LFS, initialize it, clone with recursive submodules, and run `install_dev_dependencies.sh`.
- The ROS2 workspace is `ros2_ws`, and the build command is `source build.sh` inside that workspace.
- Camera FPS is 10 Hz by default, adjustable through `ros2_ws/src/neural_controller/launch/config.yaml` using `FrameDurationLimits: [100000, 100000]`.
- Animation workflow records MCAP bags, converts them to CSV, copies animations to `animation_controller_py`, rebuilds, and updates configuration.
- Camera/vision development includes a mock camera/detection launch and Foxglove bridge.

## Neural controller facts

The neural controller README states that the package aims to ease neural-network policy deployment on robot hardware. It runs inside the `ros2_control` framework and uses RTNeural for real-time inference. It also explicitly warns that common neural-network libraries such as Torch are not designed for real-time control loops because latency and jitter hurt sim-to-real transfer.

## ROS2 launch-map facts

The `neural_controller/launch/launch.py` launch file declares `sim`, `teleop`, and `bag_recorder` arguments, selects the appropriate xacro URDF, starts `robot_state_publisher`, `ros2_control_node`, controller spawners, joint-state and IMU broadcasters, Foxglove bridge, joystick input, teleop twist, camera node for non-simulation, command velocity mux, bag recorder, IMU transform node, animation controller, joint-state throttler, Hailo detection, and person-following nodes.

## License implication

The monorepo contains a GPL-3.0 license. A closed commercial derivative must be designed carefully. You can learn from it and use it internally, but distributing modified GPL-covered software or derivative software generally triggers source-code/license obligations. Get legal review before using repo code inside a sold product.
