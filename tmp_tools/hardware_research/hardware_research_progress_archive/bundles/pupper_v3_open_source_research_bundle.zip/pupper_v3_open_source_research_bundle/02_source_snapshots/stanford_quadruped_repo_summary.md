# Source Snapshot — stanfordroboticsclub/StanfordQuadruped

## Repository role

The Instagram screenshot points to `https://github.com/stanfordroboticsclub/StanfordQuadruped`. That repository is the older Stanford Pupper / Woofer repository.

## Source-derived facts

- The README contains an end-of-life notice for the older Pupper v1 project and says support is stopping while the team works on Pupper v3.
- The README still gives a useful control architecture for the earlier Raspberry Pi quadruped stack.
- The repository hosted Python code for Stanford Pupper and Stanford Woofer, described as Raspberry-Pi-based quadrupeds that can trot, walk, and jump.
- The main old runtime entry point is `run_robot.py`.
- The old code loop constructs configuration, hardware interface, controller, state, joystick interface, optional IMU, then waits for L1 activation before stepping the controller and writing actuator positions.
- The old README explains a three-part runtime: joystick interface, controller, and hardware interface.
- The old controller architecture uses a gait scheduler, stance controller, swing controller, and inverse kinematics model.

## Relevance to current product planning

The old repository is not the correct final Pupper V3 source authority. It is still valuable because it shows the educational control architecture: command ingestion → gait planning → swing/stance update → inverse kinematics → hardware interface.

## Product implication

Treat this as a historical design reference, not as the production Pupper V3 implementation. For a commercial derivative, use the Pupper V3 monorepo and current docs as the main source, then validate licensing and official BOM/CAD artifacts.
