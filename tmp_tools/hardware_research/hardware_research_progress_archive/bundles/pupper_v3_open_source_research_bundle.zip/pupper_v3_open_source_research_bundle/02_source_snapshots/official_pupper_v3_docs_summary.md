# Source Snapshot — Official Pupper V3 Documentation

## Product identity

The official documentation describes Pupper V3 as an open-source companion robot designed to teach robotics and AI. It says Pupper can be built for about $2000.

## Hardware specifications from official docs

- 12 degrees of freedom, 3 per leg.
- 3 kg weight.
- Crouched dimensions: 25 cm length, 20 cm height, 22 cm width.
- Raspberry Pi 5 8 GB compute.
- M.2 slot available for an AI accelerator.
- Steadywin GIM4305 actuators with 4005 brushless motor, 10:1 planetary gearbox, about 3.5 Nm peak torque, about 1.0 Nm continuous torque with air cooling, and about 30 rad/s max speed.
- 9 g servo motors for ears.
- BNO086 6DOF IMU.
- IMX296 222° FOV fisheye camera in the nose.
- Microphone for voice interaction.
- Motor drivers report actuator angles, velocities, and efforts.
- Battery voltage ADC.
- 4 in × 4 in LCD for expressive face/debugging.
- 3 W speaker behind the nose.

## Sourcing and assembly facts

- Pupper uses off-the-shelf, custom, and 3D printed components.
- The official BOM is linked externally as a Google Sheet.
- The docs list kit suppliers, including Present Perfection and AIFitLab.
- The docs say the two custom PCBs are tricky to order directly and require downloading manufacturing files from BOM links.
- The docs specifically mention using JLCPCB global sourcing for the BNO086 IMU.
- Electronics preparation includes flashing motor drivers and flashing the control board.
- Control board flashing uses ST-Link V2 and STM32CubeProgrammer.
- Mechanical preparation includes heat-set threaded inserts at 250°C, gluing squash balls to lower legs, and changing/focusing the camera lens.
- CAD links are external: Onshape and Fusion 360.

## OS and operation facts

- Materials include Raspberry Pi 5 and a USB drive.
- The setup uses Raspberry Pi Imager and a custom full PiOS image.
- First setup includes SSH and PS5 controller pairing.
- Running the robot requires inserting a DeWalt battery and powering on through the rear switch.
- The robot calibrates legs against endstops and then moves into rest.
- Default robot activation uses PS controller/e-stop release.
- The operation docs explicitly warn that the robot does not have a hardware low-voltage cutoff and should not be run longer than 40 minutes without checking the battery.

## Safety facts

- Safety features include no exposed pinch points or sharp edges, protected battery, torque-limited/compliant joints, accessible E-stop on the back, and small/lightweight design.
- Human safety advisories include not touching the robot while moving, operating on suitable surfaces, avoiding hot motors, and supervising children.
- Robot safety advisories include lifting only by the handle and avoiding extended exertion that can overheat motors.
- Emergency shutdown is by pressing the E-stop switch on the backpack.

## Missing from environment

The docs point to BOM, PCBA manufacturing files, Onshape, Fusion 360, and Google Drive firmware artifacts. These were not directly retrieved into the bundle. A fabrication workflow must manually export and verify them.
