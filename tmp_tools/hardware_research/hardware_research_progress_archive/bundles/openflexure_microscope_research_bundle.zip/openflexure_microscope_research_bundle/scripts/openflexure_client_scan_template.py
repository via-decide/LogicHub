"""
OpenFlexure microscope validation receipt scaffold.

This script is a template. It requires a real microscope and the package:
    pip install openflexure-microscope-client

It intentionally writes a JSON evidence receipt with image hashes rather than
claiming success from API responses alone.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

# import openflexure_microscope_client as ofm_client


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    out = Path('ofm_validation_receipt.json')
    # microscope = ofm_client.find_first_microscope()
    # start = microscope.position.copy()
    # microscope.move_rel({'x': 100, 'y': 0, 'z': 0})
    # microscope.move(start)
    # microscope.autofocus()
    # image = microscope.capture_image()
    # image_path = Path('validation_capture.png')
    # image.save(image_path)

    receipt = {
        'schema_version': 'openflexure.validation_receipt.v1',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'instrument_id': 'replace-with-device-id',
        'variant': 'low_cost_motorised_v7_beta5',
        'server': {
            'host': 'microscope.local',
            'version': None,
            'openapi_sha256': None,
        },
        'motion_test': {
            'performed': False,
            'start_position': None,
            'end_position': None,
        },
        'autofocus_test': {
            'performed': False,
            'passed': None,
        },
        'image_test': {
            'performed': False,
            'image_path': None,
            'image_sha256': None,
        },
        'verdict': 'template_not_executed',
    }
    out.write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(f'wrote {out}')


if __name__ == '__main__':
    main()
