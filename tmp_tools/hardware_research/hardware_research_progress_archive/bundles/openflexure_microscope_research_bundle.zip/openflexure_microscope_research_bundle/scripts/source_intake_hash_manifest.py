"""Create a simple SHA-256 manifest for downloaded OpenFlexure sources."""
from __future__ import annotations

import csv
import hashlib
import sys
from pathlib import Path


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    if len(sys.argv) != 3:
        print('usage: python source_intake_hash_manifest.py <input_dir> <manifest.csv>')
        raise SystemExit(2)
    root = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2])
    rows = []
    for p in sorted(x for x in root.rglob('*') if x.is_file()):
        rows.append({
            'path': p.relative_to(root).as_posix(),
            'bytes': p.stat().st_size,
            'sha256': sha256_file(p),
        })
    with out.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['path','bytes','sha256'])
        w.writeheader()
        w.writerows(rows)
    print(f'wrote {out} with {len(rows)} files')


if __name__ == '__main__':
    main()
