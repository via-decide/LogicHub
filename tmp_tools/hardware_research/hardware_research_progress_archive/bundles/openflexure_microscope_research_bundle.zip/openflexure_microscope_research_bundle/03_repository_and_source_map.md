# Repository and Source Map

## Primary source groups

| Source group | Role | Intake action |
|---|---|---|
| `openflexure/openflexure-microscope` | Hardware source, OpenSCAD, build pipeline, documentation | Clone repository, record commit, hash scad/stl/build docs |
| Build server v7 release | Generated STL, assembly instructions, BOM, source.zip | Download exact release assets and hash |
| OpenFlexure Microscope Server | Raspberry Pi control service and HTTP API | Clone, record version, inspect API/extension model |
| OpenFlexure Connect | GUI/Electron/web interface | Clone, record version, map routes/API calls |
| Python client | Scriptable microscope control | Install or clone, inspect API method coverage |
| MATLAB client | Networked instrument control from MATLAB | Clone/download and map supported controls |
| OpenFlexure Blockly | Visual experiment scripting | Clone/download; map block -> API command |
| Microscope handbook | User guide and maintenance information | Download versioned PDF/source, hash |
| Technical overview | Design rationale and documentation index | Clone/record docs and gaps |
| Academic publications | Performance, software stack, autofocus, delta stage | Store DOI/arXiv/PMC metadata |

## Source authority hierarchy

1. Official build server release pages for the selected hardware version.
2. GitLab repository commit hashes for source files.
3. Official OpenFlexure docs for build/setup/usage.
4. Peer-reviewed or preprint papers for performance and architecture claims.
5. Community forum and Reddit only as qualitative build-risk evidence.

## Intake warning

Do not mix v6 and v7 assets unless the variant manifest explicitly declares compatibility. v7 has rewritten OpenSCAD, new instructions, enclosed wiring, different hardware standardisation choices, and different assembly expectations.

## Minimum source manifest fields

```json
{
  "project": "openflexure-microscope",
  "release": "v7.0.0-beta5",
  "source_kind": "scad|stl|bom|docs|server|client|image|paper",
  "url": "...",
  "local_path": "...",
  "sha256": "...",
  "license": "...",
  "variant": "high_res|low_cost|upright|manual|shared",
  "role": "mechanical|optical|electronics|software|validation|documentation"
}
```
