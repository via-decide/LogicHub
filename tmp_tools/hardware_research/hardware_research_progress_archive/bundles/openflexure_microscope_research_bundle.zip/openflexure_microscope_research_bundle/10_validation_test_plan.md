# OpenFlexure Validation Test Plan

## 1. Source validation

| Test | Pass condition |
|---|---|
| Source ZIP hash | SHA-256 recorded in manifest |
| STL hash | every printed STL hash recorded |
| Variant lock | one declared configuration only |
| BOM match | BOM variant matches STL/instruction variant |
| Git commit record | source repos pinned to commit SHA |
| License inventory | file-level license and attribution logged |

## 2. Print validation

| Test | Pass condition |
|---|---|
| printer calibration | dimensional cube within local tolerance |
| flexure inspection | no cracks, blobs, stringing in flexure gaps |
| gear fit | gears rotate without binding |
| actuator fit | actuator motion smooth through expected range |
| assembly photos | required stage photos captured |

## 3. Electronics validation

| Test | Pass condition |
|---|---|
| Pi boots | prebuilt image boots and UI reachable |
| server starts | API and UI respond |
| camera detected | live preview and capture work |
| controller detected | Sangaboard/compatible controller enumerates |
| motors move | X/Y/Z motion works independently |
| illumination works | LED/PCB controllable and stable |

## 4. Motion validation

Suggested first test script:

```text
read initial position
move +100 µm X
read position
move -100 µm X
read position
move +100 µm Y
move -100 µm Y
move +50 µm Z
move -50 µm Z
record pass/fail and final position error
```

## 5. Image validation

| Test | Evidence |
|---|---|
| capture blank field | image file + hash |
| capture printed grid | image file + hash |
| capture resolution target | image file + hash + metric |
| focus stack | stack metadata + sharpness curve |
| autofocus repeatability | repeated autofocus result table |
| illumination uniformity | center/edge intensity stats |

## 6. Validation receipt schema

```json
{
  "instrument_id": "ofm-001",
  "variant": "low_cost_motorised_v7_beta5",
  "source_manifest_hash": "sha256...",
  "server_version": "...",
  "client_version": "...",
  "stage_motion": {
    "x_repeatability_um": null,
    "y_repeatability_um": null,
    "z_repeatability_um": null
  },
  "imaging": {
    "test_target_image_sha256": "...",
    "autofocus_pass": true,
    "illumination_uniformity_pass": true
  },
  "verdict": "research_ready"
}
```
