# Software Stack and API Analysis

## 1. Runtime model

OpenFlexure software is designed around an embedded Raspberry Pi running the microscope server, with clients connecting locally or over the network.

Core runtime stack:

```text
Raspberry Pi OS / prebuilt SD image
  -> OpenFlexure Microscope Server
  -> hardware control layer
  -> camera and stage abstractions
  -> HTTP API / OpenAPI / Swagger UI
  -> OpenFlexure Connect / browser UI
  -> Python, MATLAB, Blockly automation clients
```

## 2. Control surfaces

| Control surface | User | Function |
|---|---|---|
| OpenFlexure Connect | normal user | GUI control, microscope discovery, camera preview, stage motion |
| Browser UI | user/dev | same interface through local server URL |
| Python client | researcher/dev | scripted scan, autofocus, image capture, experiments |
| MATLAB client | research lab | network control inside MATLAB workflows |
| Blockly | beginner/education | visual scripting |
| HTTP API | integrator | direct machine-readable control |
| Extensions | developer | server-side capabilities without changing base code |

## 3. API commands to map first

From the Python client package description and docs, initial commands to model are:

- discover microscope by mDNS.
- connect by hostname/IP.
- read position.
- absolute move.
- relative move.
- capture high-quality image.
- grab preview stream image.
- autofocus.
- list extensions.
- call extension GET/POST endpoints.

## 4. Daxini OS local-first experiment

The microscope is an excellent instrument-control target because it has clear sensory feedback and deterministic local actions.

Suggested local-first contract:

```json
{
  "experiment_id": "ofm_scan_v1",
  "instrument": "openflexure_microscope",
  "requires_network": false,
  "steps": [
    {"action": "move", "axis": "z", "mode": "autofocus"},
    {"action": "capture_image", "format": "png"},
    {"action": "validate_focus", "method": "edge_metric"},
    {"action": "record_receipt", "fields": ["position", "image_hash", "server_version"]}
  ]
}
```

## 5. Failure surfaces

| Failure | Cause | Detection |
|---|---|---|
| mDNS failure | complex network | connect by IP fallback |
| stage does not move | motor/controller/wiring | position unchanged after move |
| focus fails | optics/illumination/stage backlash | autofocus status + image sharpness |
| preview works but capture fails | camera pipeline/config | capture API error |
| extension unavailable | extension not installed | extension list missing capability |
| stale calibration | hardware changed | require calibration hash/version |

## 6. Recommended implementation target

Write a `logic_ofm_probe.py` script that:

1. discovers microscope.
2. records server metadata.
3. reads position.
4. moves +100 µm X, returns.
5. autofocuses.
6. captures image.
7. computes SHA-256 of image.
8. writes JSON evidence receipt.

This becomes the first Daxini/LogicHub proof adapter for scientific instruments.
