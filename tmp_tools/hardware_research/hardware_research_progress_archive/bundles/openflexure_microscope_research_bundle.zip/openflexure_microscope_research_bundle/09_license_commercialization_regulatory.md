# License, Commercialization, and Regulatory Notes

## 1. Hardware license

The OpenFlexure Microscope hardware is released under CERN-OHL-S-2.0 or later according to the official GitLab/project pages and build instructions. The project FAQ states that the CERN open hardware license permits making, selling, and modifying the design provided modified versions are shared under the same license.

Practical implication: selling kits or assembled microscopes can be allowed, but derivative hardware design obligations must be respected.

## 2. Documentation/license caution

The OpenFlexure website itself is licensed CC BY-SA 4.0. Do not assume all website text, images, photos, brand assets, or project marks have the same license as hardware source files. Keep a file-level license inventory.

## 3. Software license caution

The OpenFlexure client package metadata lists LGPLv3+ for the Python client. The handbook source snippet found in search results also referenced GPLv3 for software v3 alpha. Before integrating or distributing a software-derived product, perform a file-level license inventory across server, Connect, clients, and extensions.

## 4. Commercial product paths

| Product path | Feasibility | Notes |
|---|---|---|
| Educational kit | high | avoid medical claims; focus on STEM/lab learning |
| Research microscope kit | medium-high | requires good QC and calibration evidence |
| Soil/water education lab | high | good India/agriculture fit |
| Custom OpenFlexure module service | medium-high | optics, illumination, automation extensions |
| Certified diagnostic microscope | low without QMS | requires manufacturer certification, ISO13485, ISO14971, local IVD approval |

## 5. Medical/IVD boundary

The project states that following an open design does not by itself meet medical-device requirements. Certification is tied to a particular manufacturer and product. If building diagnostic products, treat OpenFlexure as an open-source starting design, not a certified product.

Minimum diagnostic-product prerequisites:

- legal manufacturer identification.
- ISO13485 quality management system.
- ISO14971 risk management file.
- production process validation.
- optical performance validation.
- traceable calibration.
- clinical/IVD performance claims under local rules.
- complaint and post-market process.

## 6. Recommended claim language

Safe early-stage claims:

- open-source digital microscope kit.
- educational microscope.
- research/teaching instrument.
- open lab automation platform.
- microscope assembly and calibration service.

Avoid until certified:

- diagnostic microscope.
- malaria diagnosis device.
- pathology diagnosis device.
- medical device.
- clinically validated result.
