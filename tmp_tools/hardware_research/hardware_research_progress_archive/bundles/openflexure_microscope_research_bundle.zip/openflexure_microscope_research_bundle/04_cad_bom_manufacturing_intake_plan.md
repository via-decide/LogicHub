# CAD, BOM, and Manufacturing Intake Plan

## 1. Configuration selection

Start with one configuration. Do not intake all variants at once.

Recommended order:

1. Low-cost motorised microscope.
2. High-resolution RMS objective microscope.
3. Manual microscope.
4. Upright microscope.
5. Custom electronics/optics variants.

Reason: the low-cost build reduces specialist optics sourcing risk while preserving the core motorised stage/software learning loop.

## 2. Asset classes to collect

| Asset class | Required files | Why it matters |
|---|---|---|
| Source CAD | `.scad`, modules, libraries, configuration files | Editable design authority |
| Generated CAD | `.stl` by release/configuration | Print/fabrication artifact |
| Dependency hashes | release hash file | Detect changed STL dependencies between revisions |
| BOM | exact build-configuration BOM | sourcing and cost model |
| Assembly docs | HTML/PDF instructions | process control and QA |
| Electronics docs | Sangaboard, LED PCB, drawer variants | wiring, motion, illumination |
| Software image | Raspberry Pi SD image | deployment reproducibility |
| Server source | Python server repo | API and hardware control |
| Clients | Connect/Python/MATLAB/Blockly | automation UX |
| Validation data | test target images, calibration images | readiness gate |

## 3. Print process validation

OpenFlexure’s precision depends on print quality. For productization, treat the 3D printer as a manufacturing process, not just a tool.

Minimum print QA:

- Material: PLA/PETG selection with recorded brand, color, lot.
- Nozzle diameter and layer height recorded.
- Dimensional cube calibration.
- Flexure gap inspection.
- Support/brim removal quality.
- Actuator travel smoothness.
- Gear mesh inspection.
- No cracks in compliant features.
- Capture microscope body photos before assembly.

## 4. BOM categories

This is a category-level intake checklist, not an official BOM replacement.

| Category | Examples | Variant dependency |
|---|---|---|
| Printed parts | body, stand, optics module, gears, drawers | high |
| Fasteners | screws, nuts, washers, sample clips | medium |
| Motion | stepper motors, gears, bands, actuators | high for motorised builds |
| Electronics | Raspberry Pi, Sangaboard/compatible controller, wiring | high |
| Camera | Raspberry Pi camera or selected sensor | high |
| Optics | RMS objective or Pi camera lens optics | very high |
| Illumination | PCB or LED/resistor workaround | high |
| Power | Pi supply, motor/LED power path | medium |
| Tools | screwdrivers, hex drivers, print cleanup tools | low |
| Calibration | slide/test target, calibration samples | medium |

## 5. Manufacturing release gates

| Gate | Evidence |
|---|---|
| CAD frozen | source ZIP hash + STL hash + variant manifest |
| Printer qualified | calibration print + dimensional record |
| BOM frozen | source BOM hash + supplier substitutions approved |
| Electronics ready | wiring checked, board version recorded |
| Assembly complete | photos at defined steps |
| Software booted | Pi image hash + server version |
| Motion validated | X/Y/Z move and repeatability tests |
| Imaging validated | focus stack + resolution test target |
| Autofocus validated | repeat autofocus pass rate |
| Packaging ready | transport and dust-protection check |

## 6. LogicHub object model

```text
ofm.variant.low_cost_motorised.v7_beta5
  ├── cad.source.openflexure_microscope.scad
  ├── cad.generated.body.stl
  ├── bom.configuration.low_cost_motorised
  ├── electronics.controller.sangaboard_v0_5
  ├── optics.module.pi_lens
  ├── software.server.openflexure_microscope_server
  ├── software.client.openflexure_connect
  ├── validation.motion.repeatability
  └── validation.imaging.resolution_target
```
