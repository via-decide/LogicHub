# LogicHub / GN8R Task Blocks for OpenFlexure

/task
repo: via-decide/LogicHub
mode: openflexure-source-intake-v1
tier: T5
estimated_time: 420
version: 1
depends_on: none
task: Build deterministic OpenFlexure source intake. Download v7 release source, selected STL files, BOM pages, assembly docs, server/client repositories, handbook, papers. Hash every file. Emit canonical source manifest.

CAUSATION:
OpenFlexure has generated manufacturing assets from OpenSCAD plus software/API components. Without deterministic intake, v6/v7 assets and custom variants can silently mix.

CONVERGENCE PROOF:
Variables:
S = source files
H = SHA-256 map
V = selected microscope variant
M = source manifest
Constraint = same(S,V) -> same(H,M)

Why naive fails:
- A: Download low-cost STL but use high-resolution BOM.
- B: Mix v6 source with v7 instructions.
- C: Lose the GitLab commit and cannot reproduce build.

EPISTEMIC_BOUNDARIES:
Facts:
- v7 is beta and recommended unless v6 is required.
- OpenSCAD source and generated STLs are separate artifacts.
- Official docs expose multiple configurations.
Unknowns:
- Exact downloaded asset hashes until intake runs.
- Local print quality.

EXECUTION_CONTRACT:
Create openflexure_source_manifest.json, source_manifest.csv, hash_report.txt, variant_manifest.json. No fabrication without manifest.

---

/task
repo: via-decide/LogicHub
mode: openflexure-cross-domain-graph-v1
tier: T5
estimated_time: 540
version: 1
depends_on: openflexure-source-intake-v1
task: Build OpenFlexure engineering relationship graph. Map OpenSCAD modules, generated STLs, printed parts, BOM rows, assembly steps, electronics, optics, software services, API commands, and validation images.

CAUSATION:
A microscope build fails when mechanical, optical, electronics, software, and calibration assumptions drift independently.

CONVERGENCE PROOF:
Variables:
P = printed parts
B = BOM rows
A = assembly steps
E = electronics configs
S = software endpoints
G = graph edges
Constraint = every build-critical artifact has at least one evidence-backed relationship.

Why naive fails:
- A: Treat STL names as enough identity.
- B: Ignore optics variant dependencies.
- C: Validate server API without validating physical image quality.

EPISTEMIC_BOUNDARIES:
Facts:
- High-resolution variant uses RMS objectives.
- Low-cost variant uses Pi camera lens.
- Python client exposes move, capture, autofocus commands.
Unknowns:
- Complete endpoint list until server OpenAPI is fetched.

EXECUTION_CONTRACT:
Emit engineering_graph.edges.ndjson, graph_manifest.json, unresolved_relationships.json. Unknown mappings stay unknown.

---

/task
repo: via-decide/LogicHub
mode: openflexure-validation-receipts-v1
tier: T5
estimated_time: 600
version: 1
depends_on: openflexure-cross-domain-graph-v1
task: Build OpenFlexure validation receipt layer. Capture stage motion, autofocus, image acquisition, resolution target, illumination uniformity, server metadata, and image hashes as replayable evidence.

CAUSATION:
A microscope can assemble correctly but produce unusable images. Fabrication evidence must include image evidence, not just assembly completion.

CONVERGENCE PROOF:
Variables:
M = motion receipt
F = focus receipt
I = image hash
R = resolution target result
Q = validation verdict
Constraint = verified microscope requires M,F,I,R and no failed blocking check.

Why naive fails:
- A: Run software test only.
- B: Capture pretty image without calibration target.
- C: Ignore autofocus failure or drift.

EPISTEMIC_BOUNDARIES:
Facts:
- OpenFlexure supports motorised scanning/autofocus.
- HTTP API and Python client can control microscope.
Unknowns:
- Actual optical resolution and focus repeatability until measured.

EXECUTION_CONTRACT:
Emit validation_receipt.json, image_manifest.csv, focus_report.md, motion_repeatability.csv. No verified state without image evidence.
