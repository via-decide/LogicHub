# Alignment With Previous Research Bundles

## 1. FarmBot alignment

FarmBot and OpenFlexure are both open-source cyber-physical systems with strong source-intake value.

| FarmBot | OpenFlexure |
|---|---|
| agriculture CNC robot | scientific microscope |
| outdoor gantry mechanics | indoor precision flexure mechanics |
| Farmduino motion controller | Sangaboard/compatible motion controller |
| Raspberry Pi / FarmBot OS | Raspberry Pi / OpenFlexure server |
| web app / MQTT / API | OpenFlexure Connect / HTTP API |
| tool-changing UTM | optics/illumination/stage variants |
| plant operation sequences | microscope scan/autofocus protocols |

## 2. Pupper V3 alignment

Pupper V3 is a dynamic robotics/control stack. OpenFlexure is a precision instrument-control stack. Both need:

- hardware/software boundary maps.
- versioned source manifests.
- calibration evidence.
- local-first runtime control.
- image or sensor evidence receipts.

## 3. Drone bundle alignment

The drone bundle focused on flight-controller safety and tether testing. OpenFlexure has lower physical risk but higher measurement-validity risk. The lesson transfers: no product state should be accepted without a validation receipt.

## 4. Air-gapped 8MB storage module alignment

The 8MB module can act as a local manifest/recipe carrier for OpenFlexure:

- store microscope variant manifest.
- store calibration profile.
- store validated scan recipes.
- store source hash ledger.
- store image evidence manifests, not raw image datasets.

## 5. LogicHub thesis

OpenFlexure proves the need for hardware Git semantics:

```text
OpenSCAD source
+ STL output
+ BOM variant
+ electronics config
+ software API version
+ calibration evidence
= actual instrument revision
```

A microscope revision is not a folder of STL files. It is a traceable chain from source code and CAD to physical measurement quality.
