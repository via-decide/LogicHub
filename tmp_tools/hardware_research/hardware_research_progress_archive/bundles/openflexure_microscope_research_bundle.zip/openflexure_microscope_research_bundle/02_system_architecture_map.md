# OpenFlexure System Architecture Map

## High-level architecture

```mermaid
flowchart TD
    USER[User / Researcher / Student]
    CONNECT[OpenFlexure Connect / Browser UI]
    CLIENTS[Python / MATLAB / Blockly Clients]
    API[HTTP API / OpenAPI / Web of Things interface]
    SERVER[OpenFlexure Microscope Server on Raspberry Pi]
    EXT[Server Extensions]
    CAM[Camera Pipeline]
    MOTION[Motion Controller / Sangaboard]
    ILLUM[Illumination PCB or LED]
    STAGE[3D Printed Flexure XYZ Stage]
    OPTICS[Optics Module]
    SAMPLE[Sample Slide]
    IMAGE[Image / Metadata / Scan Output]

    USER --> CONNECT
    USER --> CLIENTS
    CONNECT --> API
    CLIENTS --> API
    API --> SERVER
    SERVER --> EXT
    SERVER --> CAM
    SERVER --> MOTION
    SERVER --> ILLUM
    MOTION --> STAGE
    STAGE --> SAMPLE
    OPTICS --> SAMPLE
    CAM --> IMAGE
    IMAGE --> SERVER
    SERVER --> CONNECT
    SERVER --> CLIENTS
```

## Physical architecture

```text
Base / Stand
  ├── Main flexure microscope body
  │     ├── X/Y flexure stage
  │     ├── Z/focus axis
  │     ├── sample clips
  │     └── actuator interfaces
  ├── Optics module
  │     ├── RMS objective module OR Pi-camera-lens module
  │     ├── camera sensor path
  │     └── optical tube/mounting geometry
  ├── Illumination module
  │     ├── illumination PCB OR LED + resistor workaround
  │     └── condenser/diffuser options
  └── Electronics drawer
        ├── Raspberry Pi 4
        ├── Sangaboard v0.5 or compatible motor controller
        ├── wiring harness
        └── power/control connections
```

## Software stack

```text
OpenFlexure Connect / Web UI
        |
        v
HTTP API / Swagger / OpenAPI
        |
        v
OpenFlexure Microscope Server
        |-- stage control
        |-- camera control
        |-- autofocus
        |-- scan routines
        |-- extensions
        |-- configuration
        |
        v
Hardware drivers / motor controller / camera stack
```

## LogicHub relationship graph seed

```text
openSCAD source
  -> STL file
  -> printed part
  -> assembly step
  -> microscope module
  -> BOM row
  -> supplier part
  -> calibration check
  -> validation image

Python client command
  -> HTTP API route
  -> server method
  -> stage/camera action
  -> image capture
  -> metadata receipt
```
