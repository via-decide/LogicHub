# Validation and Commissioning Plan

## Validation philosophy

EVSE validation must separate:

- software correctness
- command protocol correctness
- safety-state correctness
- electrical safety
- thermal safety
- network/security behavior
- installation correctness
- field reliability

## P0 read-only validation

| Test | Method | Pass condition |
|---|---|---|
| Firmware version query | RAPI `GV` or HTTP status | version read and logged |
| EVSE state query | RAPI `GS` / HTTP `/status` | state parsed correctly |
| Fault counter query | RAPI `GF` | counters logged |
| Temperature query | RAPI `GP` / HTTP monitoring | temperatures present |
| Config dump | HTTP `/config` | schema validates |
| Claims endpoint | HTTP `/claims` | priority claims parsed |
| WebSocket stream | `/ws` | live state messages received |
| MQTT status | broker subscription | topic map documented |

## P1 simulated validation

| Test | Method | Pass condition |
|---|---|---|
| GFCI simulator | low-voltage mock | charger enters fault state |
| Stuck-relay simulator | mock AC detect | fault reported |
| No-ground simulator | ground path interrupted in safe simulator | fault reported |
| Boot lock | power cycle with gateway offline | disabled until online |
| Heartbeat watchdog | stop gateway heartbeat | fallback current or safe state |
| Overtemp simulator | mock temp above threshold | current throttle, then shutdown |
| OCPP unavailable | reject CSMS connection | local safety unaffected |
| MQTT malformed input | bad payloads | no unsafe claim accepted |

## P2 electrical validation

Electrical validation requires qualified personnel.

| Test | Required evidence |
|---|---|
| PE continuity | measurement report |
| Insulation/withstand | test report |
| Contact resistance | contactor/path measurement |
| Leakage/GFCI trip | trip threshold and time |
| Thermal rise | enclosure/cable/PCB contactor heat map |
| Relay stuck detection | controlled test proof |
| Cable/connector rating | datasheet and inspection |
| Breaker/RCD compatibility | installation evidence |

## P3 software/security validation

- HTTP auth enabled where needed
- HTTPS/MQTTS certificate handling tested
- default credentials changed
- firmware update receipt stored
- OTA rollback/recovery tested
- config backup/restore tested
- OCPP endpoint authenticated as supported
- MQTT ACL configured
- no public port exposure by default
- logs do not leak credentials

## Validation receipt format

```json
{
  "receipt_id": "openevse-validation-YYYYMMDD-0001",
  "device_serial": "unknown",
  "controller_fw": "unknown",
  "gateway_fw": "unknown",
  "test": "gfi_self_test",
  "environment": "low_voltage_simulator",
  "operator": "name",
  "result": "pass",
  "evidence": {
    "raw_trace_sha256": "...",
    "photos": [],
    "measurements": []
  },
  "safety_boundary": "no_mains",
  "approved_for_live_use": false
}
```

## Reliability metrics

Use reliability language carefully:

- charge session success rate
- fault false-positive rate
- failed charge-initiation rate
- network disconnection rate
- OTA failure rate
- thermal throttle rate
- GFCI trip count
- no-ground trip count
- stuck-relay trip count
- connector/cable inspection failures
- mean time to repair
- returned unit rate
