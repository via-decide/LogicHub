# Firmware and Software Stack Analysis

## Controller firmware: `open_evse`

Role:

- Dedicated EVSE safety controller.
- ATmega328P / ATSAMD21 target family.
- Implements EVSE state machine and safety behaviors.
- Uses RAPI serial ASCII protocol to communicate with host/gateway.

Key surfaces:

- pilot state
- current capacity
- service level
- timer
- charge energy/time limits
- auth lock
- heartbeat supervision
- fault counters
- firmware/protocol version
- temperature sensors
- current and voltage calibration
- stuck relay/no ground/GFI reporting

## RAPI protocol

RAPI is the key deterministic boundary:

```text
$<cmd> [args...]*<checksum>\r\n
```

Responses include:

```text
$OK [values...]
$NK
```

Engineering implication:

- Treat every RAPI command as a typed contract.
- Record read/write authority.
- Validate checksum.
- Separate read-only probes from mutating commands.
- Log every command and response in validation receipts.

## ESP32 gateway firmware

Role:

- local web server
- HTTP API
- WebSocket realtime stream
- MQTT status/control
- OCPP 1.6-J
- EmonCMS logging
- solar divert / Eco mode
- current shaper
- RFID auth
- OTA update
- wired Ethernet support
- energy/event logging on LittleFS

## Gateway runtime architecture

The ESP32 gateway initializes:

1. hardware abstraction
2. filesystem
3. config from EEPROM
4. EvseManager + RAPI
5. scheduler/divert/limit/lcd/rfid/LED subsystems
6. network + web server
7. energy logger, MQTT, OCPP, shaper, temp throttle

Loop responsibilities:

- Mongoose non-blocking network polling
- cooperative task scheduler
- RAPI sender
- EmonCMS publishing
- periodic demand-response checks

## EvseManager

EvseManager is the control arbiter. Every subsystem submits claims. The highest priority active claim wins. Safety and error claims outrank normal user/API/MQTT/OCPP actions.

LogicHub should model:

- client ID
- priority
- desired state
- max current
- auto release
- timestamp
- effective winner
- reason for losing claim

## UI

`openevse-gui-v2` is a Svelte/Vite/Bulma UI. Development uses `VITE_OPENEVSEHOST`, submodule init, `npm install`, `npm run dev`, and `npm run build`.

## Integration surfaces

| Interface | Use | Risk |
|---|---|---|
| HTTP REST | local config/control/status | auth/TLS/config mistakes |
| WebSocket | live status stream | local data exposure |
| MQTT | Home Assistant/status/control | broker security, topic ACL |
| MQTTS | safer MQTT | cert provisioning burden |
| OCPP 1.6-J | CSMS integration | protocol/security limitations |
| RAPI | controller command boundary | unsafe mutating commands |
| OTA | firmware update | rollback/signing/source trust |
| LittleFS logs | energy/event history | retention, flash wear, corruption |

## Development recommendations

- Build a read-only API/RAPI probe first.
- Create a mock controller.
- Replay safety states.
- Never test mutating commands on a live charger.
- Add version compatibility checks: ESP32 firmware ↔ OpenEVSE controller firmware.
- Treat OCPP 1.6-J as integration feature, not complete security answer.
- Create evidence receipts for every firmware update and every safety-test pass.
