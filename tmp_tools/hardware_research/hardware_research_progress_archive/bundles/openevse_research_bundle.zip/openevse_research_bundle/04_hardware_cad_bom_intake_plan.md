# Hardware, CAD, BOM, and Manufacturing Intake Plan

## Scope

OpenEVSE is not only firmware. A complete engineering intake must capture:

- controller board Eagle schematic and board files
- ESP32 gateway hardware reference
- enclosure files
- wiring harness and cable glands
- relays/contactors
- GFCI CT and self-test coil
- AC detect / ground monitor circuit
- MOV/surge devices
- thermal sensors
- J1772 or IEC connector/cable
- display/UI hardware
- licensed installation requirements

## P0 source files

From `OpenEVSE/OpenEVSE_PLUS`:

- `*.sch`
- `*.brd`
- board PNG/PDF previews
- release notes
- board revision folders

From `OpenEVSE/Enclosures`:

- STEP/STL/DXF/CAD files where present
- enclosure geometry
- mounting features
- cable gland/strain relief openings
- display cutouts
- connector placement

From firmware repositories:

- board definitions
- pin maps
- config defaults
- RAPI command tables
- API specifications

## Mandatory intake fields

| Field | Description |
|---|---|
| source_id | Stable source record |
| source_url | Canonical URL |
| repository | GitHub owner/name or official site |
| ref | tag, branch, commit or release |
| file_path | Repository-relative path |
| file_type | sch, brd, stl, step, firmware, docs, csv |
| sha256 | Local source hash |
| license | Declared source license |
| authority_class | official, mirror, forum, derived, unknown |
| safety_relevance | none, low, medium, high, critical |
| fabrication_ready | yes/no/unknown |
| requires_human_review | yes/no |
| notes | Gaps and caveats |

## OpenEVSE_PLUS revision review

Known repository notes include:

- v6.5.1 current version.
- v6.5 adds more powerful 10W power supply, support for 277V AC, 85C operational temperature, reworked AC detect for continuous ground monitoring requirement, onboard surge suppression MOVs, connector with Pilot/Proximity/Ground/5V.
- v5.5 changed GFCI test pin and DC relay outputs for PWM-capable relay closing/holding; connector changes to JST PH; power/data simplification for WiFi; -12V generation from +12V.
- v5 optimized for reduced build time and high-volume manufacturing.

## DFM checklist

### Electrical

- creepage/clearance checked against actual mains class
- relay/contactor rating verified
- contactor coil current and thermal behavior measured
- GFCI CT routed and shielded properly
- pilot and proximity circuits verified
- earth continuity verified
- surge/MOV path reviewed
- AC detect isolated
- input protection rated

### Mechanical

- enclosure flammability rating
- IP rating target
- cable gland rating
- strain relief
- PE bonding
- display gasket
- thermal vents or sealed heat strategy
- mounting screw isolation
- tamper-evident seal support

### Manufacturing

- board fab quote
- assembly process
- ICT or boundary test
- high-pot/insulation test plan
- earth continuity test
- firmware flashing jig
- QR/serial tracking
- safety label plan

## Do not fabricate until

- Eagle files are exported and inspected
- BOM is matched to exact components
- mains clearances are verified
- enclosure material is selected and qualified
- electrical engineer signs off
- compliance pathway is defined
- all safety tests pass with receipts
