# Safety and India Compliance Notes

## Safety posture

OpenEVSE documentation describes controller-level safety checks:

- diode check
- GFCI self-test
- ground monitoring
- stuck-relay detection
- vent-required detection
- temperature monitoring
- temperature throttling
- over-temperature shutdown
- boot lock
- heartbeat watchdog

A charger with disabled safety checks should never be left in service. Safety and error states must outrank user/API/MQTT/OCPP commands.

## India regulatory context

This section is not legal advice.

India-facing EVSE productization must be built around:

- CEA safety/electric supply regulations
- AIS 138 Part 1 for AC conductive EV charging
- BIS/ARAI applicable standards
- licensed electrical contractor requirements
- state DISCOM connection procedures
- fire safety requirements
- earthing/protective earth requirements
- public charging station requirements where applicable
- third-party testing/type testing as required
- installation and periodic inspection records

## Product safety gates

### Gate 1 — Non-mains bench

- low-voltage controller test
- RAPI mock
- UI/API test
- MQTT/OCPP test
- fault-state simulator

### Gate 2 — Isolated electrical bench

- qualified engineer only
- isolation transformer where appropriate
- protective gear
- no vehicle connected
- GFCI/ground/stuck-relay simulation
- contactor switching measurement

### Gate 3 — Controlled charger test

- real EVSE hardware
- correct enclosure
- PE continuity
- cable strain relief
- proper breaker/RCD/RCBO
- thermal measurement
- supervised charge session
- fault injection only where safe

### Gate 4 — Productization

- type testing
- compliance review
- installation manual
- field-service process
- warranty/liability terms
- security update policy
- batch serial traceability

## India-specific product wedge

Safer first business options:

1. **EVSE commissioning evidence pack**
   - installer checklist
   - photos
   - serial numbers
   - firmware versions
   - earth/GFCI/stuck-relay/thermal tests
   - handover certificate draft

2. **Local-first solar divert kit**
   - MQTT/Home Assistant/OpenEnergyMonitor integration
   - read-only monitoring first
   - current-shaping configuration
   - dashboards and support

3. **EVSE source-intake and review**
   - LogicHub ingestion of hardware/software sources
   - safety graph
   - firmware config audit
   - upgrade impact report

4. **Training bench**
   - low-voltage EVSE state simulator
   - pilot signal demo
   - no mains
   - engineering education
