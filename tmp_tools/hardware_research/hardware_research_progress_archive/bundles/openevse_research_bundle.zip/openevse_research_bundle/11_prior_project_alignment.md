# Prior Project Alignment

## 8MB air-gapped storage module

Shared pattern:

- local-first control
- explicit protocol boundary
- physical trust anchor
- manifest and hash-based source identity

OpenEVSE lesson:

- keep high-level UI separate from safety-critical control
- every command must be typed and logged
- update and validation receipts matter more than UI polish

## Drone CAD implementation bundle

Shared pattern:

- safety loop must be local and deterministic
- cloud/control app cannot override safety
- preflight/bench/tether/live-test gates

OpenEVSE lesson:

- error and safety states must outrank network commands
- live hardware must have read-only and low-voltage simulator phases before hazardous testing

## Pupper V3 / robotics bundles

Shared pattern:

- local runtime + network UI + telemetry
- hardware-control split
- logs and replay matter

OpenEVSE lesson:

- robotics safety gates can borrow EVSE-style priority claims and fault-dominant control arbitration

## FarmBot

Shared pattern:

- actuator platform
- web app + device control
- open-source commercial product

OpenEVSE difference:

- higher electrical hazard
- stricter compliance
- type testing and installation evidence are core product requirements

## SatNOGS

Shared pattern:

- open hardware + distributed network
- local client + cloud scheduler/network
- source-intake and station validation

OpenEVSE difference:

- SatNOGS can be receive-only; OpenEVSE involves direct power delivery to vehicle and humans near mains hardware

## OpenFlexure

Shared pattern:

- open scientific hardware
- repeatable build and calibration documentation
- strong fit for evidence receipts

OpenEVSE lesson:

- calibration/validation receipts should include safety constraints, not only performance metrics
