# OpenEVSE Architecture Map

## High-level system

```mermaid
flowchart TD
  User[User Browser / Mobile / Local Network] --> UI[Svelte Web UI]
  UI --> HTTP[HTTP REST API]
  UI --> WS[WebSocket Live Stream]
  HTTP --> ESP32[ESP32 WiFi Gateway]
  WS --> ESP32
  MQTT[MQTT Broker / Home Assistant] <--> ESP32
  OCPP[OCPP 1.6-J CSMS] <--> ESP32
  Emon[EmonCMS / Energy Logging] <--> ESP32
  ESP32 --> RAPI[Serial RAPI UART 115200]
  RAPI --> CTRL[OpenEVSE Safety Controller ATmega328P/SAMD21]
  CTRL --> Pilot[J1772 Pilot / Proximity]
  CTRL --> Relay[Relay / Contactor Driver]
  CTRL --> GFCI[GFCI/GFI CT + Self-Test]
  CTRL --> Ground[Ground / AC Detect]
  CTRL --> Temp[Temperature Sensors]
  Relay --> EV[Vehicle Inlet]
  Mains[AC Supply + Earth + Protection] --> Relay
```

## Safety split

```mermaid
flowchart LR
  subgraph Network_And_Policy["Network and policy layer"]
    UI[Web UI]
    API[HTTP / WebSocket]
    MQTT[MQTT]
    OCPP[OCPP]
    Scheduler[Schedule / Solar Divert / Current Shaper]
  end

  subgraph Gateway["ESP32 Gateway"]
    EvseManager[EvseManager Priority Claims]
    RapiClient[RAPI Client]
    Logs[LittleFS Logs]
    OTA[OTA Update]
  end

  subgraph Safety_Controller["Dedicated EVSE Controller"]
    StateMachine[EVSE State Machine]
    Pilot[Control Pilot]
    Relay[Relay Control]
    Ground[Ground Monitor]
    GFI[GFCI Self-Test]
    Stuck[Stuck Relay Detection]
    Temp[Temperature Shutdown]
  end

  UI --> API --> EvseManager
  MQTT --> EvseManager
  OCPP --> EvseManager
  Scheduler --> EvseManager
  EvseManager --> RapiClient --> StateMachine
  StateMachine --> Pilot
  StateMachine --> Relay
  StateMachine --> Ground
  StateMachine --> GFI
  StateMachine --> Stuck
  StateMachine --> Temp
```

## EvseManager priority model

The ESP32 architecture documentation describes a client/priority arbitration system. Safety and error priorities outrank ordinary API, MQTT, OCPP and timer control. This is the correct pattern for a cyber-physical charger: high-level clients can request current or mode, but lower-level safety claims must dominate.

```text
Error        priority 10000
Safety       priority 5000
Limit        priority 1100
OCPP         priority 1050
RFID         priority 1030
Manual       priority 1000
API/MQTT     priority 500
Boost        priority 200
Timer        priority 100
Divert       priority 50
Default      priority 10
```

## Control boundary

```text
Browser/UI/API/MQTT/OCPP
        |
        | high-level desired state
        v
ESP32 EvseManager
        |
        | RAPI serial command/query
        v
OpenEVSE controller
        |
        | pilot, relay, sensing, faults
        v
Vehicle + AC power path
```

## LogicHub graph seed

Object families to ingest:

- repository
- firmware module
- board revision
- Eagle schematic
- Eagle board
- connector
- GFCI circuit
- AC detect circuit
- pilot circuit
- relay driver
- ESP32 gateway feature
- RAPI command
- HTTP endpoint
- MQTT topic
- OCPP feature
- safety test
- validation receipt
- compliance rule
