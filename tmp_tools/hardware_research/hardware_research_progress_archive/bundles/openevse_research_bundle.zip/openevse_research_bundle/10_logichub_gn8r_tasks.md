# LogicHub / GN8R Task Blocks — OpenEVSE Intake

/task
repo: via-decide/LogicHub
mode: logichub-openevse-intake-v0.1
tier: T5
estimated_time: 360
version: 1
depends_on: none
task: Build OpenEVSE source manifest intake. Discover official OpenEVSE hardware, firmware, WiFi, UI, enclosure, simulator and documentation repositories. Pin commit SHA. Hash files. Classify hardware, firmware, software, docs, safety and compliance evidence.

CAUSATION:
EVSE is cyber-physical. Wrong source authority can attach safety evidence to the wrong firmware or board revision.

CONVERGENCE PROOF:
same source refs + same hash rules => same manifest. Every accepted source appears exactly once.

EPISTEMIC_BOUNDARIES:
No live charger commands. No fabrication claim. No compliance claim.

EXECUTION_CONTRACT:
Emit openevse-source-manifest.json, source_manifest.csv, hash report, unknown-source ledger.


/task
repo: via-decide/LogicHub
mode: logichub-openevse-safety-graph-v0.1
tier: T5
estimated_time: 480
version: 1
depends_on: openevse_source_manifest_v1
task: Build OpenEVSE safety relationship graph. Link controller firmware, RAPI commands, ESP32 gateway claims, GFCI, ground monitor, stuck relay, diode check, temperature throttle, heartbeat, boot lock, HTTP API, MQTT, OCPP and validation receipts.

CAUSATION:
A UI or OCPP command must never outrank a safety fault. LogicHub needs evidence of which component owns each safety decision.

CONVERGENCE PROOF:
Every safety object has one owner, one source, one validation target, one graph edge class.

EPISTEMIC_BOUNDARIES:
Graph shows documented safety paths only. Unknown circuits stay unknown.

EXECUTION_CONTRACT:
Emit openevse-safety-graph.ndjson, graph manifest, unresolved edges report.


/task
repo: via-decide/LogicHub
mode: logichub-openevse-validation-receipts-v0.1
tier: T5
estimated_time: 600
version: 1
depends_on: openevse_safety_graph_v1
task: Build low-voltage OpenEVSE validation receipt generator. Support read-only RAPI probes, HTTP status/config checks, mock fault traces, firmware version capture, safety-state evidence, and no-mains bench receipts.

CAUSATION:
EVSE safety cannot be proven by screenshots or self-report. It needs replayable traces and measured evidence.

CONVERGENCE PROOF:
same device trace + same schema => same receipt hash.

EPISTEMIC_BOUNDARIES:
No mains commands. No charger enable commands. No public safety approval.

EXECUTION_CONTRACT:
Emit validation_receipt.json, trace hash, pass/fail gates, human review checklist.
