# OpenEVSE Research Bundle

Generated: 2026-07-30T11:36:00+05:30

This bundle is a research, architecture, productization, and source-intake pack for the OpenEVSE open-source EV charging ecosystem.

## Important safety boundary

OpenEVSE is an AC EVSE / EV charging project. It involves mains voltage, high current, protective earth, ground-fault detection, relay safety, thermal limits, connector standards, and local electrical regulations.

Use this bundle for:

- source intake
- architecture mapping
- firmware/software study
- LogicHub/GN8R task generation
- validation planning
- India productization research
- safety/compliance scoping

Do not use this bundle alone to fabricate, install, sell, or modify a live EV charger.

## Contents

1. `01_deep_research_report.md`
2. `02_architecture_map.md`
3. `03_source_repository_map.md`
4. `04_hardware_cad_bom_intake_plan.md`
5. `05_firmware_software_stack_analysis.md`
6. `06_safety_compliance_india.md`
7. `07_validation_and_commissioning_plan.md`
8. `08_risk_register.csv`
9. `09_license_and_commercialization.md`
10. `10_logichub_gn8r_tasks.md`
11. `11_prior_project_alignment.md`
12. `12_bibliography_and_sources.md`
13. `source_manifest.csv`
14. `relationship_graph_seed.json`
15. `templates/`
16. `schemas/`
17. `scripts/`

## Verdict

OpenEVSE is valuable as a reference architecture for a local-first, open-source AC EVSE control stack:

Browser / local UI
→ ESP32 WiFi gateway
→ serial RAPI protocol
→ dedicated EVSE safety controller
→ contactor / pilot / GFCI / ground / temperature systems

The strongest product wedge is not direct cloning of a mains charger. The safer wedge is: test fixtures, monitoring, local-first controller integrations, compliance evidence tooling, India-specific installation checklists, and LogicHub source-intake pipelines for EVSE hardware/firmware.
