# Source Repository Map

## Primary repositories

| Repository | Role | Intake priority |
|---|---|---:|
| `OpenEVSE/OpenEVSE_PLUS` | Controller hardware; Eagle SCH/BRD; board revision history; CC BY-SA 3.0 | P0 |
| `OpenEVSE/open_evse` | EVSE safety/controller firmware; ATmega/SAMD; RAPI; J1772 state machine | P0 |
| `OpenEVSE/openevse_esp32_firmware` | ESP32 WiFi gateway; local UI server; HTTP/WS; MQTT; OCPP; safety page; energy logs | P0 |
| `OpenEVSE/openevse-gui-v2` | Svelte/Vite/Bulma web UI | P1 |
| `OpenEVSE/ESP8266_WiFi_v2.x` | Legacy ESP8266 WiFi firmware | P2 |
| `OpenEVSE/OpenEVSE_EV_Simulator` | EV simulator / bench validation source | P1 |
| `OpenEVSE/Enclosures` | Enclosure/mechanical source repository | P1 |
| `OpenEVSE/openevse_wifi_gui` | Older web UI surface | P2 |
| `OpenEVSE/openevse_wifi_server` | Older WiFi server surface | P2 |

## Repository classification

### Hardware

- Eagle `.sch` / `.brd`
- board screenshots
- board revision notes
- hardware license statements
- enclosure files

### Firmware

- EVSE controller firmware
- ESP32 firmware
- RAPI command parser/client
- GFCI and relay safety logic
- energy logging
- OTA update
- communication protocols

### Web/software

- UI components
- REST/WS API definitions
- MQTT integration
- OCPP integration
- user docs
- generated screenshots
- OpenAPI spec

### Compliance/evidence

- safety docs
- fault docs
- release notes
- build docs
- API docs
- installer docs

## Source-intake policy

Pin every repository by:

- URL
- owner/name
- branch
- commit SHA
- license
- file hash
- date fetched
- file inventory
- generated/not-generated classification

Do not mix:

- current ESP32 gateway docs
- legacy ESP8266 firmware
- old OpenEnergyMonitor forks
- store/product pages
- unofficial forum patches

without marking source class.
