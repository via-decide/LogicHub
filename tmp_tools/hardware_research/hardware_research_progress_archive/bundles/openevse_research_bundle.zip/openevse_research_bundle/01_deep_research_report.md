# Deep Research Report — OpenEVSE Open-Source EV Charging System

## SOURCE

Primary source set:

- OpenEVSE official site and store/documentation pages.
- `OpenEVSE/OpenEVSE_PLUS` hardware repository.
- `OpenEVSE/open_evse` EVSE controller firmware repository.
- `OpenEVSE/openevse_esp32_firmware` ESP32 WiFi gateway repository.
- `OpenEVSE/openevse-gui-v2` UI repository.
- OpenEVSE safety and architecture documentation.
- India CEA / ARAI EV charging safety references.
- Academic references on EVSE reliability and OCPP cybersecurity.

## ACCESS / ENTRY

OpenEVSE is best treated as a cyber-physical AC charging platform, not as a normal IoT board.

The system splits into:

1. **Safety controller**
   - AC EVSE safety logic.
   - Pilot/proximity signalling.
   - Relay/contactor control.
   - GFCI/GFI.
   - Ground monitoring.
   - Stuck-relay detection.
   - Temperature monitoring.
   - Serial RAPI interface.

2. **ESP32 smart gateway**
   - Local web UI.
   - HTTP REST API.
   - WebSocket stream.
   - MQTT.
   - OCPP 1.6-J.
   - Solar divert / Eco mode.
   - Current shaper.
   - Energy logging.
   - OTA update.

3. **Web interface**
   - Svelte/Vite user interface.
   - Runs from ESP32 web server or development host.
   - Dashboard, schedule, charging modes, settings, history, firmware update.

4. **Open hardware surface**
   - Eagle SCH/BRD files in OpenEVSE_PLUS.
   - Enclosure repository.
   - EV simulator repository.
   - Multiple historical board revisions.

## INTENT CAPTURE

The goal of this bundle is to answer:

- What can be learned from OpenEVSE as a reference open-source hardware/software product?
- Which source repositories matter?
- How does the system separate safety-critical control from network/UI logic?
- What would LogicHub need to ingest for deterministic hardware/firmware review?
- Can this become a product or agency offering in India?
- What are the safety and regulatory blockers?

## STATE / LOGIC ENGINE

OpenEVSE has a clean architectural lesson:

**Do not let the web UI directly own charging safety.**

The ESP32 gateway may request charge modes, schedules, current limits, MQTT/OCPP actions, solar divert and logging. The dedicated controller owns the lower-level EVSE safety surface. The serial RAPI boundary makes this split inspectable.

This is similar to prior local-first projects:

- 8MB module: physical module preserves local control and explicit protocol boundaries.
- Drone bundle: flight controller owns safety-critical loop; UI is secondary.
- Pupper/FarmBot/SatNOGS/OpenFlexure: local machine control is separated from remote or browser control.

## ACTIONS

The research bundle creates:

- architecture map
- repository map
- source intake plan
- safety/compliance matrix
- validation plan
- risk register
- commercialization notes
- LogicHub/GN8R tasks
- source manifest
- graph seed
- scripts and schemas

## OUTPUT / METRICS

Minimum useful OpenEVSE engineering review metrics:

| Area | Metric |
|---|---|
| Hardware | schematic/board file revision, contactor rating, earth continuity, MOV/surge design, AC detect, GFCI CT path |
| Firmware | OpenEVSE firmware version, ESP32 firmware version, RAPI compatibility, boot lock and heartbeat settings |
| Safety | GFCI self-test, ground monitor, stuck-relay test, diode check, temperature throttling, over-temp shutdown |
| Network | HTTP auth, MQTTS/HTTPS certificate handling, OCPP endpoint security, local-only mode capability |
| Energy | current measurement calibration, voltage calibration, session kWh accuracy, current shaping behavior |
| Compliance | CEA safety regulations, AIS 138 AC charger relevance, licensed electrical installation, third-party lab testing |
| Reliability | fault log replay, connector wear, relay cycle count, thermal rise, brownout recovery, OTA rollback |
| Productization | BOM lock, enclosure IP rating, cable/connector certification, installation documentation, field-service procedure |

## Core technical finding

OpenEVSE is a strong reference architecture for an open local-first AC EVSE. It is not a simple maker project when used on mains power. The high-value business layer is not “sell a cloned charger”; it is engineering evidence, monitoring, localized integration, and verified safe installation tooling.

## System roles

### Dedicated EVSE controller

The OpenEVSE controller firmware provides the safety-critical surface. It handles the EVSE state machine, pilot/proximity logic, relay safety, GFI/GFCI, no-ground/stuck-relay detection, temperature monitoring and RAPI.

### ESP32 WiFi gateway

The ESP32 gateway provides local network functionality. It speaks RAPI to the controller, serves the web UI, exposes HTTP/WebSocket APIs, publishes MQTT, supports OCPP 1.6-J, handles OTA update and logs energy.

### Svelte UI

The UI gives dashboard, charge modes, current controls, schedule, session limits, monitoring, history, safety settings, integrations, firmware update and troubleshooting.

### Physical power path

A real EVSE product also needs certified contactor/relay, CT/GFCI path, thermal sensing, pilot/proximity wiring, enclosure, cable glands, strain relief, PE continuity, appropriate MCB/RCD/RCBO, surge protection and correct earthing.

## Architectural recommendation

For a first safe India-facing effort:

1. Do not fabricate or sell mains EVSE hardware first.
2. Build a receive/control/monitoring test rig using low-voltage simulation.
3. Build a LogicHub source-intake adapter for OpenEVSE hardware/software.
4. Build an OpenEVSE validation receipt generator.
5. Build an India EVSE installation checklist and evidence pack.
6. Add OCPP/MQTT/Home Assistant integration experiments.
7. Only after certified electrical review, move toward AC EVSE enclosure/harness manufacturing.

## Go / No-Go

**GO** for:

- learning EVSE architecture
- local-first energy automation
- source ingestion
- compliance evidence tooling
- test fixtures
- simulator workflows
- MQTT/OCPP/Home Assistant integrations
- India installer documentation pack

**NO-GO without licensed electrical engineering and compliance testing** for:

- live mains installation
- public charger deployment
- selling modified hardware
- bypassing safety checks
- changing firmware on certified charger and claiming certification remains intact
- high-current enclosure/cable/contactor substitutions without qualification

## Monetisation logic

Best wedges:

1. **EVSE evidence gateway**
   - versioned firmware/hardware/source manifest
   - installation checklist
   - safety-test receipt
   - OCPP/MQTT config audit
   - field-service evidence record

2. **Home solar charging integration**
   - local-first MQTT/OpenEVSE/Home Assistant setup
   - grid export based charging
   - dashboard and maintenance service

3. **LogicHub EVSE review pack**
   - parse OpenEVSE Eagle/KiCad/firmware sources
   - trace hardware safety path to firmware configuration
   - produce EVSE Engineering PR risk report

4. **Installer training and commissioning checklist**
   - CEA/AIS 138 awareness
   - earth/GFCI/stuck relay/temperature tests
   - documentation pack for handover

5. **Low-voltage EVSE teaching bench**
   - pilot-state simulator
   - RAPI command visualizer
   - contactor simulation
   - fault injection

## One next action

Build the low-voltage OpenEVSE validation bench first:

- no mains
- simulated pilot/proximity
- simulated GFCI event
- mocked RAPI
- ESP32 UI/API test
- JSON validation receipts

This proves the software and safety-state model before any dangerous hardware work.
