# Bibliography and Source Notes

## openevse-official-home

- Title: OpenEVSE official site
- URL: https://www.openevse.com/
- Type: official website
- Evidence: OpenEVSE supplies open-source charging station hardware and software solutions; source code for hardware and firmware is available on GitHub.
- Use in bundle: Project identity and open-source positioning

## openevse-plus-github

- Title: OpenEVSE/OpenEVSE_PLUS
- URL: https://github.com/OpenEVSE/OpenEVSE_PLUS
- Type: GitHub repository
- Evidence: Hardware files in Eagle SCH/BRD format; CC BY-SA 3.0; current version v6.5.1; board evolution notes for AC detect, GFCI, relay driver, current sensing and v6.5 power supply/ground monitoring changes.
- Use in bundle: Hardware/CAD/BOM source authority

## openevse-controller-firmware

- Title: OpenEVSE/open_evse
- URL: https://github.com/OpenEVSE/open_evse
- Type: GitHub repository
- Evidence: Controller firmware for ATmega328P / ATSAMD21G18; SAE J1772 L1/L2; RAPI serial protocol; safety controller role.
- Use in bundle: Safety-controller firmware and RAPI contract

## openevse-esp32-firmware

- Title: OpenEVSE/openevse_esp32_firmware
- URL: https://github.com/OpenEVSE/openevse_esp32_firmware
- Type: GitHub repository
- Evidence: ESP32 WiFi gateway; local web UI; HTTP/WebSocket; MQTT; OCPP 1.6-J; RFID; solar divert; current shaper; logs; safety-page docs.
- Use in bundle: Smart gateway, local-first control, integrations

## openevse-gui-v2

- Title: OpenEVSE/openevse-gui-v2
- URL: https://github.com/OpenEVSE/openevse-gui-v2
- Type: GitHub repository
- Evidence: New UI for WiFi module; Svelte/Vite/Bulma; local development against openevse.local.
- Use in bundle: Web UI architecture

## openevse-ev-simulator

- Title: OpenEVSE/OpenEVSE_EV_Simulator
- URL: https://github.com/OpenEVSE/OpenEVSE_EV_Simulator
- Type: GitHub repository
- Evidence: EV simulator repository present in OpenEVSE organization.
- Use in bundle: Bench validation and charger simulator intake

## openevse-enclosures

- Title: OpenEVSE/Enclosures
- URL: https://github.com/OpenEVSE/Enclosures
- Type: GitHub repository
- Evidence: OpenEVSE enclosure repository present in OpenEVSE organization.
- Use in bundle: Mechanical enclosure/source intake

## openevse-safety-doc

- Title: OpenEVSE ESP32 firmware safety documentation
- URL: https://github.com/OpenEVSE/openevse_esp32_firmware/blob/master/docs/user/safety.md
- Type: GitHub documentation
- Evidence: Controller continuously runs diode check, GFCI self-test, ground monitoring, stuck-relay detection, vent-required detection, and temperature monitoring; failed checks fault the charger immediately; safety checks disabled only for diagnostics.
- Use in bundle: Safety model

## openevse-architecture-doc

- Title: OpenEVSE ESP32 firmware architecture documentation
- URL: https://github.com/OpenEVSE/openevse_esp32_firmware/blob/master/docs/developer/architecture.md
- Type: GitHub documentation
- Evidence: ESP32 gateway connected via RAPI serial to ATmega/SAMD controller; EvseManager priority system; subsystems for MQTT, EmonCMS, solar divert, OCPP, RFID, energy logging.
- Use in bundle: Runtime architecture

## india-cea-safety

- Title: CEA standards for EV charging and safety
- URL: https://e-amrit.niti.gov.in/cea-standard
- Type: Indian public resource
- Evidence: CEA safety/electric-supply measures include EV charging station safety, earth protection, fire prevention, testing, inspection, periodic assessment, maintenance records and international charging standards.
- Use in bundle: India compliance strategy

## india-arai-ais138

- Title: ARAI AIS 138 AC/DC charging standards summary
- URL: https://e-amrit.niti.gov.in/arai-standard
- Type: Indian public resource
- Evidence: AIS 138 Part 1 applies to AC EV conductive charging systems up to 1000V; covers supply-device characteristics, operating conditions, operator/third-party safety and requirements for EVSE-AC.
- Use in bundle: India AC charger compliance baseline

## ocpp-security-survey

- Title: Electric Vehicle Charging: Survey on Security Issues and Challenges of OCPP
- URL: https://arxiv.org/abs/2207.01950
- Type: academic paper
- Evidence: OCPP is widely used for communication in smart charging, but security weaknesses remain; OCPP 2.0 includes security features compared with earlier protocol versions.
- Use in bundle: OCPP risk/commercial direction

## evse-reliability-study

- Title: Reliability of Open Public Electric Vehicle Direct Current Fast Chargers
- URL: https://arxiv.org/abs/2203.16372
- Type: academic paper
- Evidence: Public DCFC study found 72.5% of 657 connectors functional; failures included screens, payments, initiation, networks, and connectors; calls for precise reliability definitions and third-party verification.
- Use in bundle: Validation strategy and reliability metrics
