#!/usr/bin/env python3
"""
Read-only OpenEVSE HTTP API probe scaffold.

Only calls GET endpoints by default.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import time
import urllib.request

GET_ENDPOINTS = ["/status", "/config", "/claims", "/time", "/logs"]

def fetch(base_url: str, path: str, timeout: float) -> dict:
    url = base_url.rstrip("/") + path
    started = time.time()
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            body = r.read()
            return {
                "path": path,
                "status": r.status,
                "elapsed_ms": int((time.time() - started) * 1000),
                "body_sha256": hashlib.sha256(body).hexdigest(),
                "body_preview": body[:500].decode(errors="replace"),
            }
    except Exception as e:
        return {"path": path, "error": repr(e)}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://openevse.local")
    ap.add_argument("--timeout", type=float, default=3.0)
    args = ap.parse_args()

    records = [fetch(args.base_url, ep, args.timeout) for ep in GET_ENDPOINTS]
    raw = json.dumps(records, sort_keys=True).encode()
    print(json.dumps({
        "probe_type": "openevse_http_read_only",
        "approved_for_live_use": False,
        "base_url": args.base_url,
        "trace_sha256": hashlib.sha256(raw).hexdigest(),
        "records": records,
    }, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
