#!/usr/bin/env python3
"""
Hash an OpenEVSE source intake directory.

Usage:
  python scripts/hash_source_intake.py /path/to/source_intake > file_hashes.csv

This script is safe: it only reads files and prints SHA-256 hashes.
"""
from __future__ import annotations
import csv
import hashlib
import pathlib
import sys

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def main() -> int:
    if len(sys.argv) != 2:
        print("usage: hash_source_intake.py <directory>", file=sys.stderr)
        return 2
    root = pathlib.Path(sys.argv[1]).resolve()
    if not root.is_dir():
        print(f"not a directory: {root}", file=sys.stderr)
        return 2

    writer = csv.writer(sys.stdout)
    writer.writerow(["relative_path", "size_bytes", "sha256"])
    for p in sorted(root.rglob("*")):
        if p.is_file():
            rel = p.relative_to(root).as_posix()
            writer.writerow([rel, p.stat().st_size, sha256_file(p)])
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
