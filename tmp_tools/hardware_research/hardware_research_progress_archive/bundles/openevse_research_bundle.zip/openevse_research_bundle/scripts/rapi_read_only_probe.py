#!/usr/bin/env python3
"""
Read-only OpenEVSE RAPI probe scaffold.

Default commands are read-only:
- GV: firmware/protocol version
- GS: EVSE state
- GF: fault counters
- GP: temperature sensors

Do not add mutating commands for live chargers unless a qualified engineer has approved the test plan.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import time

try:
    import serial  # pyserial
except ImportError:
    serial = None

READ_ONLY_COMMANDS = ["GV", "GS", "GF", "GP"]

def checksum(payload: str) -> str:
    c = 0
    for ch in payload:
        c ^= ord(ch)
    return f"{c:02X}"

def frame(cmd: str) -> bytes:
    payload = cmd
    return f"${payload}*{checksum(payload)}\r\n".encode()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", required=True)
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--timeout", type=float, default=2.0)
    args = ap.parse_args()

    if serial is None:
        raise SystemExit("pyserial not installed. Run: pip install pyserial")

    records = []
    with serial.Serial(args.port, args.baud, timeout=args.timeout) as ser:
        for cmd in READ_ONLY_COMMANDS:
            tx = frame(cmd)
            ser.write(tx)
            rx = ser.readline()
            records.append({
                "command": cmd,
                "tx": tx.decode(errors="replace").strip(),
                "rx": rx.decode(errors="replace").strip(),
                "timestamp_unix": time.time(),
            })
            time.sleep(0.2)

    raw = json.dumps(records, sort_keys=True).encode()
    print(json.dumps({
        "probe_type": "openevse_rapi_read_only",
        "approved_for_live_use": False,
        "commands": READ_ONLY_COMMANDS,
        "trace_sha256": hashlib.sha256(raw).hexdigest(),
        "records": records,
    }, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
