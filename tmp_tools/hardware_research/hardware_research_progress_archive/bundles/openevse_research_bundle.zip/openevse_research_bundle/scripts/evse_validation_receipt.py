#!/usr/bin/env python3
"""
Create a validation receipt wrapper from a raw trace file.

Usage:
  python scripts/evse_validation_receipt.py --test-id T-001 --trace trace.json --result pass
"""
from __future__ import annotations
import argparse
import hashlib
import json
import pathlib
import time
import uuid

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--test-id", required=True)
    ap.add_argument("--trace", required=True)
    ap.add_argument("--result", choices=["pass","fail","blocked","not_run"], required=True)
    ap.add_argument("--safety-boundary", default="no_mains",
                    choices=["no_mains","low_voltage_simulator","isolated_engineering_bench","live_charger"])
    args = ap.parse_args()

    trace_path = pathlib.Path(args.trace)
    data = trace_path.read_bytes()
    receipt = {
        "receipt_id": f"openevse-{time.strftime('%Y%m%d')}-{uuid.uuid4().hex[:8]}",
        "generated_at_unix": time.time(),
        "test_id": args.test_id,
        "result": args.result,
        "safety_boundary": args.safety_boundary,
        "approved_for_live_use": False,
        "evidence": {
            "trace_path": str(trace_path),
            "trace_sha256": hashlib.sha256(data).hexdigest(),
            "trace_size_bytes": len(data),
        },
    }
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
