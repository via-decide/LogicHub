# License and Commercialization Notes

## Source licenses observed

| Surface | License signal |
|---|---|
| OpenEVSE_PLUS hardware | CC BY-SA 3.0 in repository README |
| ESP32 WiFi firmware | GPLv3 in repository README |
| `openevse-gui-v2` | BSD-2-Clause stated in `open_evse` system overview |
| `open_evse` controller firmware | verify exact license file in repository before redistribution |

## Commercialization risks

### Hardware

CC BY-SA 3.0 allows reuse under share-alike terms, but commercial products must preserve attribution and share-alike obligations. Exact obligations must be reviewed before manufacturing.

### Firmware

GPLv3 firmware creates source-code distribution obligations when distributing modified binaries. A product company can sell hardware, but must handle source offer, license notices, build scripts and corresponding source obligations properly.

### Certification/listing

Even when source licenses allow modification, regulatory certification does not automatically transfer to a modified charger. Changing firmware, hardware, contactors, connectors, enclosure, cable, or installation method can invalidate prior certification assumptions.

## Better business model

Do not begin as an uncertified charger OEM.

Start with:

1. validation/evidence tooling
2. low-voltage teaching bench
3. solar divert integration
4. Home Assistant/MQTT/OCPP support
5. installer documentation
6. source-intake/LogicHub review pipeline
7. retrofit advisory only where legally and electrically safe

## Commercial product ladder

| Stage | Product | Regulatory burden |
|---|---|---|
| 1 | Research report / training course | low |
| 2 | Low-voltage EVSE simulator | low-medium |
| 3 | Installer evidence/checklist tool | medium |
| 4 | Smart charging integration service | medium |
| 5 | Enclosure/harness accessory | high |
| 6 | Complete AC EVSE charger | very high |
| 7 | Public charging station / CSMS | very high |
