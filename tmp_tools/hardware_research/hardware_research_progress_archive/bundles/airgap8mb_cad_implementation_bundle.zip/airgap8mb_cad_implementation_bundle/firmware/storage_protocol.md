# Storage Protocol Rev-A

## Serial settings

- Baud: 115200
- Framing: 8N1
- Transport: FTDI TTL UART
- Encoding: ASCII command during bring-up; binary framing for Rev-B

## Minimum commands

| Command | Purpose |
|---|---|
| `IDENTIFY` | Return firmware version, flash JEDEC ID, capacity, manifest version |
| `READ addr len` | Read bytes from flash |
| `BEGIN object_id size crc32` | Start transactional object write |
| `WRITE offset hex_payload` | Write up to one 256-byte page |
| `COMMIT` | Validate and publish object in manifest |
| `ABORT` | Abort pending write |
| `VERIFY object_id` | Recompute CRC and return status |
| `READ_MANIFEST` | Return active manifest slot |

## Product rule

Raw flash writes must not be exposed as a public command in production firmware.
