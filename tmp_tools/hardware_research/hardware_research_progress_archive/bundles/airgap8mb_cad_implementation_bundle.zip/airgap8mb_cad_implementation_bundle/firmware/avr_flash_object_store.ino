#include <SPI.h>

// Air-Gapped 8MB Storage Module Rev-A firmware scaffold
// Target: ATmega328P-PU + W25Q64JV SPI NOR
// Warning: scaffold only. Add watchdog, bounds checks, CRC, and power-loss tests before product use.

static const uint8_t FLASH_CS = 10;   // PB2
static const uint8_t STATUS_LED = 8;  // PB0

static void flashSelect() { digitalWrite(FLASH_CS, LOW); }
static void flashDeselect() { digitalWrite(FLASH_CS, HIGH); }

uint8_t flashReadStatus1() {
  flashSelect();
  SPI.transfer(0x05);
  uint8_t s = SPI.transfer(0x00);
  flashDeselect();
  return s;
}

void flashWriteEnable() {
  flashSelect();
  SPI.transfer(0x06);
  flashDeselect();
}

uint32_t flashReadJedecId() {
  flashSelect();
  SPI.transfer(0x9F);
  uint32_t id = ((uint32_t)SPI.transfer(0x00) << 16);
  id |= ((uint32_t)SPI.transfer(0x00) << 8);
  id |= SPI.transfer(0x00);
  flashDeselect();
  return id;
}

uint8_t flashReadByte(uint32_t addr) {
  flashSelect();
  SPI.transfer(0x03);
  SPI.transfer((addr >> 16) & 0xFF);
  SPI.transfer((addr >> 8) & 0xFF);
  SPI.transfer(addr & 0xFF);
  uint8_t v = SPI.transfer(0x00);
  flashDeselect();
  return v;
}

void flashRead(uint32_t addr, uint8_t *buf, uint16_t len) {
  flashSelect();
  SPI.transfer(0x03);
  SPI.transfer((addr >> 16) & 0xFF);
  SPI.transfer((addr >> 8) & 0xFF);
  SPI.transfer(addr & 0xFF);
  for (uint16_t i = 0; i < len; i++) buf[i] = SPI.transfer(0x00);
  flashDeselect();
}

void setup() {
  pinMode(FLASH_CS, OUTPUT);
  pinMode(STATUS_LED, OUTPUT);
  flashDeselect();
  Serial.begin(115200);
  SPI.begin();
  SPI.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0));

  uint32_t id = flashReadJedecId();
  Serial.print("JEDEC_ID=0x");
  Serial.println(id, HEX);
}

void loop() {
  if (!Serial.available()) return;
  char c = Serial.read();

  if (c == 'i') {
    uint32_t id = flashReadJedecId();
    Serial.print("OK ID ");
    Serial.println(id, HEX);
  } else if (c == 's') {
    Serial.print("OK STATUS ");
    Serial.println(flashReadStatus1(), HEX);
  } else if (c == 'r') {
    uint8_t b = flashReadByte(0);
    Serial.print("OK BYTE0 ");
    Serial.println(b, HEX);
  } else {
    Serial.println("ERR UNKNOWN_CMD");
  }
}
