# Preliminary Manufacturing Outputs

These Gerber and Excellon files are script-generated draft outputs for review and quotation discussions.
They are **not final production files**.

Final Gerbers must be regenerated from KiCad after:

- ERC passes.
- DRC passes.
- footprints are verified.
- board stackup is confirmed.
- fab design rules are entered.
- mounting holes and enclosure clearances are checked.

Use these files only as a first manufacturing-facing reference.
