# BOM Notes

## Productization caution

- ATmega328P-PU is suitable for an Arduino-compatible EVT prototype, but not ideal as a new commercial design anchor.
- W25Q64JV-class flash is correct for the 8MB target.
- Rev-A uses external FTDI header to reduce USB-layout risk. Product Rev-B should use onboard USB-C + USB-UART + ESD protection.

## Must-verify before ordering

- Footprint dimensions from manufacturer datasheet.
- Crystal load capacitance.
- LDO output current and dropout.
- 74LVC input tolerance with selected vendor.
- Header orientation and enclosure clearance.
- Flash WP#/HOLD# policy.
