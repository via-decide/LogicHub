# Deep Research Report — Air-Gapped 8MB Storage Module

## Executive verdict

The concept is feasible as an **offline deterministic storage cartridge and local trust anchor**, not as an independent AI compute engine. The right product framing is:

> A tamper-evident, USB-serviceable, air-gapped 8MB rule/package/manifest cartridge controlled by a small deterministic MCU.

The web application should remain a portal, checkout, identity, and demonstration layer. Private logic should remain on the physical cartridge or on the user’s local host.

## Architecture

```mermaid
flowchart TD
    WEB[logichub.app / checkout / account portal]
    HOST[Local host utility]
    FTDI[FTDI USB-TTL bridge]
    MCU[ATmega328P-PU deterministic controller]
    FLASH[W25Q64JV 8MB SPI NOR]
    MANIFEST[Signed manifest + CRC/SHA checks]
    ENC[Tamper-evident enclosure]

    WEB -. no private logic .-> HOST
    HOST --> FTDI
    FTDI --> MCU
    MCU --> FLASH
    MCU --> MANIFEST
    MCU --> ENC
```

## Hardware design

Rev-A uses a 5V ATmega328P at 16MHz because that matches Arduino-compatible programming and the user-provided blueprint. The 8MB flash is a 3.3V SPI NOR, so Rev-A includes 3.3V regulation and level shifting.

The highest-risk electrical boundary is the 5V MCU to 3.3V flash interface. The design uses a 74LVC125-style buffer for 5V-to-3.3V signals and direct 3.3V MISO return into the MCU. For commercial Rev-B, move both devices to one 3.3V domain or use a MCU with native 3.3V operation at the required speed.

## Firmware design

The firmware should not expose raw flash writes directly. Use a small object-store protocol:

- `IDENTIFY`
- `READ_OBJECT`
- `BEGIN_WRITE`
- `WRITE_PAGE`
- `COMMIT_OBJECT`
- `ABORT_WRITE`
- `VERIFY_OBJECT`
- `LOCK_REGION`
- `READ_MANIFEST`

Every object should carry:

- object ID
- generation number
- size
- CRC32
- optional SHA-256 from host side
- write state
- monotonic manifest slot

## Storage layout

```text
0x000000 - 0x003FFF   Boot manifest A
0x004000 - 0x007FFF   Boot manifest B
0x008000 - 0x00FFFF   Device identity and config
0x010000 - 0x01FFFF   Firmware/package metadata
0x020000 - 0x77FFFF   Object storage region
0x780000 - 0x7DFFFF   Recovery / last-known-good package
0x7E0000 - 0x7FFFFF   Audit ring / diagnostic trace
```

## Mechanical design

The included enclosure is a snap-fit cartridge shell with:

- bottom tray
- lid
- PCB standoffs
- USB/FTDI service opening
- tamper-label flats
- 0.3mm nominal clearance around PCB
- 1.6mm nominal PCB thickness allowance

The included STEP files are reference solids. The OpenSCAD file is the editable parametric source for enclosure iteration.

## Security model

This is not tamper-proof. It is tamper-evident and local-first.

Security controls:

- no network interface on cartridge
- host utility uses explicit serial protocol
- firmware rejects malformed commands
- object writes are transactional
- dual manifest slots avoid power-loss corruption
- optional write-protect pin policy
- enclosure uses tamper label zones

## Main risks

1. ATmega328P lifecycle: not ideal for a new commercial product.
2. 5V/3.3V signal boundary: must be tested carefully.
3. SPI flash endurance: use wear-aware manifest/object writes.
4. Security overclaim: do not advertise as unbreakable.
5. Enclosure tolerances: must be tested on the exact printer/material.
6. Certification: USB productizing requires EMC/ESD review.
7. FTDI/header choice: consumer product should move from header to onboard USB bridge.

## Product recommendation

Build Rev-A as a lab/EVT cartridge. For Rev-B productization, migrate to:

- 3.3V MCU domain.
- USB-C onboard bridge.
- ESD protection.
- hardware write-protect jumper or switch.
- signed manifest policy.
- factory test pads.
- injection-moulding-ready enclosure.
