# Air-Gapped 8MB Storage Module — Rev-A CAD Implementation Bundle

This bundle converts the research blueprint into a **Rev-A EVT/CAD implementation baseline**.
It includes editable KiCad project files, a draft 2-layer board, preliminary Gerber/Excellon manufacturing outputs, STEP enclosure reference solids, a parametric OpenSCAD enclosure, firmware scaffolds, host validation scripts, BOM, risk controls, and bring-up checklists.

## Important production warning

This bundle is enough to start CAD review, breadboard/EVT build planning, KiCad cleanup, and enclosure iteration. It is **not safe to send directly to a PCB factory without review**.

Before ordering PCBs:

1. Open `kicad/airgap8mb_revA.kicad_pro` in KiCad.
2. Run ERC on the schematic.
3. Run DRC on the PCB.
4. Verify every footprint against the exact ordering part number.
5. Confirm USB/FTDI interface choice.
6. Confirm the enclosure STEP against real connector height and PCB thickness.
7. Generate final Gerbers from KiCad on your machine.

## Rev-A design choice

The CAD follows the user-specified architecture:

- ATmega328P-PU DIP-28 at 5V / 16MHz.
- W25Q64JV-class 8MB SPI NOR at 3.3V.
- 3.3V regulator for flash and level shifter.
- FTDI-style 6-pin serial programming header with DTR auto-reset.
- SPI level shifting from 5V MCU to 3.3V flash.
- Tamper-evident snap enclosure reference model.

For a commercial Rev-B, consider moving the MCU and flash to a common 3.3V domain, or replacing ATmega328P with a newer recommended MCU. Microchip currently marks ATmega328P as **not recommended for new designs** on its product page.

## Folder map

```text
bom/                  BOM CSV and sourcing notes
kicad/                Editable KiCad project, schematic, and PCB
a manufacturing/      Preliminary Gerbers and drill files generated from this Rev-A geometry
mechanical/           STEP, STL, and OpenSCAD enclosure assets
firmware/             AVR flash object-store scaffold
host_tools/           Python host validation and serial test script
validation/           EVT, DFM, PCBA, and bring-up gates
schemas/              Manifest and cartridge identity JSON schemas
sources/              Source references and assumptions ledger
```

## Go / No-Go

**Go for prototype CAD implementation.**

**No-Go for direct production release.** The design needs ERC/DRC, footprint verification, PCBA DFM review, firmware fault-injection, flash endurance tests, and enclosure tolerance validation before sale.
