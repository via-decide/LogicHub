# DFM Checklist

## PCB

- Minimum trace/space entered from selected fab.
- Annular ring rules checked.
- Mounting hole keepouts checked.
- FTDI header clearance checked.
- Crystal kept close to XTAL pins.
- Flash decoupling capacitor placed close to VCC/GND.
- Level shifter between MCU and flash placed close to flash.
- Test pads accessible in enclosure.

## Enclosure

- PCB fit clearance verified with printed coupon.
- Header/service opening fits actual connector.
- Snap-fit does not overstress printed material.
- Tamper label flat visible and usable.
- Standoff height matches PCB thickness and solder-side clearance.
- No component collision with lid.
