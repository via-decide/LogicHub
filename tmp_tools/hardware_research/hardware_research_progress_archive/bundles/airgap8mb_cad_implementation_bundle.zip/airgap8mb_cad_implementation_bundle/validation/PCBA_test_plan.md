# PCBA Test Plan

## Fixture signals

- 5V input
- GND
- 3V3 output
- RESET
- UART TX/RX
- SPI MOSI/MISO/SCK/CS
- FLASH WP#/HOLD#

## Factory test sequence

1. Barcode scan / serial assignment.
2. Power short test.
3. 5V current draw test.
4. 3V3 rail tolerance test.
5. ISP connectivity test.
6. Firmware flash.
7. FTDI serial loop test.
8. Flash JEDEC ID read.
9. Scratch sector erase/program/read/verify.
10. Manifest A/B write and recovery test.
11. Tamper label application.
12. Final enclosure fit check.
