# EVT Test Plan

## Electrical bring-up

1. Visual inspection under magnification.
2. Continuity check: 5V to GND, 3V3 to GND.
3. Power from current-limited bench supply at 5V / 100mA limit.
4. Verify 3.3V regulator output.
5. Verify RESET pull-up and DTR pulse.
6. Verify 16MHz clock at XTAL pins.
7. Program bootloader through ISP.
8. Program firmware through FTDI.
9. Read W25Q64 JEDEC ID.
10. Read/write/erase one scratch sector.

## Storage reliability

- 1,000 write/verify cycles on scratch sector.
- Power-cut during page write.
- Power-cut during manifest commit.
- CRC mismatch detection.
- dual-manifest fallback.

## Exit criteria

- no shorts
- stable 5V and 3.3V rails
- bootloader flashing passes
- flash ID stable across 100 resets
- no corrupted active manifest after power-cut tests
