// Air-Gapped 8MB Cartridge Enclosure Rev-A
// Parametric OpenSCAD source for enclosure CAD implementation.
// Units: mm

$fn = 48;

pcb_l = 70;
pcb_w = 40;
pcb_t = 1.6;
clearance = 0.35;
wall = 2.0;
bottom_h = 9;
lid_h = 5;
outer_l = pcb_l + 2*(wall + clearance);
outer_w = pcb_w + 2*(wall + clearance);
corner_r = 2.0;

module rounded_box(l,w,h,r){
  hull(){
    translate([r,r,0]) cylinder(h=h,r=r);
    translate([l-r,r,0]) cylinder(h=h,r=r);
    translate([r,w-r,0]) cylinder(h=h,r=r);
    translate([l-r,w-r,0]) cylinder(h=h,r=r);
  }
}

module pcb(){
  color("green") translate([wall+clearance, wall+clearance, bottom_h-2]) cube([pcb_l, pcb_w, pcb_t]);
}

module bottom_shell(){
  difference(){
    rounded_box(outer_l, outer_w, bottom_h, corner_r);
    translate([wall, wall, 1.4]) rounded_box(outer_l-2*wall, outer_w-2*wall, bottom_h, 1.2);
    // FTDI / USB service opening
    translate([-1, 7, 3]) cube([wall+2, 18, 5]);
  }
  // PCB ledges
  translate([wall+clearance, wall+clearance, bottom_h-2.2]) cube([pcb_l, 1.2, 1.2]);
  translate([wall+clearance, wall+clearance+pcb_w-1.2, bottom_h-2.2]) cube([pcb_l, 1.2, 1.2]);
  // standoffs near mounting holes
  for(x=[wall+clearance+3, wall+clearance+pcb_l-3])
    for(y=[wall+clearance+3, wall+clearance+pcb_w-3])
      translate([x,y,1.4]) difference(){ cylinder(h=bottom_h-3.0, r=2.4); cylinder(h=bottom_h, r=1.25); }
  // tamper label flat
  translate([outer_l/2-12, -0.2, 2]) cube([24,0.6,5]);
}

module lid(){
  translate([0,0,bottom_h+0.2]) difference(){
    rounded_box(outer_l, outer_w, lid_h, corner_r);
    translate([wall+0.25, wall+0.25, -0.1]) rounded_box(outer_l-2*(wall+0.25), outer_w-2*(wall+0.25), lid_h, 1.0);
  }
  // snap lip
  translate([wall+0.4, wall+0.4, bottom_h-0.8]) rounded_box(outer_l-2*(wall+0.4), outer_w-2*(wall+0.4), 1.0, 1.0);
}

bottom_shell();
pcb();
lid();
