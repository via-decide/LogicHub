# Enclosure Design Notes

## Included assets

- `step/airgap8mb_enclosure_bottom_reference.step`
- `step/airgap8mb_enclosure_lid_reference.step`
- `step/airgap8mb_board_envelope.step`
- `scad/airgap8mb_enclosure.scad`
- `stl/*.stl`

## Mechanical baseline

- PCB: 70mm x 40mm x 1.6mm
- Enclosure outer envelope: approximately 76mm x 46mm x 14–16mm
- Wall thickness: 2.0mm
- PCB clearance: 0.35mm per side
- Standoff holes: M2.5 reference
- Tamper label flat: front edge
- Service opening: FTDI/USB header side

## Production notes

For 3D printing, start with PETG or ABS. PLA is acceptable for fit prototypes but not for heat or durability validation.

For injection moulding, this model must be redesigned with:

- draft angles
- uniform wall thickness
- proper snap-fit stress analysis
- ejector-pin strategy
- material shrinkage
- gate and parting-line planning
- texture and label recesses
