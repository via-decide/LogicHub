#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
import time

try:
    import serial  # pyserial
except ImportError:
    serial = None


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate AirGap8MB serial flash bring-up")
    parser.add_argument("--port", required=True, help="Serial port, e.g. /dev/ttyUSB0 or COM5")
    parser.add_argument("--baud", type=int, default=115200)
    args = parser.parse_args()

    if serial is None:
        print("pyserial not installed. Install with: python -m pip install pyserial", file=sys.stderr)
        return 2

    with serial.Serial(args.port, args.baud, timeout=2) as s:
        time.sleep(2.0)
        s.reset_input_buffer()
        for cmd in [b"i", b"s", b"r"]:
            s.write(cmd)
            s.flush()
            line = s.readline().decode(errors="replace").strip()
            print(line)
            if not line.startswith("OK"):
                print(f"unexpected response to {cmd!r}", file=sys.stderr)
                return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
