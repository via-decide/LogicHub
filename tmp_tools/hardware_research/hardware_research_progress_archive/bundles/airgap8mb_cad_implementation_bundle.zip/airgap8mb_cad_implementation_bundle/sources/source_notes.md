# Source Notes and Assumptions

## Verified source-derived anchors

- ATmega328P is a 32KB Flash / 2KB SRAM / 1KB EEPROM 8-bit AVR class MCU and is currently marked not recommended for new designs by Microchip.
- W25Q64JV is a 64Mbit / 8MByte serial SPI flash operating at 2.7V–3.6V, with 256-byte pages and 4KB sectors.
- KiCad schematic and board files use S-expression formats.

## Engineering assumptions

- Board outline: 70mm x 40mm.
- PCB thickness: 1.6mm.
- Rev-A programming interface: external FTDI 6-pin serial header.
- Rev-A power input: 5V.
- Flash domain: 3.3V.
- User-requested 16MHz ATmega architecture retained for Rev-A.
- Enclosure outer envelope: approx. 76mm x 46mm x 14–16mm.

## Must verify with datasheets

- Exact package dimensions.
- Crystal load capacitor values.
- Regulator stability capacitor requirements.
- Level shifter input tolerance and edge-rate behavior.
- Flash WP#/HOLD# pull strategy.
