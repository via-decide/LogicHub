# KiCad Use Instructions

The KiCad files are generated as a Rev-A editable baseline.

## Open order

1. Open `airgap8mb_revA.kicad_pro`.
2. Open the schematic and review architecture notes.
3. Open PCB and inspect the 70mm x 40mm two-layer board.
4. Update footprints using the exact package options you will order.
5. Run ERC/DRC.
6. Regenerate Gerbers from KiCad after review.

## Known limitations

- Schematic is an architecture sheet plus explicit net map, not a fully symbol-wired production schematic.
- PCB is a routed draft with approximate footprints and traces.
- Preliminary Gerbers were generated from the same geometry by script and should be treated as draft manufacturing outputs only.
- Footprints must be checked against exact datasheets before fabrication.
