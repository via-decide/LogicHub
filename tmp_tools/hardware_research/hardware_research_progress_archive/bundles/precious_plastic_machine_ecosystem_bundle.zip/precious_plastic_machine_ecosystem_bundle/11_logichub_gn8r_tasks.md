# LogicHub / GN8R Task Blocks

/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 240
version: 1
depends_on: none
task: Build Precious Plastic source intake. Discover machine pack files: CAD, STEP/F3D, DXF, drawings, manuals, BOM, schematics, safety notes, images, videos, and workspace docs. Hash every file and emit canonical manifest.

CAUSATION:
Open hardware without deterministic source intake becomes folklore. Same machine files must produce same evidence before fabrication.

CONVERGENCE:
$S$=source files, $H$=hashes, $M$=manifest. Constraint: same(S)->same(H,M). Every accepted file appears once.

EXECUTION_CONTRACT:
Create importer, classifier, SHA-256 manifest, source URL ledger, version ledger, license field, rejected-file diagnostics, tests.

/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 240
version: 1
depends_on: precious_plastic_source_intake_v1
task: Build machine canonical model for Precious Plastic. Represent Shredder, Injection, Extrusion, Sheetpress, Compression, motor, heater, frame, guard, electrical enclosure, BOM, process, and operator hazards.

CAUSATION:
Files alone cannot tell if a machine is safe or buildable. Need typed machine graph before validation.

CONVERGENCE:
$G$=machine graph, $B$=BOM, $R$=risk nodes. Constraint: every hazard maps to mitigation or open waiver.

EXECUTION_CONTRACT:
Define schemas, parser adapters, graph builder, BOM joiner, risk node store, manifest export, tests.

/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 240
version: 1
depends_on: precious_plastic_machine_model_v1
task: Build Precious Plastic validation evidence. Gates: source identity, BOM completeness, fabrication readiness, electrical safety, guarding, thermal safety, material batch QC, process run receipt, product QC.

CAUSATION:
Machine output is only valuable if batch/material/process evidence survives review.

CONVERGENCE:
$E$=evidence receipts, $Q$=quality gates. Constraint: release allowed only when required gates pass or waiver exists.

EXECUTION_CONTRACT:
Create receipt schema, gate engine, CSV/JSON export, evidence folder layout, validation CLI, failing fixtures, docs.
