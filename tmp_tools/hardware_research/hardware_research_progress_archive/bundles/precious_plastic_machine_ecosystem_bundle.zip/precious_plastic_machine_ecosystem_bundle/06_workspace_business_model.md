# Workspace and Business Model

## Workspace options

| Workspace | Revenue | Complexity | First-sellable output |
|---|---|---|---|
| Collection Point | Waste collection, sorting service | Low | Clean sorted plastic |
| Shredder Workspace | Flake production | Medium | Sorted flakes by colour/type |
| Injection Workspace | Small product production | Medium | Tokens, hooks, clips, educational items |
| Extrusion Workspace | Profiles/bricks/beams | High | Beams, rods, bricks, moulded profiles |
| Sheetpress Workspace | Sheet production | High | Boards, panels, signs, furniture material |
| Machine Shop | Machine building/support | Very high | Machine builds, spare parts, repairs |
| Community Point | Workshops/training | Medium | Paid workshops and community recycling events |
| Mix Workspace | Combined pilot lab | High | Product experiments and demonstrations |

## Recommended India/Kutch path

1. Start as **Community + Injection** pilot.
2. Add verified Shredder or partner with shredder operator.
3. Build local products for schools, NGOs, cafes, farms, makers, and municipalities.
4. Add Sheetpress only after material supply and sales are proven.
5. Add machine-building services only after safety documentation and supplier network are ready.

## Monetisation routes

- Paid recycling workshops.
- School/college machine demos.
- Moulded products.
- Recycled-plastic sheet/panel products.
- Custom logo tokens and signage.
- Material sorting and flake supply.
- Machine maintenance and spare-part supply.
- LogicHub verification reports for makers and machine shops.

## Avoid early

- Selling uncertified machines.
- Promising structural material performance.
- Food-contact packaging.
- Products for children under safety-regulated categories.
- Operating unknown fumes indoors.
