# Precious Plastic Ecosystem Architecture Map

## Operating model

```mermaid
flowchart TD
  A[Collection Point] --> B[Sorting + Washing]
  B --> C[Shredder Workspace]
  C --> D[Flake Inventory]
  D --> E[Injection Workspace]
  D --> F[Extrusion Workspace]
  D --> G[Sheetpress Workspace]
  D --> H[Mix Workspace]
  E --> I[Small products]
  F --> J[Beams / bricks / profiles]
  G --> K[Sheets / panels]
  H --> L[Experiments / education]
  I --> M[Bazar / local sales]
  J --> M
  K --> M
  L --> N[Community how-to]
  M --> O[Receipts + batch evidence]
```

## Machine graph

```mermaid
graph LR
  Sorter[Material sorting table]
  Washer[Wash + dry station]
  Shredder[Shredder / Shredder Pro]
  Sieve[Flake classification]
  Injection[Injection]
  Extruder[Extrusion / Extrusion Pro]
  Sheetpress[Sheetpress]
  Compression[Compression]
  Moulds[Moulds + dies]
  QC[Quality control]

  Sorter --> Washer --> Shredder --> Sieve
  Sieve --> Injection --> Moulds --> QC
  Sieve --> Extruder --> Moulds --> QC
  Sieve --> Sheetpress --> QC
  Sieve --> Compression --> QC
```

## LogicHub canonical model

```mermaid
flowchart LR
  Source[Official/community source files] --> Hash[SHA-256 manifest]
  Hash --> Parse[CAD/BOM/DXF/PDF parse]
  Parse --> Machine[Machine manifest]
  Machine --> Risk[Safety risk model]
  Risk --> Validation[Commissioning checklist]
  Validation --> Evidence[Evidence receipts]
  Evidence --> Release[Build release / supplier pack]
```

## Data entities

- `MachineProject`: name, source URL, version, machine family, author, license.
- `SourceFile`: path, SHA-256, MIME/type, source URL, retrieval timestamp.
- `ManufacturingFile`: CAD, DXF, STEP/F3D, PDF, electrical, BOM, firmware/config.
- `SafetyRequirement`: hazard, mitigation, verification evidence.
- `MaterialBatch`: polymer type, colour, source, contamination notes, drying record.
- `ProcessRun`: machine, operator, temperature, time, motor/load, output weight.
- `ProductBatch`: mould/die/sheet ID, material batch, QC evidence, sale status.
