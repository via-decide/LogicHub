# Bibliography and Source Notes

- [S001] Precious Plastic Basic Machines — https://www.preciousplastic.com/solutions/machines/basic — official overview. Notes: CC BY-SA statement; Shredder, Extrusion, Injection, Compression technical data.
- [S002] Precious Plastic Pro Machines — https://www.preciousplastic.com/solutions/machines/pro — official overview. Notes: Shredder Pro, Extrusion Pro, Sheetpress technical data and open-source statement.
- [S003] Precious Plastic Toolbox - Build — https://onearmy.github.io/academy/build — official academy/toolbox. Notes: Machine families, build pack concept, machine fundamentals and accessibility framing.
- [S004] Precious Plastic Community - Download Kit — https://community.preciousplastic.com/library/download-kit — official community library. Notes: Starterkit and workspace model; ecosystem roles; how-to contribution model.
- [S005] Precious Plastic Community - Shredder 2.1 — https://community.preciousplastic.com/library/shredder-21 — official/community machine how-to. Notes: Legacy shredder file-download item; update path toward newer SHR 3.3.
- [S006] Precious Plastic Community - Shredder Pro 2.0 — https://community.preciousplastic.com/library/shrpro---20 — official/community pro machine how-to. Notes: CAD/STEP/F3D, DXF, blueprint, schematics and BOM download-pack description; safety-skills requirements.
- [S007] CPCB Plastic Waste Management Portal — https://pwm.cpcb.gov.in/ — India regulatory portal. Notes: Plastic Waste Management Rules and EPR registration references.
- [S008] CPCB EPR Portal for Plastic Packaging — https://eprplastic.cpcb.gov.in/ — India regulatory portal. Notes: EPR obligations for producers/importers/brand owners and plastic waste processing.
- [S009] BIS Scheme-X / machinery safety product information — https://www.bis.gov.in/scheme-x-certification/product-specific-information/?lang=en — India machinery safety source. Notes: Current India machinery/electrical safety certification intake source; verify applicability before selling machinery.
