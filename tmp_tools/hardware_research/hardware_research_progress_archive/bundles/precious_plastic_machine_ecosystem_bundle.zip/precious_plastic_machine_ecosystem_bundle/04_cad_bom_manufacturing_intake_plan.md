# CAD, BOM, Manufacturing and Source Intake Plan

## Goal

Create a deterministic manufacturing source bundle for each chosen Precious Plastic machine.

## Intake steps

1. Download machine pack from the official Community/Academy page.
2. Record source URL, page title, author, page edited date, and download date.
3. Unzip without modifying original bytes.
4. Hash every file with SHA-256.
5. Classify files by type:
   - CAD: `.step`, `.stp`, `.f3d`, `.f3z`, `.sldprt`, `.sldasm`, `.stl`.
   - Fabrication: `.dxf`, `.dwg`, `.svg`, `.pdf` drawings.
   - Electrical: schematics, wiring diagrams, VFD settings, control panel diagrams.
   - BOM: `.csv`, `.xlsx`, `.ods`, `.pdf` tables.
   - Manuals: assembly, run, maintenance, safety.
   - Media: photos/videos used as assembly evidence.
6. Create `machine_manifest.json` for each machine.
7. Run completeness gate.
8. Freeze a `revA-source-intake` tag before fabrication.

## Completeness gates

### Gate A — source identity

- Machine name present.
- Machine version present.
- Download URL present.
- License present.
- Source hash manifest complete.

### Gate B — fabrication readiness

- CAD model present.
- Drawing/blueprint present.
- Laser-cut DXF or part drawings present when required.
- BOM present.
- Critical part dimensions present.
- Electrical schematic present for motor/heater/control machines.
- Assembly manual present.

### Gate C — safety readiness

- Emergency stop design.
- Guarding for rotating blades/belts/chains.
- Electrical enclosure and earthing plan.
- Thermal over-temperature plan.
- Ventilation/fume plan.
- PPE and operator procedure.
- Maintenance lockout plan.

## Output folders

```text
precious-plastic-intake/
  machines/
    shredder-pro-2.0/
      original-download/
      normalized/
      manifests/
      validation/
    injection-basic/
    sheetpress-v4/
  shared/
    suppliers/
    material-standards/
    safety-standards/
  evidence/
    file_hashes.csv
    source_manifest.csv
```

## Non-negotiable rule

Never fabricate from a file whose source URL, exact revision, license, SHA-256, and machine-version mapping are unknown.
