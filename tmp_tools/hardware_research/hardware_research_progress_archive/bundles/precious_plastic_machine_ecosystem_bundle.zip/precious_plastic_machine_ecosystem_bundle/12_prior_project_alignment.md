# Prior Project Alignment

## 8MB air-gapped storage module

Use the 8MB module concept as a local receipt cartridge for plastic batches, machine settings, source manifests, and product provenance. It fits the evidence layer, not machine control.

## Drone CAD bundle

Drone work taught the same rule: CAD-looking files are not equivalent to flight-safe products. Precious Plastic requires the same discipline for rotating/heated/high-power machines.

## Pupper V3 and robotics bundles

Pupper showed ROS/control-stack complexity. Precious Plastic is mechanically simpler but safety-critical because the hazards are physical: blades, heat, electricity, fumes, and heavy moving assemblies.

## FarmBot

FarmBot and Precious Plastic both map well to LogicHub as open-source hardware/software ecosystems. FarmBot is agriculture automation; Precious Plastic is circular manufacturing. Both need source intake, BOM normalization, and fabrication evidence.

## OpenFlexure

OpenFlexure emphasizes precision, optics, and scientific validation. Precious Plastic emphasizes process variability, material classification, and operator safety.

## SatNOGS

SatNOGS showed distributed network/operations. Precious Plastic has a similar network logic: local workspaces, community how-tos, Bazar, maps, and shared source packs.

## Voron

Voron is the closest mechanical analogy. Both need part lists, CAD/STL/DXF/source intake, supplier sourcing, commissioning, and careful mechanical assembly.

## OpenEVSE

OpenEVSE is high-voltage EV infrastructure. Precious Plastic has lower regulatory formality in some uses but still has comparable electrical and safety-risk requirements when selling machines.

## OpenMV + OpenIPC

Vision can be added later for flake sorting, colour classification, machine monitoring, quality inspection, and evidence capture.

## BeagleV-Fire / Milk-V Duo

RISC-V/edge devices can serve as offline machine monitors, vibration loggers, temperature loggers, or local dashboards for a Precious Plastic workspace.
