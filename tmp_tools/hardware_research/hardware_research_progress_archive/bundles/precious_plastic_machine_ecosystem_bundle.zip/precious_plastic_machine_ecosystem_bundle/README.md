# Precious Plastic Machine Ecosystem Research Bundle

Generated: 2026-07-30T13:16:02+05:30

This bundle studies Precious Plastic as an open-source machine ecosystem for distributed plastic recycling, small-factory manufacturing, education, and local circular-economy products.

## Contents

- `01_deep_research_report.md` — full research report and Go/No-Go verdict.
- `02_ecosystem_architecture_map.md` — machines, workspaces, material flow, source flow, and LogicHub-style graph.
- `03_machine_family_map.md` — basic and pro machines with technical data and use cases.
- `04_cad_bom_manufacturing_intake_plan.md` — how to collect and verify CAD, DXF, STEP, PDF drawings, electrical schematics, BOM, and manuals.
- `05_materials_process_quality_notes.md` — polymer sorting, drying, contamination, process control, QC and failure modes.
- `06_workspace_business_model.md` — workspace roles, product routes, service model, monetisation.
- `07_india_productization_strategy.md` — India/Kutch/Gujarat-oriented rollout plan.
- `08_safety_compliance_risk_register.csv` — mechanical, electrical, thermal, fire, dust/fume, and business risks.
- `09_validation_and_commissioning_plan.md` — commissioning gates and acceptance test plan.
- `10_license_and_commercialization.md` — CC BY-SA / attribution / share-alike implications.
- `11_logichub_gn8r_tasks.md` — compact task blocks for source intake and machine validation.
- `12_prior_project_alignment.md` — relationship to FarmBot, OpenFlexure, SatNOGS, Voron, OpenEVSE, OpenMV/OpenIPC, RISC-V edge, drone, Pupper, and 8MB module bundles.
- `13_bibliography_and_sources.md` — source list and retrieval notes.
- `data/reference_machine_matrix.csv` — machine matrix for source-intake and planning.
- `templates/` — source, BOM, machine, safety, and validation intake templates.
- `schemas/` — JSON schemas for source manifest, machine manifest, and test receipt.
- `scripts/hash_sources.py` — local file hasher for downloaded CAD/source files.
- `source_manifest.csv` and `file_hashes.csv` — generated bundle evidence.

## Important limitation

This ZIP does not embed official Precious Plastic download-pack CAD, DXF, STEP/F3D, Google Drive assets, schematics, or manuals. Those should be downloaded directly from the official Precious Plastic Community/Academy pages, pinned by exact URL/version/date, hashed, and recorded in `source_manifest.csv` before fabrication or resale.

## Recommended first implementation path

Start with a receive/process-only source-intake project, then build a **Shredder Workspace** or **Injection Workspace** only after machine safety review. For commercial output, the safer first product is recycled-plastic sheet/object production and local education workshops, not machine resale.
