# Validation and Commissioning Plan

## Stage 0 — source validation

- All downloaded files hashed.
- Machine version identified.
- License recorded.
- CAD/BOM/manual completeness checked.
- No mixed-version documents without explicit mapping.

## Stage 1 — supplier review

- Laser-cut parts reviewed by local fabricator.
- Shaft, blade, bearing and frame tolerances reviewed.
- Motor/VFD/contactors reviewed by qualified electrician.
- Electrical enclosure and earthing plan reviewed.
- Guarding and E-stop layout reviewed.

## Stage 2 — dry build

- Assemble frame without power.
- Check alignment and bearing preload.
- Check all guards and panels.
- Rotate shafts by hand when safe.
- Check hopper/plunger clearance.
- Verify no pinch points exposed.

## Stage 3 — electrical commissioning

- Insulation/earth continuity check.
- E-stop check.
- Overload and thermal protection check.
- VFD settings locked and documented.
- Motor direction verified without material.
- Heater SSR/temperature control tested with safe supervision.

## Stage 4 — no-load run

- Run at low speed/no-load.
- Log vibration, heat, noise, current.
- Confirm E-stop stops safely.
- Confirm restart lockout behavior.
- Check fasteners after first run.

## Stage 5 — low-risk material run

- Use known clean HDPE/PP test pieces.
- Feed slowly.
- Record current, jams, output, flake size, temperature.
- Stop immediately on abnormal noise/heat/vibration.

## Stage 6 — process qualification

- Run 5 controlled batches.
- Track input weight, output weight, scrap/rejects.
- Measure product dimensions.
- Create QC coupons.
- Record defects and corrective actions.

## Stage 7 — release gate

Machine/product may only be released after:

- guarding evidence.
- electrical safety checklist.
- material SOP.
- maintenance SOP.
- operator training record.
- emergency procedure.
- process receipts.
- first batch QC report.
