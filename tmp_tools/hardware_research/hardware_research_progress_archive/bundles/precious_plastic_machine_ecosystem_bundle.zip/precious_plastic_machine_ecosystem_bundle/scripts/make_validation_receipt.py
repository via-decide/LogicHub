#!/usr/bin/env python3
import json, datetime, sys
receipt = {
  "receipt_id": "PP-RECEIPT-0001",
  "machine": sys.argv[1] if len(sys.argv) > 1 else "shredder-pro-2.0",
  "test_name": "source-intake-completeness",
  "operator": "TBD",
  "result": "blocked",
  "evidence": ["source_manifest.csv", "file_hashes.csv"],
  "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "notes": "Replace blocked with pass only after official machine pack files are downloaded, hashed, and reviewed."
}
print(json.dumps(receipt, indent=2))
