#!/usr/bin/env python3
"""Hash downloaded Precious Plastic machine source files.
Usage: python scripts/hash_sources.py /path/to/downloaded-machine-pack > file_hashes.csv
"""
from pathlib import Path
import hashlib, csv, sys
root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')
writer = csv.writer(sys.stdout)
writer.writerow(['relative_path','sha256','bytes'])
for p in sorted(root.rglob('*')):
    if p.is_file():
        h = hashlib.sha256(p.read_bytes()).hexdigest()
        writer.writerow([str(p.relative_to(root)), h, p.stat().st_size])
