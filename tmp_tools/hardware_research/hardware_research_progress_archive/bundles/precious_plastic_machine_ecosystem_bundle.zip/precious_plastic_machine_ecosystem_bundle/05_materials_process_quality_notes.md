# Materials, Process and Quality Notes

## Feedstock control

Precious Plastic machines turn plastic waste into new objects, but the limiting factor is not only machine design. It is feedstock consistency.

## Batch classification

Each incoming batch should be logged with:

- material type: HDPE, PP, PET, PLA, ABS, PS, mixed, unknown.
- colour category.
- source category: bottle caps, containers, 3D-print scrap, household waste, industrial scrap.
- cleaning status.
- drying status.
- contamination notes.
- operator confidence.

## Process hazards by plastic type

| Plastic | Useful route | Main caution |
|---|---|---|
| HDPE | Injection, sheetpress, beams | Warpage/shrinkage; sort by colour. |
| PP | Injection, sheetpress | Lower surface energy; warpage; contamination sensitivity. |
| PET | Sheet/experiment only unless dried well | Moisture and degradation; avoid food-contact claims. |
| PLA | 3D-print scrap experiments | Moisture and heat degradation. |
| ABS | Controlled experiments | Fumes; ventilation required. |
| PVC | Avoid in general Precious Plastic workflow | Hazardous fumes/chlorine risk when heated. |
| Unknown/mixed | Shred-only or non-safety experiments | Unpredictable properties and fumes. |

## QC evidence

- Flake size distribution photos and sieve notes.
- Moisture/drying log.
- Temperature profile.
- First-shot/first-sheet images.
- Defect log.
- Coupon bend/impact/scratch test.
- Product weight and dimensions.
- Regrind percentage.
- Repeatability across 5, 10, 50, 100 cycles.

## Common defects

| Defect | Likely cause | Corrective action |
|---|---|---|
| Bubbles | Moisture/contamination/overheating | Dry material, reduce dwell, improve sorting. |
| Poor fusion | Low temperature/pressure/time | Increase heat soak or pressure; improve flake packing. |
| Burn marks | Overheating/degraded plastic | Lower setpoint; purge material; sort feedstock. |
| Weak part | Mixed polymer or poor melt | Improve material sorting; test smaller batch. |
| Nozzle clog | Oversized flakes/contamination | Sieve flakes; clean barrel/nozzle. |
| Warping | Cooling/shrinkage | Adjust mould cooling and material type. |

## Product design rule

Design products around recycled plastic variability. Prefer thick, tolerant, non-critical shapes over thin, precision, safety-critical, or food-contact products.
