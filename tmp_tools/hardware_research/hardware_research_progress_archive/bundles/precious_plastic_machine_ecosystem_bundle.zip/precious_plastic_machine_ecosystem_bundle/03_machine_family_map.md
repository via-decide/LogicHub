# Precious Plastic Machine Family Map

## Reference machine matrix

| Machine | Role | Best first use | Main hazards | Product outputs |
|---|---|---|---|---|
| Shredder | Reduces waste into flakes | First source-control machine | Blades, high torque, kickback, electrical | Flakes by type/colour/size |
| Extrusion | Continuous melt forming | Beams, bricks, profiles | Hot barrel, motor torque, fumes, fire | Beams, bricks, lines, profile forms |
| Injection | Batch moulding | Small repeatable products | Hot barrel/mould, manual pressure, burns | Tokens, hooks, clips, tiles, handles |
| Compression | Oven + car-jack moulding | Historical/prototyping only | Hot oven, pressure, fumes | Large moulded prototypes |
| Shredder Pro | Higher-throughput flake production | Serious workspace after safety review | Double shaft, 340 kg machine, 400 V, VFD/motor | 50 kg/h class flakes depending on size |
| Extrusion Pro | Higher-output profile machine | Bricks/beams business | 5 kW heating/drive, 400 V, fumes | Beams, bricks, mould-fed profiles |
| Sheetpress | Large sheet production | Best visible product path | Hydraulic press, 15 kW, hot plates, heavy mass | 1 m x 1 m recycled sheets |

## Recommended selection logic

### Lowest complexity

- Injection workspace with purchased flakes or small verified shredder access.
- Educational product and mould-design focus.

### Best visible market output

- Sheetpress workspace plus CNC/router partner.
- Sell panels, table tops, boards, signage, and furniture components.

### Best upstream business

- Shredder workspace.
- Sell sorted, washed, colour/type-classified flakes to other makers.

### Best construction-material route

- Extrusion Pro for beams/bricks, but only after drying, sorting, machine-safety, and product testing are mature.

## Machine version caution

The Precious Plastic ecosystem contains older and newer machine versions plus community variants. Treat every file pack as versioned evidence. Do not merge V2, V3, V4, Pro, and community files into a single manufacturing pack without explicit version mapping.
