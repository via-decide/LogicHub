# License and Commercialization Notes

## Source license posture

Current official Precious Plastic machine pages state that knowledge/material is available under **Creative Commons Attribution-ShareAlike International 4.0**. Treat this as a share-alike hardware documentation constraint until a file-level license inventory proves otherwise.

## Commercial implication

You can generally study, share, adapt, build and commercialize under CC BY-SA terms, but you must preserve attribution and share adapted material under compatible terms where required. This is not legal advice.

## What needs file-level review

- CAD files.
- DXF laser-cut files.
- PDF drawings/manuals.
- photos/videos used in documentation.
- electrical schematics.
- BOM spreadsheets.
- community-contributed machine variants.
- third-party motor/VFD/controller datasheets.
- branding, logo and graphic assets.

## Safe commercialization path

- Sell services, training, parts fabrication, and products made from recycled plastic.
- Attribute Precious Plastic and machine contributors.
- Release any modified machine CAD/manual updates under appropriate share-alike terms.
- Do not use Precious Plastic branding in a way that implies official endorsement.
- Do not represent community designs as certified industrial machinery unless independently certified.

## Risky commercialization path

- Selling machines as ready-to-use industrial equipment without safety certification.
- Removing attribution.
- Closing modified CAD that must remain share-alike.
- Using official/community logos as your own brand.
- Claiming food-contact, child-safe, structural, electrical-insulation, or medical-grade properties without testing.
