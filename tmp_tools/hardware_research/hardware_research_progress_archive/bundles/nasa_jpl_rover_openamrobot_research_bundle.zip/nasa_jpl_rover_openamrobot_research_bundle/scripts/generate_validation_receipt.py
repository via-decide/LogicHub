#!/usr/bin/env python3
import json, uuid, datetime
from pathlib import Path
receipt = {
  "receipt_id": "MR-" + uuid.uuid4().hex[:12],
  "platform": "openamrobot",
  "revision": "",
  "operator": "",
  "date_time": datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "source_manifest_hash": "",
  "test_name": "",
  "preconditions": [],
  "commands": [],
  "measurements": {},
  "pass_fail": "not-run",
  "risks_found": [],
  "next_action": ""
}
Path("validation_receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
print("validation_receipt.json")
