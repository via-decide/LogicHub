#!/usr/bin/env python3
from pathlib import Path
import hashlib, csv, sys
root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("hashes.csv")
rows = []
for path in sorted(root.rglob("*")):
    if path.is_file():
        rows.append({"path": str(path.relative_to(root)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size})
with out.open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=["path","sha256","bytes"])
    w.writeheader()
    w.writerows(rows)
print(f"Wrote {len(rows)} hashes to {out}")
