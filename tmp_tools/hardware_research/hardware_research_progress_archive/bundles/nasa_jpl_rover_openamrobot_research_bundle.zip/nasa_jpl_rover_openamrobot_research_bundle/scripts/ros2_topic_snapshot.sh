#!/usr/bin/env bash
set -euo pipefail
mkdir -p evidence
date --iso-8601=seconds > evidence/timestamp.txt
ros2 topic list > evidence/topic_list.txt
ros2 node list > evidence/node_list.txt
ros2 param list > evidence/param_list.txt || true
echo "Snapshot written to evidence/"
