# CAD, BOM, and Manufacturing Intake Plan

## Intake rule

Every upstream asset must be tracked by:

```text
source_url
repository
commit_or_release
file_path
file_type
license
sha256
owner
derived_from
verification_status
```

## NASA JPL OSR intake

Collect:
- Onshape browser model link and exported STEP assemblies.
- Parts list from `parts_list/`.
- Wiring docs from `electrical/wiring/`.
- PCB docs from `electrical/pcb/`.
- Mechanical docs from `mechanical/`.
- Rover code from `osr-rover-code`.

Normalize:
- COTS parts.
- fabricated parts.
- 3D printed/laser cut parts.
- motors/controllers.
- battery/power chain.
- wiring harnesses.

## OpenAMRobot intake

Collect:
- official `OpenAMRobot-v0.0.1-source.zip`.
- `MANIFEST.json`.
- `checksums.sha256`.
- hardware CAD/STEP/SolidWorks/DXF/PDF files.
- electrical and mechanical BOMs.
- firmware overlay files.
- ROS 2 packages.
- UI source.
- documentation.

## Manufacturing-readiness grades

| Grade | Meaning |
|---|---|
| G0 | link-only source |
| G1 | source downloaded and hashed |
| G2 | CAD/BOM parsed |
| G3 | engineering review done |
| G4 | supplier package generated |
| G5 | first article built |
| G6 | validation passed |
| G7 | repeatable production pack |

This ZIP is a **G0/G1 research and intake bundle**, not a fabrication pack.
