# India Productization Strategy

## Product A: Rover Engineering Lab

Base: NASA JPL OSR.

Offer:
- source-intake report
- BOM localization matrix
- wiring harness kit
- classroom build plan
- terrain test plan
- teacher guide
- LogicHub project dashboard

## Product B: ROS 2 AMR Simulation and Bring-up Lab

Base: OpenAMRobot.

Offer:
- Docker simulation setup
- ROS 2 Jazzy course
- Nav2 + SLAM + docking experiments
- browser UI demo
- safety retrofit BOM
- supervised physical bring-up

## Product C: Hardware Source-Intake Service

Base: LogicHub/Hanuman.solutions.

Offer:
- CAD/BOM/license ingest
- missing-source detection
- safety blocker detection
- supplier quote pack
- validation receipts

## Localize first

- fasteners
- plates/brackets after CAD review
- wiring harnesses
- printed covers
- assembly jigs
- documentation
- packaging

## Do not casually localize

- batteries and chargers
- motors and drivers
- encoders
- LiDAR
- camera modules
- E-stop and fusing parts
- power converters
- compute boards

## Monetization ladder

| Tier | Offer |
|---|---|
| T1 | digital research bundle |
| T2 | online simulation workshop |
| T3 | build-planning consultation |
| T4 | parts sourcing and BOM localization |
| T5 | supervised education kit |
| T6 | campus robotics lab |
| T7 | SME AMR pilot safety consulting |
