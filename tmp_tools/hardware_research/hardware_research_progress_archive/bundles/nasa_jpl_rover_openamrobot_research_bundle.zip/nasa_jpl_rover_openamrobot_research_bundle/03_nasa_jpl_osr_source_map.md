# NASA JPL Open Source Rover Source Map

## Primary sources

| Source | Purpose | Priority |
|---|---|---|
| `nasa-jpl/open-source-rover` | Main hardware/build/docs repository | P0 |
| `nasa-jpl/osr-rover-code` | Raspberry Pi ROS2/Python rover code | P0 |
| Onshape model linked in README | Browser-viewable 3D model | P0 |
| Parts list | BOM/procurement | P0 |
| Electrical wiring docs | Wiring harness and PCB integration | P0 |
| Mechanical docs | Assembly and mechanical source | P0 |

## Source-derived facts

- Six-wheel Mars-rover-style build.
- COTS-oriented design.
- Rocker-bogie suspension.
- Differential pivot.
- Six-wheel Ackerman steering.
- Raspberry Pi brain.
- Approximate cost in current README: about $1600.
- Aluminum structural material.
- Build roadmap: order parts, wiring, PCB/electronics, mechanical assembly, Pi/code bringup.
- Apache-2.0 license stated in README.
- OSHWA certification stated in README.

## Intake tasks

1. Pin repository commit.
2. Hash all Markdown/docs/assets downloaded.
3. Export Onshape model to STEP only after recording source URL and date.
4. Normalize parts list into BOM CSV.
5. Convert wiring docs to harness table.
6. Convert mechanical docs to assembly graph.
7. Pin `osr-rover-code`.
8. Create safety gate before powered testing.

## Validation focus

- frame squareness
- rocker-bogie free motion
- wheel contact
- steering direction
- motor direction
- battery monitoring
- low-speed motion
- field-terrain crawl
