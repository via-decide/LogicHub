# Bibliography and Sources

## jpl-osr-readme
- Project: NASA JPL Open Source Rover
- Title: JPL Open Source Rover Project README
- URL: https://github.com/nasa-jpl/open-source-rover/blob/master/README.md
- Type: GitHub README
- License/status: Apache License 2.0 per README
- Evidence used: Scaled-down six-wheel rover; COTS parts; rocker-bogie, differential pivot, 6-wheel Ackerman; Raspberry Pi brain; build roadmap.

## jpl-osr-code-readme
- Project: NASA JPL Open Source Rover
- Title: JPL Open Source Rover Code README
- URL: https://github.com/nasa-jpl/osr-rover-code/blob/main/README.md
- Type: GitHub README
- License/status: Check repository license
- Evidence used: Raspberry Pi rover-control code; ROS2 tested on Foxy; Python3; setup and bringup docs.

## jpl-news-open-source-rover
- Project: NASA JPL Open Source Rover
- Title: Students Can Now Build Their Own Rover Model
- URL: https://www.jpl.nasa.gov/news/students-can-now-build-their-own-rover-model/
- Type: NASA JPL article
- License/status: JPL/NASA web page
- Evidence used: Original public framing: students and hobbyists can build a scaled-down rover from COTS parts.

## openamrobot-discourse
- Project: OpenAMRobot
- Title: OpenAMRobot v0.0.1 announcement
- URL: https://discourse.openrobotics.org/t/openamrobot-v0-0-1-open-source-ros-2-mobile-robot-platform/56515
- Type: Open Robotics Discourse
- License/status: Community post
- Evidence used: Public product-level release; ROS 2 Jazzy; hardware/CAD/BOM/firmware/sim/Nav2/SLAM/docking/web UI/Blockly/camera/voice workflow.

## openamrobot-release
- Project: OpenAMRobot
- Title: OpenAMRobot v0.0.1 release README
- URL: https://github.com/openAMRobot/openamrobot-release/blob/main/README.md
- Type: GitHub README
- License/status: MIT/repository-specific; verify files
- Evidence used: Frozen multi-repo release archive across hardware, software, firmware, UI, interfaces, communication, and docs.

## openamrobot-hw
- Project: OpenAMRobot
- Title: OpenAMR Platform Hardware README
- URL: https://github.com/openAMRobot/openamr-platform-hw/blob/main/README.md
- Type: GitHub README
- License/status: MIT for docs/BOM; planned CERN-OHL-S-2.0 for future hardware files per README
- Evidence used: Differential-drive hardware, CAD, BOM, electrical, wiring, safety; Pi 5, Teensy 4.0, BLDC motors, LiDAR, camera.

## openamrobot-sw
- Project: OpenAMRobot
- Title: OpenAMR Platform Software README
- URL: https://github.com/openAMRobot/openamr-platform-sw/blob/main/README.md
- Type: GitHub README
- License/status: Verify per repository
- Evidence used: ROS 2 Jazzy stack; Gazebo Harmonic; Nav2; AprilTag docking; Docker quickstart.

## openamrobot-fw
- Project: OpenAMRobot
- Title: OpenAMR Platform Firmware README
- URL: https://github.com/openAMRobot/openamr-platform-fw/blob/main/README.md
- Type: GitHub README
- License/status: MIT for original; Apache-2.0 for linorobot2-derived overlay
- Evidence used: Teensy 4.0 micro-ROS motor-control firmware; encoder odometry; IMU; debug telemetry; flashing workflow.

## openamrobot-ui
- Project: OpenAMRobot
- Title: OpenAMRobot UI README
- URL: https://github.com/openAMRobot/openamrobot-ui/blob/main/README.md
- Type: GitHub README
- License/status: Verify per repository
- Evidence used: Browser dashboard: maps, manual driving, goals, camera, routes, Blockly, missions, health, developer tools; software E-stop limitation.
