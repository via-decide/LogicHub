# NASA JPL Rover / OpenAMRobot Research Bundle

Generated: 2026-07-30T13:34:00+05:30

This ZIP compares two high-value open mobile robotics platforms:

1. **NASA JPL Open Source Rover (OSR)** — a six-wheel Mars-rover-inspired educational and rugged-terrain robot.
2. **OpenAMRobot v0.0.1** — an early ROS 2 Jazzy autonomous mobile robot platform with hardware, firmware, software, UI, interfaces, communication, and documentation repositories.

## Core verdict

- Use **NASA JPL OSR** for mechanical learning, rocker-bogie rover mobility, rugged-terrain experiments, outreach, and COTS hardware/BOM source intake.
- Use **OpenAMRobot** for modern ROS 2 AMR workflows: simulation, Nav2, SLAM, AprilTag docking, browser UI, micro-ROS motor control, and product-level multi-repository release design.
- Do **not** combine them into one physical robot before each platform is separately source-pinned, safety-reviewed, and validated.

## Included files

- `01_deep_research_report.md`
- `02_architecture_comparison.md`
- `03_nasa_jpl_osr_source_map.md`
- `04_openamrobot_source_map.md`
- `05_cad_bom_manufacturing_intake_plan.md`
- `06_software_firmware_stack_analysis.md`
- `07_validation_and_commissioning_plan.md`
- `08_safety_compliance_risk_register.csv`
- `09_india_productization_strategy.md`
- `10_license_and_commercialization.md`
- `11_logichub_gn8r_tasks.md`
- `12_prior_project_alignment.md`
- `13_bibliography_and_sources.md`
- `source_manifest.csv`
- `file_hashes.csv`
- `schemas/`
- `scripts/`
- `templates/`

## Limitation

This ZIP does **not** embed official CAD, Onshape exports, STEP files, release archives, firmware binaries, ROS workspaces, vendor datasheets, PCB files, or wiring diagrams. Download those directly from upstream, pin by commit/release/version, hash them, and add them to `source_manifest.csv` before fabrication or operation.
