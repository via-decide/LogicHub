# Validation and Commissioning Plan

## NASA JPL OSR

### Source gate
- Repository commit pinned.
- Parts list pinned.
- Onshape export logged.
- Rover code pinned.
- License notices captured.

### Mechanical gate
- rocker-bogie moves freely.
- steering linkage clearances verified.
- wheel contact verified.
- fasteners torqued.
- wire strain relief through moving assemblies.

### Electrical gate
- polarity check.
- fuse installed.
- battery monitor installed.
- motor controllers configured.
- current draw measured.
- no exposed shorts.

### Motion gate
- wheels on blocks.
- motor direction test.
- steering direction test.
- low-speed floor test.
- terrain crawl test.

## OpenAMRobot

### Simulation gate
- Docker build.
- Gazebo launch.
- RViz.
- Nav2.
- SLAM.
- docking pipeline.

### Firmware gate
- PlatformIO build.
- Teensy flash.
- micro-ROS agent connects.
- ROS topics present.
- encoder directions correct.
- IMU sane at rest.
- low-speed `/cmd_vel` on blocks.

### Hardware safety gate
- 24 V fuse installed.
- battery disconnect installed.
- physical E-stop installed.
- Pi 5 active cooler installed.
- 5 V brown-out tested.
- UI stop documented as non-safety.

## Receipt fields

```yaml
receipt_id:
platform:
revision:
operator:
date_time:
source_manifest_hash:
test_name:
preconditions:
commands:
measurements:
pass_fail:
risks_found:
next_action:
```
