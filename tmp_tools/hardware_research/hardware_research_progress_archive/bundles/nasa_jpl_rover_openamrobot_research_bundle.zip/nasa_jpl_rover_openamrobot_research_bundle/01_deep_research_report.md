# Deep Research Report: NASA JPL Open Source Rover + OpenAMRobot

## Executive summary

This research bundle compares two different open mobile robot ecosystems.

**NASA JPL Open Source Rover (OSR)** is a six-wheel, Mars-rover-inspired platform for education, outreach, rugged-terrain research, and mechanical learning. It is strongest where physical geometry matters: rocker-bogie suspension, differential pivot, six-wheel Ackerman steering, aluminum structure, COTS sourcing, wiring through moving assemblies, and field drive validation.

**OpenAMRobot v0.0.1** is a modern ROS 2 autonomous mobile robot platform. It is strongest where software-system integration matters: ROS 2 Jazzy, Gazebo Harmonic simulation, Nav2, SLAM, AprilTag docking, Teensy 4.0 micro-ROS firmware, browser dashboard, Blockly-style workflow, camera streaming, diagnostics, and a frozen multi-repository release archive.

## Platform comparison

| Dimension | NASA JPL OSR | OpenAMRobot |
|---|---|---|
| Robot type | Six-wheel Mars rover-style robot | Differential-drive AMR |
| Terrain intent | Rugged / outdoor / educational terrain | Indoor AMR / logistics / lab floor |
| Mechanical focus | Rocker-bogie, differential pivot, Ackerman steering | Sheet/chassis AMR base, drivetrain integration |
| Compute | Raspberry Pi | Raspberry Pi 5 |
| Low-level control | Rover electronics/code path | Teensy 4.0 + micro-ROS firmware overlay |
| Middleware | ROS2 tested on Foxy in code repo | ROS 2 Jazzy |
| Simulation | Secondary | Central: Gazebo Harmonic |
| Navigation | Builder-extensible | Nav2, SLAM, AprilTag docking |
| UI | Custom/builder-defined | Browser dashboard, maps, camera, routes, Blockly, health |
| Maturity | Long-running OSHW-certified education project | Very new experimental public release |
| Best product | Rover education/mechanics kit | ROS 2 AMR simulation and bring-up kit |

## NASA JPL OSR findings

The OSR README describes the rover as an open-source, build-it-yourself, scaled-down six-wheel rover design based on JPL Mars rover mobility. It is built from consumer off-the-shelf parts and aimed at teaching mechanical engineering, software, electronics, and robotics, while also serving as a rugged-terrain research platform.

Engineering significance:
- The mobility system gives students a real mechanical architecture problem, not only a wheeled chassis.
- The Raspberry Pi brain creates room for sensor add-ons and software extension.
- The build path is source-rich: parts list, wiring, PCB/electronics, mechanical assemblies, software bring-up, and Onshape model references.
- Its strongest monetizable form is a verified education kit, not an industrial robot.

## OpenAMRobot findings

OpenAMRobot v0.0.1 is especially useful because it packages the hard part of modern robotics: multiple repositories across hardware, firmware, software, UI, interfaces, communication, and documentation. The release README explains that GitHub auto-generated archives only contain the release-builder repository, so OpenAMRobot publishes a single product-level release archive.

Engineering significance:
- The project is a strong example of multi-repository hardware/software release governance.
- The software stack is modern: ROS 2 Jazzy, Gazebo Harmonic, Nav2, SLAM, and docking.
- The firmware boundary is explicit: Teensy 4.0, micro-ROS, encoders, IMU, motor control, debug telemetry.
- The operator surface is explicit: browser UI with maps, teleoperation, routes, visual programs, camera, missions, and health.
- Upstream honestly documents safety blockers such as missing 24 V battery fuse, missing battery-side disconnect/E-stop, Pi 5 thermal risk, Pi brown-out risk, and software E-stop limitations.

## Productization verdict

### Best first combined product

**Open Mobile Robotics Engineering Lab**

Modules:
1. NASA OSR mechanical rover source-intake and build-planning lab.
2. OpenAMRobot ROS 2 Jazzy simulation lab.
3. Firmware/control safety lab.
4. CAD/BOM/license/source-manifest lab.
5. Validation receipt and operator safety lab.

### Go / No-Go

| Path | Verdict |
|---|---|
| Research and source-intake bundle | GO |
| OpenAMRobot simulation demo | GO |
| NASA OSR education kit planning | GO |
| OpenAMRobot physical powered build | CONDITIONAL GO after fuse/E-stop/thermal/power retrofits |
| Industrial AMR deployment | NO-GO until safety, reliability, and compliance are validated |
| Outdoor autonomous rover | NO-GO without additional perception/autonomy/terrain validation |

## Next action

Create two separate LogicHub roots:

```text
/projects/nasa-jpl-open-source-rover/
/projects/openamrobot-v0.0.1/
```

Keep the projects separate until each passes:
- source hash gate
- license inventory gate
- CAD/BOM extraction gate
- safety gate
- validation evidence gate
