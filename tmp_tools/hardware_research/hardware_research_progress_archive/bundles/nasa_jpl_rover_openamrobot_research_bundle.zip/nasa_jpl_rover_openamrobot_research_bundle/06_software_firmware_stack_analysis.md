# Software and Firmware Stack Analysis

## NASA JPL OSR

The OSR code repo states that the Raspberry Pi code controls the rover, uses ROS2 tested on Foxy, and uses Python3.

Recommended modernization branch:
- preserve upstream as imported source.
- create separate ROS 2 Jazzy branch.
- add Docker dev environment.
- add simulated robot description.
- add Nav2-compatible model only after hardware geometry is verified.
- capture test receipts for each motion command.

## OpenAMRobot

OpenAMRobot software stack:
- Ubuntu 24.04.
- ROS 2 Jazzy.
- Gazebo Harmonic.
- Nav2.
- SLAM.
- AprilTag docking.
- Docker quickstart.
- UI workspace.
- rosbridge/camera/dashboard layer.

OpenAMRobot firmware stack:
- Teensy 4.0.
- PlatformIO.
- micro-ROS agent.
- linorobot2-derived overlay.
- motor control.
- encoder odometry.
- IMU integration.
- debug telemetry.

## Firmware safety rule

Before live motion:
1. robot on blocks,
2. low-speed command only,
3. physical E-stop reachable,
4. fuse/disconnect installed,
5. encoder direction confirmed,
6. IMU sanity confirmed,
7. operator area clear.

## UI safety rule

The browser dashboard is an operator interface, not a safety controller. Software stop must never be accepted as equivalent to a latching hardware E-stop.
