# Architecture Comparison

```mermaid
flowchart TB
  subgraph OSR["NASA JPL Open Source Rover"]
    OSR_MECH["Rocker-bogie + differential pivot + six-wheel Ackerman"]
    OSR_ELEC["PCB / wiring / motor controllers / battery"]
    OSR_PI["Raspberry Pi"]
    OSR_CODE["ROS2/Python rover code"]
    OSR_MECH --> OSR_ELEC --> OSR_PI --> OSR_CODE
  end

  subgraph AMR["OpenAMRobot"]
    AMR_HW["Differential-drive chassis + 24V power"]
    AMR_T4["Teensy 4.0 micro-ROS firmware"]
    AMR_PI["Raspberry Pi 5 + Ubuntu 24.04"]
    AMR_ROS["ROS 2 Jazzy + Gazebo + Nav2 + SLAM + Docking"]
    AMR_UI["Browser UI + Blockly + Camera + Health"]
    AMR_HW --> AMR_T4 --> AMR_PI --> AMR_ROS --> AMR_UI
  end

  LH["LogicHub source intake / diff / validation / release evidence"] --> OSR
  LH --> AMR
```

## Key architecture distinction

NASA OSR starts from terrain mobility and mechanical architecture. OpenAMRobot starts from ROS 2 AMR software architecture and operator workflows.

## Safety boundary

```text
UI command != safety permission
ROS goal != safety permission
firmware watchdog != safety-rated E-stop
physical fuse + disconnect + E-stop + validated wiring = minimum powered-operation gate
```

## Canonical source graph

```text
RobotProject
  SourcePackage
    CADAsset
    BOMLine
    WiringHarness
    FirmwareTarget
    ROSPackage
    OperatorUI
    ValidationReceipt
    SafetyWaiver
```
