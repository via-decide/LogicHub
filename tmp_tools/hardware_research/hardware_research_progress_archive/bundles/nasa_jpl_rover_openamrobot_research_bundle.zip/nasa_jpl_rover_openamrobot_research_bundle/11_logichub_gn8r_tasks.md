# LogicHub / GN8R Task Blocks

/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 360
version: 1
depends_on: none
task: Build source intake for NASA JPL OSR and OpenAMRobot. Discover README, CAD links, BOM, wiring, firmware, ROS, UI, release, license, safety docs. Hash every source. Emit manifest.

CAUSATION:
Robot builds without deterministic source identity become unsafe folklore. CAD, BOM, wiring, firmware and docs must be pinned before manufacturing or motion tests.

CONVERGENCE PROOF:
Variables:
$S$ = source files
$H$ = hashes
$M$ = manifest
$L$ = license map
$Constraint = same(S) => same(H,M,L)$

Why naive fails:
- A: GitHub ZIP misses OpenAMRobot multi-repo release.
- B: CAD links copied without commit/export identity.
- C: Local BOM substitutions made before safety review.

EPISTEMIC_BOUNDARIES:
Facts:
- NASA OSR and OpenAMRobot are separate architectures.
- OpenAMRobot spans multiple repos.
- Powered operation is safety-relevant.

EXECUTION_CONTRACT:
- Create two project roots.
- Pin upstream URLs/commits.
- Hash downloaded files.
- Mark external CAD as link-only until exported.
- Emit source_manifest.csv/json.

---

/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 420
version: 1
depends_on: mobile_robot_source_intake_v1
task: Build safety gate engine for mobile robots. Encode battery fuse, E-stop, Pi thermal, Pi brownout, Teensy 5V intolerance, LiPo discharge, wiring-chafe, software-stop limitations.

CAUSATION:
A ROS launch can pass while the robot remains physically unsafe. Safety gates must outrank commands, UI, and demo success.

CONVERGENCE PROOF:
Variables:
$R$ = risk register
$G$ = gates
$E$ = evidence
$D$ = decision
$Constraint = unresolved(Critical) => no powered floor test$

Why naive fails:
- A: Treat UI stop as hardware E-stop.
- B: Run motors without fuse/disconnect.
- C: Ignore 3.3V signal limits.

EPISTEMIC_BOUNDARIES:
Facts:
- OpenAMRobot docs disclose missing fuse/disconnect.
- UI docs disclose software E-stop limitation.
- OSR docs warn battery discharge hazard.

EXECUTION_CONTRACT:
- Emit pass/fail/warn.
- Require physical E-stop evidence.
- Require battery protection evidence.
- Store validation receipts.

---

/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 480
version: 1
depends_on: mobile_robot_safety_gate_v1
task: Build architecture comparison review. Compare NASA OSR rocker-bogie rover with OpenAMRobot ROS2 AMR. Map CAD, BOM, firmware, software, UI, safety, validation and monetization.

CAUSATION:
Rover and AMR look similar but solve different problems. Mixing them creates wrong terrain assumptions, unsafe claims and bad BOMs.

CONVERGENCE PROOF:
Variables:
$A1$ = OSR
$A2$ = OpenAMR
$C$ = comparison
$V$ = verdict
$Constraint = every recommendation cites source or is marked inference$

Why naive fails:
- A: Treat both as generic robot car.
- B: Sell experimental AMR as industrial.
- C: Use NASA/JPL identity as endorsement.

EXECUTION_CONTRACT:
- Produce matrix.
- Produce Go/No-Go.
- Produce India sourcing strategy.
- Preserve source evidence.
