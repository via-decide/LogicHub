# Prior Project Alignment

## 8MB air-gapped storage module
Use the storage module concept as an offline robot build manifest carrier: source hashes, firmware hash, validation receipts, safety checklist, and supplier BOM.

## Drone bundle
Transfer arming-gate logic: no motion until IMU/encoder/power/kill-switch gates pass.

## Pupper V3
Transfer high-level compute vs low-level actuation separation and motor safety validation.

## FarmBot
Transfer web operator workflow and hardware/software product-surface thinking.

## OpenFlexure
Transfer build-variant and validation documentation discipline.

## SatNOGS
Transfer station identity, observation receipts, and distributed fleet thinking.

## Voron
Transfer BOM/configurator, build commissioning, and mod separation.

## OpenEVSE
Transfer safety-priority concept: UI/API commands cannot override safety controller.

## OpenMV + OpenIPC
Transfer local-first camera/perception, privacy boundaries, and snapshot/stream validation.

## RISC-V edge bundle
Future compute candidates for local perception, deterministic IO, or FPGA-assisted robotics.
