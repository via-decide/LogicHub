# OpenAMRobot Source Map

## Release structure

OpenAMRobot v0.0.1 uses a release repository plus several domain repositories. The release README says the official `OpenAMRobot-v0.0.1-source.zip` is the frozen product-level archive because a normal GitHub source ZIP does not include all domain repositories.

## Repositories

| Repository | Domain |
|---|---|
| `openAMRobot/openamrobot-release` | frozen release metadata |
| `openAMRobot/openamr-platform-hw` | hardware, CAD, BOM, wiring, safety |
| `openAMRobot/openamr-platform-sw` | ROS 2 Jazzy, Gazebo, Nav2, docking |
| `openAMRobot/openamr-platform-fw` | Teensy 4.0 micro-ROS motor-control firmware |
| `openAMRobot/openamrobot-ui` | browser operator interface |
| `openAMRobot/openamrobot-interfaces` | shared interfaces |
| `openAMRobot/openamrobot-comm` | communication |
| `openAMRobot/openamrobot-docs` | documentation |

## Hardware facts from upstream docs

- Raspberry Pi 5, 8 GB.
- Ubuntu Server 24.04 + ROS 2 Jazzy.
- Teensy 4.0, 3.3 V IO, not 5 V tolerant.
- ZD Z4BLD60-24GN-30S ×2 BLDC motors.
- ZBLD.C20-120L2R ×2 drivers.
- AS5040 wheel encoders.
- MPU6500 IMU.
- RPLIDAR A1.
- Raspberry Pi Camera Module 3 NoIR.
- 24 V battery reference design.
- Wheel diameter 0.2 m, track 0.46 m.

## Source-disclosed safety blockers

- No fuse on 24 V battery.
- No battery-side disconnect / hardware E-stop.
- Pi 5 active cooler not fitted in reference configuration.
- Pi 5 brown-out risk.
- Firmware command watchdog is not a substitute for physical E-stop.
- UI E-stop is a software stop, not safety-rated or independent.

## OpenAMRobot source-intake gates

1. Download official v0.0.1 release archive.
2. Verify `VERSION`, `MANIFEST.json`, and `checksums.sha256`.
3. Hash each extracted file.
4. Map repository boundaries.
5. Parse hardware BOM and mechanical BOM.
6. Parse firmware overlay provenance.
7. Launch software simulation.
8. Verify UI demo mode.
9. Block physical operation until safety retrofits are documented.
