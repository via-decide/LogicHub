# License and Commercialization Notes

## NASA JPL OSR

The OSR README states Apache License 2.0 and includes a disclaimer that references to commercial products do not imply endorsement by the United States Government, JPL, or Caltech.

Commercial notes:
- preserve Apache-2.0 notices.
- verify CAD/Onshape export terms.
- do not imply NASA/JPL/Caltech endorsement.
- avoid using NASA/JPL branding as product branding.
- create file-level inventory before redistribution.

## OpenAMRobot

The OpenAMRobot public announcement describes it as MIT-licensed. Repository details are more nuanced:
- hardware repo says MIT for docs/BOM currently, with hardware design files planned under CERN-OHL-S-2.0 when added.
- firmware repo says MIT for original work and Apache-2.0 for linorobot2-derived overlay files.
- UI/software dependencies need separate inventory.

Required license inventory columns:

```csv
path,source_project,license,copyright_owner,derived_from,modifications,redistribution_allowed,commercial_risk,notice_required
```

Safe monetization:
- training
- integration
- source-intake
- validation support
- safety retrofit consulting
- simulation/demo packaging

Unsafe claims:
- certified AMR
- NASA-endorsed rover
- safety-rated browser E-stop
- industrial logistics deployment without validation
