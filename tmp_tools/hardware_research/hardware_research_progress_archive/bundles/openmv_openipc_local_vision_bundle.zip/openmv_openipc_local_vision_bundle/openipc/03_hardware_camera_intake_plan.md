# OpenIPC Camera Hardware Intake Plan

## Target hardware classes

| Class | Good for | Risk |
|---|---|---|
| known OpenIPC-supported board | fastest proof of concept | procurement consistency |
| commodity IP camera with known SoC/sensor | low cost | board revisions vary |
| industrial camera module | productization | higher BOM cost |
| WiFi FPV camera board | low-latency research | RF/regulatory complexity |

## Required hardware intake fields

- exact camera model
- board photos top/bottom
- SoC marking
- sensor marking
- flash chip marking and capacity
- RAM chip marking
- UART pads location
- power rail voltages
- Ethernet/WiFi chipset
- stock firmware version
- boot log
- OpenIPC image selected
- recovery method verified

## Bring-up sequence

1. Photograph PCB and labels.
2. Identify SoC, sensor, flash, RAM.
3. Connect UART console.
4. Dump boot log.
5. Backup original flash if possible.
6. Check OpenIPC support matrix/docs.
7. Flash only matching firmware.
8. Verify boot, network, login, stream, and recovery.
9. Freeze target board revision for any product.

## Enclosure and privacy hardware

- visible privacy shutter if consumer-facing
- status LED that cannot be disabled silently
- reset/recovery button
- tamper sticker or tamper switch for security installs
- physical LAN option preferred over WiFi for industrial privacy
