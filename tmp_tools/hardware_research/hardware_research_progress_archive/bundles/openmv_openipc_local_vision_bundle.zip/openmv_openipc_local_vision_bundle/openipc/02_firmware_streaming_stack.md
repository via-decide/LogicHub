# OpenIPC Firmware and Streaming Stack

## Source intake

Minimum source assets:

- `OpenIPC/firmware` repository at exact commit.
- OpenIPC builder inputs/configuration.
- target SoC defconfig.
- target sensor/board files.
- bootloader/partition layout notes.
- firmware image hash.
- web UI source version.
- docs/wiki references.

## Streaming stack

OpenIPC local-camera products usually center on:

- image sensor driver
- SoC ISP path
- hardware encoder
- Majestic streamer or equivalent camera app
- RTSP stream
- web UI / HTTP endpoints
- local NVR integration

## Local gateway contract

The local gateway should read:

- RTSP URL
- snapshot URL
- firmware version
- camera health status
- stream metadata

The gateway should not require:

- vendor cloud account
- undocumented mobile app relay
- remote NAT traversal
- hardcoded public server

## OpenIPC product hard rules

- No arbitrary camera flashing.
- No build without recovery path.
- No unsupported sensor promise.
- No remote exposure of RTSP without authentication/VPN.
- No default cloud video upload.
