# OpenIPC Architecture Analysis

## Source-derived facts

OpenIPC describes itself as an alternative open firmware for IP cameras, based on Buildroot. Its README says the project is a rapidly developing open-source alternative firmware for popular IP cameras. It also says support historically began with HiSilicon SoCs and expanded to Ambarella, Anyka, Fullhan, Goke, GrainMedia, Ingenic, MStar, Novatek, SigmaStar, XiongMai, and others.

OpenIPC provides a community and paid support model. The README explicitly recommends paid commercial support for business use.

## Runtime architecture

```mermaid
flowchart TB
  Boot[Bootloader / flash partitions] --> Kernel[OpenIPC Linux kernel]
  Kernel --> Drivers[Sensor + ISP + network drivers]
  Drivers --> Encoder[Hardware encoder]
  Encoder --> Majestic[Majestic streamer]
  Majestic --> RTSP[RTSP stream]
  Majestic --> HTTP[HTTP snapshots/config]
  HTTP --> LocalUI[Web UI]
  RTSP --> NVR[Local NVR / gateway]
```

## Product roles

- no-cloud camera firmware
- local RTSP camera
- privacy camera appliance
- FPV video research
- local surveillance gateway
- replacement firmware for abandoned camera hardware

## Compatibility problem

A camera model name is not enough. Product intake must capture:

- SoC
- image sensor
- bootloader access
- flash size and partition map
- existing firmware backup
- network interface
- recovery route
- matching OpenIPC firmware build

## Flashing risk

Wrong firmware can brick a device. Productization must include:

- UART console access
- original firmware backup
- documented recovery method
- programmer or bootloader recovery path
- serial logs from first boot
- rollback test
