#!/usr/bin/env bash
set -euo pipefail
URL="${1:?usage: ./rtsp_probe_ffprobe.sh rtsp://user:pass@camera/stream}"
SECONDS_TO_RUN="${2:-30}"
ffprobe -v error -rtsp_transport tcp -read_intervals "%+#${SECONDS_TO_RUN}"   -show_entries stream=codec_name,width,height,avg_frame_rate   -of json "$URL"
