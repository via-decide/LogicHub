#!/usr/bin/env python3
"""Read OpenMV USB VCP output without asserting DTR.
Non-invasive probe scaffold. Requires: pip install pyserial
"""
import argparse, time, serial

parser = argparse.ArgumentParser()
parser.add_argument("port", help="Serial port, e.g. /dev/ttyACM0 or COM3")
parser.add_argument("--baud", type=int, default=115200)
parser.add_argument("--seconds", type=float, default=30)
args = parser.parse_args()

end = time.time() + args.seconds
with serial.Serial(args.port, args.baud, timeout=1, dsrdtr=False) as ser:
    ser.dtr = False
    while time.time() < end:
        line = ser.readline().decode(errors="replace").strip()
        if line:
            print(line)
