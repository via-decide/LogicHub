#!/usr/bin/env python3
import argparse, json, hashlib, datetime
parser = argparse.ArgumentParser()
parser.add_argument('--manifest', required=True)
parser.add_argument('--result', required=True)
args = parser.parse_args()
manifest = open(args.manifest, 'rb').read()
result = open(args.result, 'rb').read()
receipt = {
  'schema': 'local-vision-validation-receipt-v1',
  'generated_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'manifest_sha256': hashlib.sha256(manifest).hexdigest(),
  'result_sha256': hashlib.sha256(result).hexdigest(),
}
receipt['receipt_sha256'] = hashlib.sha256(json.dumps(receipt, sort_keys=True).encode()).hexdigest()
print(json.dumps(receipt, indent=2))
