#!/usr/bin/env python3
"""Fetch a camera snapshot URL and print SHA-256 and size.
Use only on cameras you own or are authorized to test.
"""
import argparse, hashlib, urllib.request
parser = argparse.ArgumentParser()
parser.add_argument('url')
parser.add_argument('--user')
parser.add_argument('--password')
args = parser.parse_args()
req = urllib.request.Request(args.url)
if args.user and args.password:
    import base64
    token = base64.b64encode(f"{args.user}:{args.password}".encode()).decode()
    req.add_header('Authorization', f'Basic {token}')
with urllib.request.urlopen(req, timeout=10) as r:
    data = r.read()
print({'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
