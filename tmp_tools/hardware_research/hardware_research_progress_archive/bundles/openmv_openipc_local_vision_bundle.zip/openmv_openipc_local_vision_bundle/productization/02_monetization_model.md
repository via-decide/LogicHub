# Monetization Model

## Hardware-led

- Verified OpenMV inspection kits.
- Verified OpenIPC local camera bundles.
- Fixtures, lighting rings, mounts, brackets, and enclosures.
- Local gateway appliance.

## Service-led

- OpenIPC compatibility audit.
- Firmware flashing and recovery.
- OpenMV script/model customization.
- Local NVR setup and maintenance.
- Privacy/security hardening.
- Factory inspection integration.

## Platform-led

- LogicHub source-manifesting and validation reports.
- Daxini.space marketplace for verified camera profiles.
- Viadecide technical teardown/content series.
- Hanuman.solutions implementation service.
- Aporaksha controlled physical-verification flows.

## Commercial package examples

| Package | Price logic | Deliverables |
|---|---|---|
| Vision Research Intake | fixed service fee | source manifest + feasibility report |
| OpenMV Inspection MVP | kit + customization | camera, fixture, script, validation receipt |
| Local CCTV Privacy Kit | hardware + setup | OpenIPC camera, local NVR, policy dashboard |
| Factory Vision Pilot | project fee | 1 location deployment + 30-day validation |
