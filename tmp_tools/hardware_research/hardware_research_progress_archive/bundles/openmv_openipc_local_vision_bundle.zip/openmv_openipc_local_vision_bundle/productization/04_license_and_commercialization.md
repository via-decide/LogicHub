# License and Commercialization Notes

## OpenMV

The OpenMV README states that most code is MIT, but identifies important exceptions:

- some image library code is GPL, including AGAST, LSD, and ZBAR;
- GPL code can be disabled via `OMV_NO_GPL` in imlib configuration files;
- third-party libraries and drivers have various permissive licenses;
- some drivers/modules/libraries are proprietary and available for non-commercial use only;
- commercial licensing options require contacting OpenMV.

Commercial action: create a file-level license inventory before distributing a firmware image or closed-source product.

## OpenIPC

The OpenIPC firmware repository LICENSE file is MIT. However, productization must still inspect every component, build dependency, kernel/Buildroot package, binary blob, web UI, and hardware-specific contribution.

Commercial action: treat OpenIPC as source-available/open-source firmware, not a certification shortcut.

## Product rule

Do not copy model files, third-party weights, firmware images, web assets, or camera vendor blobs into a commercial bundle until license provenance is clear.
