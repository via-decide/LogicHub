# India Productization Strategy

## Best initial offers

### 1. Local shop/factory camera appliance

OpenIPC-compatible camera plus local gateway. Use case: small factory monitoring, local evidence, no vendor cloud dependency.

### 2. Industrial OpenMV inspection kit

OpenMV camera, lens/lighting fixture, scripts for QR/barcode/color/part-presence detection, local pass/fail dashboard.

### 3. Education AI vision kit

OpenMV camera + guided lessons + visual tasks + local dashboard. Avoid surveillance framing.

### 4. Aporaksha-adjacent visual verification

Use camera for token/fixture/document-state verification first. Avoid face recognition or biometric identity claims until legal/security review.

## Commercial services

- board support verification
- OpenIPC flashing/recovery service
- custom OpenMV script development
- local NVR setup
- privacy/network hardening
- enclosure/fixture design
- LogicHub manifest and validation reports

## Regulatory watchpoints

- wireless/WiFi compliance if hardware is sold
- privacy obligations for surveillance deployments
- cybersecurity obligations for network cameras
- import/sourcing consistency
- electrical safety for power adapters/enclosures
- workplace monitoring consent where applicable

## Go-to-market framing

Use:

- “local-first camera appliance”
- “private inspection camera”
- “edge AI vision kit”
- “open firmware research kit”

Avoid:

- “guaranteed secure surveillance”
- “works on every camera”
- “medical/diagnostic vision system”
- “biometric authentication system” without full review
