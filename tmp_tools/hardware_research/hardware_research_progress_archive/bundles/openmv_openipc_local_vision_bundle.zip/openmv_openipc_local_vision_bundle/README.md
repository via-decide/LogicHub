# OpenMV + OpenIPC Local Vision Research Bundle

Generated: 2026-07-30T12:00:00+05:30

## Scope
This bundle studies two complementary open-source local-vision platforms:

1. **OpenMV** — microcontroller-class programmable machine-vision camera, Python/MicroPython workflow, edge AI/TinyML, sensor-level image processing, and direct microcontroller/robot integration.
2. **OpenIPC** — Buildroot-based open firmware ecosystem for commodity IP cameras, focused on replacing opaque vendor firmware with a local, configurable network-camera stack.

The goal is not to merge them into one firmware image. The useful product architecture is a **two-tier local-first vision system**:

- **OpenMV tier:** low-power event detection, triggering, local classification, line following, barcode/AprilTag/QR recognition, simple robotics/inspection loops.
- **OpenIPC tier:** always-on local video streaming, RTSP/IP camera replacement firmware, local NVR/Frigate/Home Assistant style integration, edge surveillance/privacy appliances.
- **LogicHub/Daxini tier:** source intake, reproducible manifests, privacy boundary, offline validation receipts, and evidence-backed productization.

## Can you build a product from this only?
You can start **research, source intake, proof-of-concept planning, and EVT validation** from this bundle. You cannot fabricate or ship a product from this bundle alone.

Missing before product release:

- Exact OpenMV board model selection and vendor hardware files.
- Exact OpenIPC-supported camera board, SoC, sensor, flash layout, bootloader/rollback path.
- Exported source archives and commit-pinned firmware builds.
- Thermal, EMI/EMC, enclosure, power, privacy, cybersecurity, and field reliability validation.
- Legal review for surveillance/privacy, wireless compliance, camera procurement, and OSS license obligations.

## Best first product direction
The highest-probability product is not a new camera PCB. It is a **local-first vision appliance**:

- OpenMV module for edge-triggered visual events.
- OpenIPC-supported IP camera for local RTSP/NVR feed.
- Local host app or gateway that stores events, signs validation receipts, and never uploads raw video by default.
- Optional cloud only for device management, signed updates, or customer-selected telemetry.

## Bundle contents

- `01_deep_research_report.md` — full strategic and engineering report.
- `architecture/` — system diagrams and data-flow boundaries.
- `openmv/` — OpenMV architecture, firmware/IDE/API, hardware intake plan.
- `openipc/` — OpenIPC architecture, firmware/wiki/source intake, local camera risks.
- `local_first/` — privacy boundary, data model, product architecture.
- `validation/` — test plans, validation receipt design, reliability matrix.
- `productization/` — India strategy, monetization, commercial paths, BOM templates.
- `logichub/` — compact GN8R/LogicHub task blocks.
- `prior_projects/` — alignment with previous generated research bundles.
- `scripts/` — non-invasive validation scaffolds.
- `schemas/` — JSON schemas for source and validation manifests.
- `templates/` — CSV intake templates.
- `sources/` — bibliography, source manifest, hash manifest.

## Important warning
OpenIPC flashing is invasive. Wrong firmware for a camera SoC/sensor/flash layout can brick hardware. Treat OpenIPC productization as **source intake and validation first**, not mass flashing.

OpenMV licensing is also mixed: the public README says most code is MIT, but GPL image-library code, third-party permissive code, and some proprietary/non-commercial components exist. Commercial builds require a file-level license inventory.
