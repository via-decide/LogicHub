# Prior Project Alignment

## 8MB air-gapped storage module

Use as local signed policy/receipt cartridge:

- store vision privacy policy hash
- store model/script manifest hash
- store event receipts
- store local validation gate results

## Drone CAD implementation bundle

OpenMV can act as a lightweight visual sensor for drone experiments. OpenIPC is less suitable for flight control; it is more suitable for ground/FPV streaming research where latency and RF are tested.

## Pupper V3 research bundle

OpenMV can serve as a robot perception coprocessor. OpenIPC can provide local monitoring/video for robot lab operation.

## FarmBot bundle

OpenMV fits crop/weed marker detection, QR/tool verification, and bed inspection. OpenIPC fits fixed-bed monitoring and timelapse.

## OpenFlexure bundle

OpenMV-style local image processing can inspire microscope quality-control workflows, but OpenFlexure is optics/positioning first. OpenIPC is not a microscope firmware replacement.

## SatNOGS bundle

Shared pattern: local-first networked hardware, source-manifested firmware, receive-only/privacy-preserving telemetry, and validation receipts.

## Voron bundle

OpenMV can inspect first-layer/print defects in a controlled lighting enclosure. OpenIPC can provide local printer chamber monitoring without cloud.

## OpenEVSE bundle

Same control-plane principle: safety-critical device logic must be separated from web/UI/cloud logic. For vision, privacy-critical raw video must be separated from metadata/events.
