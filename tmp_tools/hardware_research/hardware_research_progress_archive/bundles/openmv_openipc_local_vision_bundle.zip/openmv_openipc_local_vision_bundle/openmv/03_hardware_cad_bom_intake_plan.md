# OpenMV Hardware/CAD/BOM Intake Plan

## Board selection decision

| Candidate | Best for | Watchpoints |
|---|---|---|
| OpenMV H7 Plus | stable high-memory MCU vision | product lifecycle; check availability |
| OpenMV N6 | high-end MCU/NPU camera, local AI + H.264 | newer toolchain and firmware maturity |
| OpenMV AE3 | ultra-low-power edge AI | availability and model deployment workflow |
| OpenMV Cam RT / older models | lower-cost education | performance/memory limits |

## Required intake fields

- board model
- board revision
- MCU/SoC
- camera sensor
- lens/FOV/focus method
- RAM/flash
- interface pins
- power input and peak current
- thermal operating envelope
- firmware release/commit
- OpenMV IDE version
- examples/models used
- license inventory

## Enclosure/fixture direction

OpenMV product value is usually determined by optics and fixture repeatability:

- fixed focus distance
- controlled illumination
- matte black internal baffles
- repeatable part positioning
- cable strain relief
- thermal path away from sensor
- lens protection window

## Manufacturing readiness checklist

- camera/lens supplier locked
- lens focus adjustment locked or calibrated
- illumination wavelength and intensity locked
- printed/molded enclosure tolerances checked
- EMI/ESD path checked
- software update method defined
- factory calibration script created
