# OpenMV Architecture Analysis

## Source-derived facts

The OpenMV README identifies the project as an open-source machine vision platform. It states that OpenMV cameras are programmable in Python3 and include support for TensorFlow, ST Edge AI, NPU acceleration through ARM Ethos-U55, and ST Neural-ART. It also lists image filtering, feature detection, color tracking, QR/barcode decoding, AprilTag recognition, GIF/MJPEG recording, and streaming as built-in capability areas.

The README identifies the OpenMV-N6 and OpenMV-AE3 as newer-generation models. N6 is positioned as an STM32N6-based high-performance camera with NPU, H.264, high-speed USB, ISP, GPU, microSD, WiFi/BLE, Gigabit Ethernet, and GPIO. AE3 is positioned as a low-power model with Alif Ensemble E3, dual Ethos-U55 NPUs, global-shutter camera, IMU, microphone, distance sensor, USB, WiFi/BLE, and QWIIC.

## Runtime model

OpenMV is a MicroPython-style programmable camera. The normal application is a script that reads frames, applies image operations or inference, and emits compact results to another system.

```mermaid
sequenceDiagram
  participant Sensor
  participant OpenMVScript
  participant Model
  participant Host
  Sensor->>OpenMVScript: frame
  OpenMVScript->>OpenMVScript: preprocessing / threshold / feature extraction
  OpenMVScript->>Model: optional inference
  Model-->>OpenMVScript: label / bbox / score
  OpenMVScript->>Host: event over USB VCP / UART / SPI / I2C / CAN
```

## Interface model

The README describes an RPC interface library for connecting OpenMV to other microcontrollers over UART, I2C, SPI, and CAN. It also notes that simple `print()` output can be read through the USB Virtual COM Port.

## Product roles

- visual event sensor
- local object/count detector
- robotics perception coprocessor
- line/color/marker tracker
- barcode/QR station
- education/AI camera module
- fixture/inspection checker

## Engineering risks

| Risk | Why it matters | Control |
|---|---|---|
| Lens/lighting mismatch | accuracy drops before code changes matter | fixed illumination + lens/FOV spec |
| Model memory mismatch | model may not fit board | model manifest with RAM/flash/operator check |
| Mixed licensing | commercial builds may be restricted | file-level license inventory |
| Unstable USB serial handling | host scripts miss output | set DTR false when reading VCP |
| Overclaiming AI | demos fail in production lighting | validation on target environment |
