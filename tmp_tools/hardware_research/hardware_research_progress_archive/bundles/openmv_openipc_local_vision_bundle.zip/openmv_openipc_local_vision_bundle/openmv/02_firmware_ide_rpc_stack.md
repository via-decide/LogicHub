# OpenMV Firmware, IDE, and RPC Stack

## Firmware source intake

Minimum source assets to collect:

- `openmv/openmv` repository at exact commit.
- `openmv/micropython` submodule/fork commit.
- board configuration files.
- firmware release artifact or locally reproducible build output.
- OpenMV IDE version used for scripts and firmware update.
- example scripts used in validation.
- model files and conversion tool versions.

## IDE

OpenMV IDE is a cross-platform IDE based on Qt Creator. Its README says it is for writing Python code for OpenMV Cam, updating firmware, and developing applications quickly. It can also be compiled from source.

## Host interface options

| Interface | Use | Product note |
|---|---|---|
| USB VCP | debug, logs, local host gateway | simplest proof-of-concept |
| UART | embedded controller integration | robust for product wiring |
| SPI | high-speed data transfer | board-level integration needed |
| I2C | low-speed MCU control | simple but limited bandwidth |
| CAN | robotics/industrial bus | useful for noisy systems |

## Script contract for local-first product

OpenMV scripts should emit deterministic compact JSONL or binary events:

```json
{"t": 1722321000.12, "type": "apriltag", "id": 17, "score": 0.91, "bbox": [120, 44, 52, 52], "frame_hash": "sha256:..."}
```

Do not stream raw frames to cloud. Keep frame export behind explicit policy.
