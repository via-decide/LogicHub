# Data Flow and Privacy Boundary

## Data classes

| Class | Example | Default storage | Cloud allowed? |
|---|---|---|---|
| D0 Device health | uptime, firmware version, thermal status | local + receipt | yes, if anonymized |
| D1 Event metadata | object label, count, confidence, timestamp | local | only explicit opt-in |
| D2 Derived evidence | frame hash, short signed receipt | local | receipt hash only |
| D3 Raw imagery | snapshot, video, face/body crop | local encrypted store | no by default |
| D4 Credentials | RTSP password, API keys, WiFi creds | local secret store | no |
| D5 Models/scripts | OpenMV script, TFLite model, camera config | local/versioned | manifest hash only |

## Local-first invariant

A camera system is only local-first if it can perform its primary function with no internet dependency after provisioning.

## Evidence receipt structure

```json
{
  "device_id": "cam-001",
  "source": "openmv|openipc|gateway",
  "event_type": "detection|snapshot|health|firmware_update|privacy_policy_change",
  "timestamp": "2026-07-30T12:00:00+05:30",
  "payload_hash": "sha256:...",
  "policy_id": "privacy-policy-v1",
  "export_allowed": false
}
```
