# System Architecture: OpenMV + OpenIPC Local Vision

## Layered architecture

```mermaid
flowchart TB
  subgraph EdgeSensors[Edge vision devices]
    OMV[OpenMV camera
MicroPython + image/AI events]
    OIPC[OpenIPC camera
Buildroot + RTSP + web config]
  end

  subgraph LocalGateway[Local-first gateway]
    ING[Stream/event intake]
    POL[Privacy policy engine]
    BUF[Local circular buffer]
    REC[Validation receipt writer]
    API[Local HTTP/WebSocket API]
  end

  subgraph UserApps[User surfaces]
    DASH[Local dashboard]
    MOBILE[Mobile LAN UI]
    LOGIC[LogicHub source/evidence view]
  end

  OMV -->|detections / serial / RPC / USB VCP| ING
  OIPC -->|RTSP / snapshot / health| ING
  ING --> POL
  POL --> BUF
  POL --> REC
  API --> DASH
  API --> MOBILE
  REC --> LOGIC
```

## Responsibility split

| Layer | Owns | Must not own |
|---|---|---|
| OpenMV | local detections, GPIO/serial control, small AI inference | long-term NVR storage, public cloud sync, identity authority |
| OpenIPC | local IP video stream, camera firmware replacement, stream control | arbitrary camera compatibility guarantee, biometric decisions |
| Gateway | policy, receipts, logs, stream/event correlation | raw hidden upload, silent firmware replacement |
| LogicHub | manifest, source lineage, validation evidence | safety/security claims not backed by test evidence |

## Data allowed to leave LAN by default

- device model
- firmware version
- update manifest hash
- health status
- validation receipt hash
- anonymized count metrics, if user enabled

## Data blocked by default

- raw frames
- video clips
- face/body crops
- license plates
- location-linked camera feed
- OpenMV script containing private logic
- camera credentials
- RTSP URLs and tokens
