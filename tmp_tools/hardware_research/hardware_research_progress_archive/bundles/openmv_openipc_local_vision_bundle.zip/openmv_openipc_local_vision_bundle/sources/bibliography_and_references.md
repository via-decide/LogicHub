# Bibliography and References

## OpenMV

- OpenMV GitHub README: https://github.com/openmv/openmv/blob/master/README.md
- OpenMV IDE GitHub README: https://github.com/openmv/openmv-ide/blob/master/README.md
- OpenMV documentation: https://docs.openmv.io/
- OpenMV product site: https://openmv.io/
- OpenMV paper: https://arxiv.org/abs/1711.10464
- Energy-efficient OpenMV/TinyML UAV use: https://arxiv.org/abs/2111.15481

## OpenIPC

- OpenIPC firmware repository: https://github.com/OpenIPC/firmware
- OpenIPC docs repository: https://github.com/OpenIPC/docs
- OpenIPC website: https://openipc.org
- OpenIPC software page: https://openipc.org/our-software?locale=en
- OpenIPC documentation: https://docs.openipc.org/
- OpenIPC quick start: https://docs.openipc.org/use-cases/video-surveillance/-quick-start/

## Related integration targets

- Frigate NVR: https://frigate.video/
- Home Assistant: https://www.home-assistant.io/
- RTSP reference tooling: ffmpeg/ffprobe, VLC, GStreamer.
