# LogicHub / GN8R Task Blocks

/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 360
version: 1
depends_on: none
task: Build local vision source intake. Discover OpenMV firmware, MicroPython submodule, IDE version, scripts, models, OpenIPC firmware, board profiles, docs, web UI, camera SoC/sensor metadata. Hash every accepted source.

CAUSATION:
Vision product without source identity cannot be validated. Camera result depends on firmware, model, lens, sensor, lighting, board and stream path.

CONVERGENCE PROOF:
Variables: S=sources, H=hashes, B=board identity, M=manifest. Constraint=same(S,B)=>same(H,M). Every source appears once.

Why naive fails:
- A: Treat camera model as enough. Board revision differs. Firmware bricks.
- B: Ignore model/script version. Detection changes silently.
- C: Mix raw video and metadata. Privacy boundary collapses.

EPISTEMIC_BOUNDARIES:
Facts: OpenMV firmware/scripts and OpenIPC firmware are separate systems. Target camera support depends on SoC/sensor/board.

EXECUTION_CONTRACT:
Create source manifest schema, file scanner, board intake CSV, model/script hash ledger, and validation receipt seed.

/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 420
version: 1
depends_on: local_vision_source_intake
task: Build local vision privacy graph. Model OpenMV events, OpenIPC RTSP streams, local gateway buffers, exports, cloud-update checks, receipts, and blocked data classes.

CAUSATION:
Local-first claim is false unless raw imagery, credentials, model files and exports have explicit policy boundaries.

CONVERGENCE PROOF:
Variables: D=data class, P=policy, E=edge source, X=export. Constraint=D3/D4 never leaves LAN unless P explicitly allows X.

Why naive fails:
- A: Call product private while uploading frames.
- B: Store RTSP credentials in logs.
- C: Treat frame hash and raw frame as same risk.

EPISTEMIC_BOUNDARIES:
Facts: Events, frame hashes, raw video and credentials have different sensitivity. Evidence receipt does not require video export.

EXECUTION_CONTRACT:
Implement data-class registry, policy check, receipt schema, export audit log, and negative tests for blocked raw-video upload.

/task
repo: via-decide/LogicHub
mode: logichub-v0.1
tier: T5
estimated_time: 480
version: 1
depends_on: local_vision_privacy_graph
task: Build OpenMV/OpenIPC validation pipeline. Run OpenMV serial event tests, OpenIPC RTSP/snapshot uptime tests, cloud-disconnect tests, thermal/power checks, and manifest-bound receipt generation.

CAUSATION:
Vision systems fail in field conditions: lighting, lens, encoder, WiFi, thermals and model drift. Need evidence before product claim.

CONVERGENCE PROOF:
Variables: T=test, R=result, V=validation receipt, H=source hash. Constraint=pass requires R bound to H and board identity.

Why naive fails:
- A: Demo works once. Field fails nightly.
- B: RTSP opens in VLC. Drops after 12h.
- C: Model passes sample image. Fails target lighting.

EPISTEMIC_BOUNDARIES:
Facts: No direct certification is produced. Pipeline creates engineering evidence only.

EXECUTION_CONTRACT:
Create test runner interfaces, receipt generator, RTSP probe, OpenMV VCP probe, and report renderer.
