# Validation Plan

## V0 Source validation

- Verify repository URLs.
- Pin commits/releases.
- Hash source archives and firmware/model/script files.
- Record license inventory.
- Record board/SoC/sensor model.

## V1 OpenMV bench validation

- Power measurement idle/run/inference.
- USB VCP log capture with DTR false.
- Camera frame capture and exposure lock.
- Script startup repeatability.
- Detection accuracy under target lighting.
- Event JSON/receipt generation.
- Thermal drift over 2h.
- Recovery from unplug/replug.

## V2 OpenIPC bench validation

- UART boot log captured.
- Firmware image hash recorded.
- Original firmware backup recorded, if allowed.
- Network boot verified.
- RTSP stream opens in VLC/ffprobe.
- Snapshot endpoint verified.
- Stream uptime 24h.
- Recovery method tested.
- Authentication enabled.
- No outbound cloud dependency in primary operation.

## V3 Hybrid validation

- OpenMV event correlated with OpenIPC snapshot/clip.
- Event latency measured.
- Local dashboard displays health and policy.
- Cloud disconnect test passed.
- Local-only data retention checked.
- Export policy tested.
- Source manifest linked to validation receipt.

## V4 Field pilot

- Install in one controlled real location.
- Record false positives/false negatives.
- Record thermal/network/power failures.
- Review privacy and user controls.
- Update design before commercial release.
