# Local-First Vision Product Specification

## Product concept

A local vision appliance that gives users useful visual automation without forcing raw video into a cloud platform.

## Functional requirements

- Runs primary detection/streaming function on LAN with no internet dependency.
- Stores raw video locally by default.
- Emits signed event receipts.
- Allows cloud only for explicit update, backup, or remote access settings.
- Supports source-manifested firmware/model/script versions.
- Provides a visible privacy state.

## Reference SKU ladder

| SKU | Components | Target use |
|---|---|---|
| Vision Dev Kit | OpenMV + gateway scripts | education/robotics/inspection |
| Local CCTV Kit | OpenIPC camera + local NVR setup | shops/factories/home privacy |
| Inspection Station | OpenMV + controlled lighting + fixture | manufacturing QA |
| Hybrid Local Vision Box | OpenMV events + OpenIPC stream + local dashboard | serious product MVP |

## System state machine

```mermaid
stateDiagram-v2
  [*] --> Provisioning
  Provisioning --> SourceManifested
  SourceManifested --> LocalOnly
  LocalOnly --> RecordingEnabled: user enables local storage
  RecordingEnabled --> EventValidated
  EventValidated --> ExportPending: user requests export
  ExportPending --> Exported: policy passes
  ExportPending --> Blocked: policy fails
  LocalOnly --> UpdatePending: signed update available
  UpdatePending --> Updated: verified update applied
  Updated --> SourceManifested
```
