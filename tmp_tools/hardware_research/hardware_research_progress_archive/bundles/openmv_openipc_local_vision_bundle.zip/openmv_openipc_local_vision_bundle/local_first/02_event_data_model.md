# Event Data Model

## Event schema example

```json
{
  "schema": "local-vision-event-v1",
  "device": {
    "id": "openmv-001",
    "platform": "openmv",
    "firmware": "commit-or-version",
    "source_manifest": "sha256:..."
  },
  "event": {
    "type": "object_detected",
    "label": "part_present",
    "confidence": 0.94,
    "bbox": [100, 80, 50, 60],
    "timestamp": "2026-07-30T12:00:00+05:30"
  },
  "privacy": {
    "raw_frame_stored": false,
    "cloud_export_allowed": false,
    "policy": "privacy-policy-v1"
  },
  "evidence": {
    "frame_hash": "sha256:...",
    "event_hash": "sha256:..."
  }
}
```

## Design rule

The event is useful without raw imagery. Raw imagery is optional evidence, stored locally, and exported only by explicit policy.
