#!/usr/bin/env python3
"""Hash local SatNOGS source artifacts and emit a CSV receipt."""
from __future__ import annotations
import csv, hashlib, sys
from pathlib import Path

if len(sys.argv) < 3:
    print("usage: hash_sources.py <artifact_dir> <out_csv>")
    raise SystemExit(2)

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
rows=[]
for path in sorted(p for p in root.rglob('*') if p.is_file()):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    rows.append({
        'relative_path': path.relative_to(root).as_posix(),
        'bytes': path.stat().st_size,
        'sha256': h.hexdigest(),
    })
with out.open('w', newline='', encoding='utf-8') as f:
    w=csv.DictWriter(f, fieldnames=['relative_path','bytes','sha256'])
    w.writeheader(); w.writerows(rows)
print(f'wrote {len(rows)} hashes to {out}')
