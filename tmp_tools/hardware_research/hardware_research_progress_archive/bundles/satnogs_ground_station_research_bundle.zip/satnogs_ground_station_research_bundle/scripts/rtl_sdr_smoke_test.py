#!/usr/bin/env python3
"""Receive-only SDR smoke test wrapper.

This script intentionally does not transmit. It checks whether rtl_test is available
and captures a bounded hardware-test log for a SatNOGS fixed RX station.
"""
from __future__ import annotations
import shutil, subprocess, json, datetime

result = {
    'schema_version': 'satnogs-rtl-sdr-smoke-test.v1',
    'timestamp_utc': datetime.datetime.utcnow().isoformat() + 'Z',
    'tool': 'rtl_test',
    'available': False,
    'returncode': None,
    'stdout': '',
    'stderr': '',
}

if shutil.which('rtl_test'):
    result['available'] = True
    proc = subprocess.run(['rtl_test', '-t'], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20, check=False)
    result['returncode'] = proc.returncode
    result['stdout'] = proc.stdout[-4000:]
    result['stderr'] = proc.stderr[-4000:]

print(json.dumps(result, indent=2, sort_keys=True))
