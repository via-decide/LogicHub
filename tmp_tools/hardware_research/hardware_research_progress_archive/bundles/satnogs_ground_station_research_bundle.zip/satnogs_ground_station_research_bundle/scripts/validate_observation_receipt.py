#!/usr/bin/env python3
"""Minimal validation for a SatNOGS observation receipt JSON."""
from __future__ import annotations
import json, sys
from pathlib import Path

REQUIRED = ['schema_version', 'station_id', 'start_utc', 'end_utc', 'artifacts', 'result_class']
VALID_RESULTS = {'success','partial','noise','failed','not_uploaded'}

p=Path(sys.argv[1]) if len(sys.argv)>1 else None
if not p or not p.exists():
    print('usage: validate_observation_receipt.py <receipt.json>')
    raise SystemExit(2)

data=json.loads(p.read_text())
missing=[k for k in REQUIRED if k not in data]
if missing:
    raise SystemExit(f'missing required fields: {missing}')
if data.get('schema_version') != 'satnogs-observation-receipt.v1':
    raise SystemExit('bad schema_version')
if data.get('result_class') not in VALID_RESULTS:
    raise SystemExit('bad result_class')
for item in data.get('artifacts', []):
    for k in ['path','sha256','kind']:
        if k not in item:
            raise SystemExit(f'artifact missing {k}')
print('receipt valid')
