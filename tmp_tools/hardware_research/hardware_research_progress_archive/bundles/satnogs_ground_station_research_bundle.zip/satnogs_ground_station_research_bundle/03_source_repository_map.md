# 03 — Source and Repository Map

## Official project surfaces

| Surface | Source URL | Purpose | Intake priority |
|---|---|---|---|
| SatNOGS About | https://satnogs.org/about/ | Project scope and subproject taxonomy | P0 |
| SatNOGS Docs | https://satnogs.org/documentation/ | Stack options and default architecture | P0 |
| SatNOGS Wiki Get Started | https://wiki.satnogs.org/Get_Started | Ground-station setup path | P0 |
| SatNOGS Kit Docs | https://docs.satnogs.org/projects/satnogs-kit/en/latest/introduction.html | Kit-level guided station build | P1 |
| SatNOGS Client | https://gitlab.com/librespacefoundation/satnogs/satnogs-client | Station execution client | P0 |
| SatNOGS Network | https://gitlab.com/librespacefoundation/satnogs/satnogs-network | Scheduling and observation network | P0 |
| SatNOGS DB | https://gitlab.com/librespacefoundation/satnogs/satnogs-db | Satellite/transmitter database | P0 |
| SatNOGS Rotator | https://gitlab.com/librespacefoundation/satnogs/satnogs-rotator | Mechanical rotator hardware | P1 |
| SatNOGS Rotator Controller | https://gitlab.com/librespacefoundation/satnogs/satnogs-rotator-controller | Rotator firmware/control | P1 |
| gr-satnogs | https://gitlab.com/librespacefoundation/satnogs/gr-satnogs | GNU Radio signal processing | P1 |
| satnogs-pi-gen | https://gitlab.com/librespacefoundation/satnogs/satnogs-pi-gen | Raspberry Pi image generation | P1 |
| SatNOGS Network live | https://network.satnogs.org | Ground stations, scheduling, observations | P0 |
| SatNOGS DB live | https://db.satnogs.org | Satellite/transmitter lookup | P0 |

## Repository intake rules

1. Prefer Git commit hash or release tag over branch head.
2. Save every source URL, version/ref, file count, hash, license, and usage boundary.
3. Do not fabricate CAD/PCB files from screenshots or documentation prose.
4. Do not send RF hardware into fabrication until exact official design files are exported and hashed.
5. Treat third-party SDR hardware, antennas, LNAs, and filters as external dependencies with their own datasheets/licenses.

## LogicHub semantic surfaces

| Domain | Objects |
|---|---|
| Mechanical | rotator brackets, gears, bearings, fasteners, mast, enclosure |
| Electronics/RF | SDR, LNA, filters, coax, connectors, power, ESD/lightning protection |
| Embedded Linux | Pi image, services, systemd units, client config |
| Software | Client, network API, DB API, flowgraphs, scripts |
| Operations | station ID, API key handling, observation schedule, testing flag |
| Evidence | waterfall, decoded frames, SNR, observation ID, station logs |
| Compliance | receive-only mode, antenna placement, RF safety, licensing notes |
