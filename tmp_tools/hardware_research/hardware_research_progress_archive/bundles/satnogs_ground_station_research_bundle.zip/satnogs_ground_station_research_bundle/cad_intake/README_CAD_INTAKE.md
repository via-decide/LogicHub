# CAD Intake Placeholder

This directory is intentionally empty except for this README.

Do not draw unofficial replacement CAD for SatNOGS rotator or station hardware from memory. Instead:

1. Download official CAD from the relevant Libre Space Foundation/SatNOGS repository or linked documentation.
2. Record URL, commit/tag, license, file type, and export settings.
3. Hash the raw downloaded source and exported manufacturing files.
4. Only then generate LogicHub CAD/fabrication descriptors.

Expected file classes after official intake:

- STL / STEP / DXF mechanical files
- rotator assembly drawings
- PCB design files, if applicable
- exported Gerbers, if applicable
- BOM CSV
- assembly images/instructions
