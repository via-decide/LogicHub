# 07 — Regulatory, Safety, and India Productization Notes

## Receive-only baseline

The recommended product baseline is receive-only. It should not transmit, telecommand, rebroadcast, jam, interfere, or modify RF emissions. Receive-only education stations are much simpler to reason about than transmit-capable stations.

## Compliance principles

- Verify local Indian rules before selling, installing, or publicly operating RF equipment.
- Do not include transmitting hardware in the first product unless licensing and authorization are complete.
- Keep SDR use receive-only by hardware and software policy.
- Do not instruct users to decode restricted/non-public signals.
- Include RF safety, mast safety, lightning protection, and rooftop work safety instructions.
- Institutions should appoint a responsible technical operator.

## Product positioning for India

| Segment | Offer |
|---|---|
| Engineering colleges | satellite RF lab station + curriculum |
| Maker spaces | receive-only ground station kit and workshop |
| Schools | space-data dashboard with pre-collected observations |
| Amateur radio clubs | station build + network integration service |
| Space startups | telemetry monitoring prototype and open-data workflow |
| Government/NGO labs | distributed observation education network |

## India-first product ladder

1. **Software-only classroom dashboard** using public SatNOGS data.
2. **Indoor SDR training kit** for basic RF and SDR concepts.
3. **Outdoor fixed receive-only station** with safe installation SOP.
4. **Tracked receive-only research station** with rotator and validation support.
5. **Institutional network** with service contract, maintenance, and training.

## Hard safety boundary

This bundle is not legal advice and not RF authorization. Before commercial installation, get local regulatory review for radio reception, antenna mounting, public demonstrations, rooftop safety, imports, and any transmitter-adjacent equipment.
