# SatNOGS Satellite Ground-Station Research Bundle

Generated: 2026-07-30

This bundle is a deep-research and engineering-intake pack for building a SatNOGS-style open-source satellite ground-station project. It is designed for LogicHub, Daxini OS, Zayvora, Hanuman.solutions, and future CAD/BOM/fabrication workflows.

## Scope

- Source-derived research on SatNOGS architecture, software, client, network, database, rotator, and ground-station hardware.
- Receive-only RF ground-station productization plan.
- CAD/BOM/manufacturing intake workflow for collecting official SatNOGS assets from GitLab/docs and hashing them before fabrication.
- Validation plan for SDR reception, antenna/rotator performance, observation scheduling, client-network integration, and evidence capture.
- Commercialization notes for India-focused education, RF labs, maker kits, satellite-data learning stations, and space-tech services.
- Alignment with earlier bundles: air-gapped 8MB module, drone CAD implementation, Pupper V3, FarmBot, and OpenFlexure.

## Important limitation

This bundle does not embed the official SatNOGS CAD, PCB, firmware, or image artifacts. Those should be downloaded directly from the official SatNOGS/Libre Space Foundation sources and recorded in `source_manifest.csv` using `scripts/hash_sources.py`. This avoids mixing stale copied files into fabrication workflows.

## Recommended first build path

Start with a receive-only fixed-antenna Raspberry Pi + RTL-SDR station before moving to a tracked VHF/UHF rotator station. A fixed station proves SDR, client, network account, API key, station configuration, observation upload, and local RF noise baseline with much lower mechanical risk.
