# 02 — SatNOGS Architecture Map

## System block diagram

```mermaid
flowchart TD
    SAT[LEO / Amateur / CubeSat RF transmitter]
    ANT[VHF/UHF antenna: fixed, Yagi, helical, QFH]
    RF[RF chain: coax, LNA, filter, bias tee, lightning protection]
    SDR[SDR receiver]
    HOST[Station host: Raspberry Pi / Linux PC]
    CLIENT[SatNOGS Client]
    FLOW[GNU Radio / SatNOGS flowgraphs / demodulators]
    ROT[Optional Hamlib rotator control]
    NET[SatNOGS Network: scheduling + observation upload]
    DB[SatNOGS DB: satellites + transmitter metadata]
    DASH[Dashboard / observation review / public data]
    LOGIC[LogicHub intake: CAD+BOM+config+evidence]

    SAT --> ANT --> RF --> SDR --> HOST --> CLIENT --> FLOW
    CLIENT --> NET
    CLIENT --> ROT
    NET --> DB
    NET --> DASH
    HOST --> LOGIC
    RF --> LOGIC
    ANT --> LOGIC
    ROT --> LOGIC
```

## Data-flow boundary

```text
scheduled observation
  -> station client pulls job
  -> local host configures receiver/rotator
  -> RF capture begins during satellite pass
  -> signal is demodulated/decoded where possible
  -> observation artifacts are uploaded to SatNOGS Network
  -> satellite/transmitter metadata is resolved through SatNOGS DB
  -> operator validates result quality
```

## Control surfaces

| Surface | Role | Validation evidence |
|---|---|---|
| Antenna | Captures RF energy in target bands | pass SNR, waterfall, station noise floor |
| LNA/filter/coax | Conditions weak signal before SDR | insertion loss, gain/noise budget, overload check |
| SDR | Digitizes RF spectrum | PPM calibration, sample rate stability, pass capture |
| Host | Runs Linux and SatNOGS client | uptime, logs, service status, CPU/storage thermal state |
| SatNOGS Client | Pulls jobs and executes observation | API auth, job logs, observation upload receipt |
| Rotator | Points antenna along pass path | az/el calibration, stow, homing, backlash measurement |
| Network | Schedules and stores observations | observation URL/ID, station status, community feedback |
| DB | Stores satellite/transmitter metadata | NORAD ID, transmitter, frequency, mode, status |

## Versioned product variants

```text
V0 Fixed RX EVT
  - fixed VHF/UHF antenna
  - Raspberry Pi + RTL-SDR
  - local install + network registration
  - no moving parts

V1 Tracked RX DVT
  - az/el rotator
  - Hamlib-compatible control
  - calibrated directional antenna
  - weatherproof mast/enclosure

V2 Institutional station
  - multi-band support
  - curriculum and dashboard
  - install SOP + maintenance kit
  - LogicHub source evidence and station health telemetry
```
