# 09 — LogicHub / GN8R Task Blocks

/task
repo: via-decide/LogicHub
mode: open-hardware-source-intake-v1
tier: T5
estimated_time: 360
version: 1
depends_on: none
task: Build SatNOGS source-intake manifest. Collect official docs, GitLab repos, station docs, DB/API docs, client docs, rotator CAD references, controller firmware references, image generator, and live Network/DB endpoints. Preserve URLs, refs, licenses, and hashes. Do not fabricate or infer missing CAD.

CAUSATION:
Open-source hardware fails when source authority is unclear. SatNOGS spans docs, GitLab, CAD, RF hardware, Linux images, API credentials, and public data. Need exact intake before productization.

CONVERGENCE PROOF:
Variables:
$S$ = source set
$H$ = hash ledger
$L$ = license map
$M$ = manifest
$Constraint = every accepted artifact has URL+version+hash+license+usage_boundary$

Why naive fails:
- A: Download random ZIPs. Lose provenance.
- B: Copy CAD without version. Cannot reproduce fabrication.
- C: Mix receive and transmit assumptions. Compliance risk.

EPISTEMIC_BOUNDARIES:
Facts:
- SatNOGS has Network, DB, Client, and Ground Station components.
- Official CAD/assets may live outside one repo.
Unknowns:
- Exact current CAD release selected.
- Local regulatory permissions.

EXECUTION_CONTRACT:
Create source_manifest.csv, source_manifest.schema.json, artifact hash script, missing_source_report.md, and satnogs_intake_receipt.json. No network write operations. No fabrication outputs.

---

/task
repo: via-decide/LogicHub
mode: satnogs-ground-station-validation-v1
tier: T5
estimated_time: 480
version: 1
depends_on: open_hardware_source_intake_v1
task: Build receive-only SatNOGS station validation workflow. Model RF chain, SDR host, client config, Network station entry, API-key boundary, observation artifacts, and local evidence receipts. Prove fixed antenna station before rotator.

CAUSATION:
Ground station product is only credible if reception, scheduling, upload, and evidence are reproducible. Rotator first = too many failure modes.

CONVERGENCE PROOF:
Variables:
$R$ = RF chain
$C$ = client config
$O$ = observation artifacts
$E$ = evidence receipts
$Constraint = three successful or reviewable observations with logs+artifact hashes+station config hash$

Why naive fails:
- A: Blame software when antenna/noise is bad.
- B: Upload without local artifacts. Cannot debug.
- C: Rotator errors hide RF errors.

EPISTEMIC_BOUNDARIES:
Facts:
- SatNOGS Client pulls observation jobs and uploads observations.
- Fixed station is lower risk than tracked station.
Unknowns:
- Local RF noise floor.
- Satellite pass quality.

EXECUTION_CONTRACT:
Create station_config.schema.json, observation_receipt.schema.json, validation_plan.md, rtl_sdr_smoke_test.py, and receipt validator. No transmit functions.

---

/task
repo: via-decide/LogicHub
mode: satnogs-productization-india-v1
tier: T5
estimated_time: 420
version: 1
depends_on: satnogs_ground_station_validation_v1
task: Design India-ready SatNOGS receive-only product ladder. Build BOM variants, sourcing plan, workshop curriculum, service model, risk register, compliance checklist, and installation SOP for fixed and tracked stations.

CAUSATION:
Open-source kit alone is not a product. Buyer needs safe sourcing, build steps, validation, training, maintenance, and legal clarity.

CONVERGENCE PROOF:
Variables:
$B$ = BOM variants
$S$ = sourcing
$V$ = validation
$P$ = product packages
$Constraint = no package includes transmit capability unless authorization path is documented$

Why naive fails:
- A: Sell hardware without station success proof.
- B: Ignore rooftop/weather safety.
- C: Promise satellite data without location/noise assessment.

EPISTEMIC_BOUNDARIES:
Facts:
- Receive-only education station is lower regulatory risk.
Unknowns:
- Final India compliance path.
- Site-specific antenna performance.

EXECUTION_CONTRACT:
Create product_ladder.md, india_sourcing_bom.csv, field_install_sop.md, compliance_questions.md, and pilot acceptance gates. Mark all legal items as require-human-review.
