# 08 — Commercialization and Monetisation Logic

## Product wedge

SatNOGS is already open. The monetisable layer is not proprietary enclosure branding. The valuable layer is verified integration:

- correct source intake
- correct station hardware bundle
- correct RF configuration
- working client setup
- station health monitoring
- observation evidence receipts
- curriculum and support
- local installation service

## Commercial packages

| Package | Customer | Revenue model |
|---|---|---|
| Classroom data-only bundle | schools | subscription/course pack |
| SDR starter kit | makers/students | hardware kit + workshop |
| Fixed SatNOGS receive station | colleges/clubs | kit + setup + support |
| Tracked station | RF labs/space clubs | project-based installation |
| SatNOGS-in-a-box dashboard | institutions | appliance + annual support |
| LogicHub station evidence layer | engineering teams | SaaS/local license/service |

## Differentiation

- India sourcing list and setup SOP.
- Gujarati/Hindi/English training material.
- No transmit-by-default policy.
- Verified open-source provenance ledger.
- Local evidence mirror for observations.
- Integration with Daxini/LogicHub for source-to-station traceability.

## Risks

- RF compliance confusion.
- Hardware weather reliability.
- Station performance depends heavily on location/noise/antenna.
- Support burden from Linux/SDR/network issues.
- Rotator mechanical failures.
- Community expectations around open-source attribution and contribution.

## Go threshold

A commercial pilot is justified only if a fixed receive-only station can produce repeatable observation receipts at two physically different locations with documented RF baseline, setup time, cost, and failure modes.
