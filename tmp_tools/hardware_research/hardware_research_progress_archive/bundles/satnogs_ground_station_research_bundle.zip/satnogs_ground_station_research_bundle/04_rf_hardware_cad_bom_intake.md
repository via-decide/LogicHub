# 04 — RF Ground Station Hardware and CAD/BOM Intake Plan

## Recommended baseline: fixed receive-only station

| Block | Recommended EVT choice | Reason |
|---|---|---|
| Host | Raspberry Pi 4/5 or Linux mini PC | widely supported station host class |
| Receiver | RTL-SDR-class USB SDR | low-cost, receive-only validation |
| Antenna | fixed VHF/UHF QFH, turnstile, discone, or simple V-dipole | removes rotator complexity for EVT |
| RF conditioning | LNA + band-pass filter as required | improves weak-signal reception and reduces overload |
| Cable | short, low-loss coax | VHF/UHF loss control |
| Enclosure | weather-protected host/SDR box | outdoor reliability |
| Power | 5V/USB-C supply with surge protection | station uptime |
| Grounding | mast/enclosure grounding strategy | lightning/static risk reduction |

## Tracked station add-ons

| Block | Function | Engineering risk |
|---|---|---|
| Azimuth/elevation rotator | tracks LEO passes | mechanical backlash, weather, calibration |
| Directional antenna | higher gain | pointing accuracy and polarization |
| Rotator controller | motor control interface | firmware/config/homing risk |
| Hamlib integration | rotator abstraction | config mismatch and protocol issues |

## CAD intake checklist

- Locate official SatNOGS rotator CAD source.
- Record exact GitLab repository, branch/tag/commit.
- Export STL/STEP/DXF from official files only.
- Hash each exported file.
- Confirm printer material and tolerance assumptions.
- Run mechanical interference checks for antenna load and mast interface.
- Create a fastener BOM with Indian sourcing equivalents.
- Create weatherproofing notes for UV, rain, dust, and wind load.

## BOM intake checklist

- SDR receiver model and revision.
- Host board and power adapter.
- Antenna type and frequency band.
- LNA/filter model numbers.
- Coax type, connector type, length.
- Mast mount, bearings, fasteners, enclosure, cable glands.
- Lightning/static protection plan.
- Indian sourcing alternatives with exact supplier part numbers.

## Fabrication boundary

Do not fabricate a SatNOGS rotator from this bundle alone. This bundle tells you what to collect and validate. Fabrication requires official CAD exports, printer/material settings, test fixture, bearing/fastener verification, and load testing.
