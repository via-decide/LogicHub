# 12 — Bibliography and References

Primary sources used for this bundle:

- SatNOGS About: https://satnogs.org/about/
- SatNOGS Documentation: https://satnogs.org/documentation/
- SatNOGS Wiki Get Started: https://wiki.satnogs.org/Get_Started
- SatNOGS Kit Introduction: https://docs.satnogs.org/projects/satnogs-kit/en/latest/introduction.html
- SatNOGS Client GitLab: https://gitlab.com/librespacefoundation/satnogs/satnogs-client
- SatNOGS Network GitLab: https://gitlab.com/librespacefoundation/satnogs/satnogs-network
- SatNOGS DB GitLab: https://gitlab.com/librespacefoundation/satnogs/satnogs-db
- SatNOGS Rotator GitLab: https://gitlab.com/librespacefoundation/satnogs/satnogs-rotator
- gr-satnogs GitLab: https://gitlab.com/librespacefoundation/satnogs/gr-satnogs
- satnogs-pi-gen image builder: https://librespacefoundation.gitlab.io/satnogs/satnogs-pi-gen/
- SatNOGS 14M observations milestone: https://satnogs.org/2026/05/28/new-milestone-for-satnogs-14m-observations/

Use these as source authority. Search results and live docs were used to identify the stack and current project state, but fabrication requires direct file download and hash verification.
