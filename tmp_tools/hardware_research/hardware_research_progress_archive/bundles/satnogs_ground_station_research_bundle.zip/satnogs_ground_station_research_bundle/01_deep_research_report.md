# 01 — Deep Research Report: SatNOGS Satellite Ground Station

## Executive verdict

SatNOGS is the best open-source RF/space systems bundle candidate because it is not only a hardware project. It is a complete distributed ground-station stack: community documentation, global scheduling network, crowdsourced satellite transmitter database, station client, SDR signal-processing pipeline, optional antenna rotator, and physical ground-station hardware.

The practical product opportunity is not to clone SatNOGS blindly. The opportunity is to package a verified, receive-only, India-ready SatNOGS learning and research station with clean RF documentation, source hashes, build receipts, signal-quality validation, and LogicHub-compatible hardware/software lineage.

## Source-derived facts

SatNOGS describes itself as a complete open satellite ground-station platform. Its official About page says the project provides the basis for affordable satellite ground-station manufacturing, modular integration, instrumentation, a collaborative ground-station network, community development, and automation of operator-less ground stations. It also identifies four subprojects: SatNOGS Network, SatNOGS DB, SatNOGS Client, and SatNOGS Ground Station.

The Get Started wiki describes the user path: build a station or use existing stations; options range from a simple fixed antenna with Raspberry Pi to complex multi-antenna steerable ground stations. It also states that users create a Network account, create a ground-station entry and API key, install SatNOGS Client, test setup, schedule an observation, then remove the testing flag after successful community-reviewed operation.

The documentation page says the stack is modular and scalable, based on open-source technologies and open standards. It lists configuration choices: Network/no network, SatNOGS Client or tethered operation with gPredict/Gqrx, control PC options including Raspberry Pi/other boards/PC, SatNOGS rotator or commercial rotator, and VHF/UHF antennas.

The SatNOGS Client documentation/search result states that the client pulls observation jobs from SatNOGS Network and executes them on the station host, usually a Raspberry Pi. It can optionally control a Hamlib-compatible rotator to track satellites.

The SatNOGS DB API is described as a REST API providing detailed information about satellites and transmitters. The Network API is described as a REST API used to get scheduled jobs and post observation data.

SatNOGS reached its 14,000,000th observation on 6 May 2026, making the network’s scale commercially and technically significant for open RF/space education and telemetry access.

## Architecture thesis

SatNOGS is valuable because it separates concerns cleanly:

```text
Satellite transmitters
  -> RF path through antenna/LNA/filter/coax
  -> SDR receiver
  -> local SatNOGS Client + flowgraphs/decoders
  -> SatNOGS Network job scheduling and observation upload
  -> SatNOGS DB transmitter/satellite metadata
  -> public observations, dashboards, and downstream analysis
```

For LogicHub, this is a strong cross-domain engineering object because it has:

- mechanical hardware: rotator, mounts, antenna structure, mast, enclosure
- RF/electronics: SDR, LNA, filters, bias-tee, coax, grounding, power
- embedded Linux: Raspberry Pi or compatible host image
- software services: client, network, DB, APIs, decoders
- cloud/network interface: scheduling and observation upload
- regulatory boundary: receive-only vs transmit-capable operation
- operational evidence: observations, waterfall/SNR data, station uptime, failed passes

## Recommended product framing

Do not start by selling a fully tracked rotator station. Start with a three-tier product ladder:

1. **SatNOGS Fixed RX Learning Station**
   - Raspberry Pi, RTL-SDR-class receiver, fixed VHF/UHF antenna, power, enclosure, scripts, local validation.
   - Goal: receive satellite passes and upload/test observations.

2. **SatNOGS Tracked RX Research Station**
   - Adds azimuth/elevation rotator, calibrated antenna pointing, Hamlib integration, weatherproof mounting, RF survey.
   - Goal: reliable directional reception with station-quality reports.

3. **SatNOGS Institutional RF/Space Lab**
   - Adds curriculum, dashboards, satellite-data workflows, OpenFlexure/FarmBot-style source-intake, field install SOP, maintenance.
   - Goal: schools, colleges, maker labs, space clubs, and engineering programs.

## Fit for Daxini / LogicHub

SatNOGS maps strongly to LogicHub because every station build must preserve relationships across CAD, BOM, RF configuration, Linux image, API credentials, station metadata, and observation results. A useful LogicHub workflow would fingerprint each station revision, verify hardware-source provenance, store RF calibration evidence, and compare station revisions through semantic deltas rather than file diffs alone.

## Go / No-Go

**Go for receive-only education and research station.**

**Do not go directly to transmit-capable telecommand hardware.** The user-facing product should be receive-only until licensing, amateur radio operation, RF emissions, and national regulatory constraints are formally handled.

## One next action

Build a source-intake ledger for SatNOGS: collect official docs, GitLab repos, client image, rotator CAD, rotator-controller firmware, flowgraphs, DB/API docs, and any station-specific config; record source URL, version/ref, license, hash, and usage boundary before physical build.
