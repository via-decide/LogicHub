# 06 — Validation Plan

## EVT validation stages

### Stage 0 — Source intake

- Collect official URLs for docs, client, network, DB, rotator, controller, and image generator.
- Pin each repository to commit hash or release tag.
- Hash downloaded CAD/BOM/firmware/image artifacts.
- Record license and usage boundary.

### Stage 1 — Linux host smoke test

- Boot host.
- Confirm time sync.
- Confirm disk health and free space.
- Confirm SDR enumerates via USB.
- Confirm local temperature under continuous capture.

### Stage 2 — SDR receive-only test

- Run SDR device identification.
- Run sample capture.
- Run local FM/known-signal receive test if lawful and available.
- Estimate noise floor.
- Record PPM correction.

### Stage 3 — SatNOGS client test

- Install SatNOGS Client or official image.
- Configure station ID and API key.
- Place station in testing mode.
- Pull first scheduled observation.
- Capture logs and local artifacts.

### Stage 4 — Observation quality test

- Schedule several passes with known active transmitters.
- Store waterfall/audio/IQ/log artifacts.
- Classify outcomes: success, partial, noise, failed.
- Compare antenna orientations and elevation angle.

### Stage 5 — Tracked station validation

Only after fixed station succeeds:

- Home rotator.
- Verify azimuth/elevation limits.
- Test mechanical backlash.
- Test emergency stop / stow behavior.
- Simulate pass tracking before attaching antenna.
- Verify real pass tracking with low wind load.

## Acceptance gates

| Gate | Pass condition |
|---|---|
| Source gate | all official assets have URL/ref/hash/license |
| Host gate | SDR and client run without thermal/storage errors |
| RF gate | station records predictable local RF baseline |
| Observation gate | at least 3 successful or reviewable observations |
| Upload gate | Network receives station artifacts correctly |
| Rotator gate | mechanical tracking follows commanded path within configured tolerance |
| Product gate | repeatable install SOP, BOM, validation receipts, risk mitigations |
