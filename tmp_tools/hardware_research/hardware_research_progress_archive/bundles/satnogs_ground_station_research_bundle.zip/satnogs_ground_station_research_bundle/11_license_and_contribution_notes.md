# 11 — License and Contribution Notes

## Source-derived licensing signal

SatNOGS project-principles documentation says software and hardware developed for SatNOGS are open source under copyleft licenses, and that data is freely accessible under a license requiring attribution and share-alike treatment.

SatNOGS documentation itself is published under Creative Commons Attribution-ShareAlike 4.0 International according to the docs license page/search result.

Some related Libre Space/SatNOGS hardware projects use CERN Open Hardware Licence v1.2, but the exact license must be verified per repository and per artifact before redistribution or productization.

## Commercial use warning

Do not assume one license covers every artifact. Treat each as separate:

- mechanical CAD
- PCB design files
- firmware
- Linux image/build scripts
- client/network/DB software
- documentation
- observation data
- logos/trademarks

## Productization rule

A commercial SatNOGS-compatible kit should:

- preserve attribution;
- publish required modifications where copyleft requires it;
- avoid implying official endorsement unless authorized;
- keep brand/trademark usage clean;
- separate your India-localized support material from upstream sources;
- contribute fixes upstream when appropriate.
