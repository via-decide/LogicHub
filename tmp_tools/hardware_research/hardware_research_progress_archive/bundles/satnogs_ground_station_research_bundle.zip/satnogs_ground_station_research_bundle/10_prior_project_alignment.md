# 10 — Prior Project Alignment

## With 8MB air-gapped storage module

The 8MB module can become a local station configuration cartridge for classroom mode: transmitter lists, pass schedules, lesson packs, station policies, and offline observation receipts. It should not be framed as a satellite decoder engine; it is a deterministic storage/authentication module.

## With drone CAD implementation bundle

The drone bundle contributes IMU, GPS, telemetry, enclosure, power, and field-test thinking. The SatNOGS station is safer as a receive-only RF appliance, but shares outdoor electronics, weatherproofing, power stability, and telemetry logging needs.

## With Pupper V3 bundle

Pupper V3 taught ROS2/real-time/control-loop architecture. SatNOGS uses a different domain but the same separation of concerns: high-level scheduler, local client, hardware interface, telemetry, and safety boundary.

## With FarmBot bundle

FarmBot and SatNOGS are both excellent LogicHub candidates because they combine cloud/web control, local embedded hardware, public documentation, and machine operations. FarmBot moves in a garden; SatNOGS points RF hardware at satellites.

## With OpenFlexure bundle

OpenFlexure offers lab-grade open instrument validation. SatNOGS can use the same product discipline: source intake, build receipts, calibration, environmental constraints, and operator training.

## LogicHub opportunity

The common product layer across all bundles is an engineering-provenance platform:

```text
open-source project
  -> source manifest
  -> CAD/BOM/software graph
  -> build/validation receipts
  -> productization plan
  -> localized kit/service offer
```
