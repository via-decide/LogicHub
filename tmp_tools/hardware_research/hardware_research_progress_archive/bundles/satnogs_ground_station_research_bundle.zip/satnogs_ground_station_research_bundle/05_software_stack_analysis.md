# 05 — Software Stack Analysis

## Core software layers

| Layer | Role | Notes |
|---|---|---|
| SatNOGS Client | station-side daemon that pulls jobs and executes observations | usually runs on Raspberry Pi-class host |
| SatNOGS Network | scheduling/discovery/observation upload server | global management layer |
| SatNOGS DB | satellite and transmitter metadata | REST API for satellite/transmitter information |
| gr-satnogs / flowgraphs | SDR receive/demodulate/decode path | GNU Radio-based signal processing ecosystem |
| satnogs-pi-gen | Raspberry Pi image generation | repeatable station image baseline |
| Hamlib | rotator/radio abstraction | used for compatible rotator control |

## Local-first mirror design

For a Daxini/LogicHub product, use a local evidence collector in front of cloud/network submission:

```text
SatNOGS observation result
  -> local artifact directory
  -> hash waterfall/audio/IQ/frame/log files
  -> validate station config hash
  -> upload to Network if allowed
  -> store local receipt in LogicHub
```

## Suggested local receipt schema

```json
{
  "schema_version": "satnogs-observation-receipt.v1",
  "station_id": "string",
  "observation_id": "string|null",
  "satellite_norad_id": "string",
  "transmitter_id": "string|null",
  "start_utc": "string",
  "end_utc": "string",
  "rf_chain_hash": "sha256",
  "client_config_hash": "sha256",
  "artifacts": [
    {"path": "string", "sha256": "string", "kind": "waterfall|audio|iq|log|decoded_frame"}
  ],
  "result_class": "success|partial|noise|failed|not_uploaded",
  "operator_notes": "string"
}
```

## Failure classes

| Failure | Likely layer | Diagnostic artifact |
|---|---|---|
| No signal | antenna/RF/location/scheduling | waterfall + pass geometry |
| Strong noise | RF overload/local EMI | noise-floor scan |
| Job not pulled | client/network/API key | client logs |
| Upload failed | network/API | HTTP logs and retry state |
| Rotator not moving | Hamlib/controller/mechanics | command log + az/el telemetry |
| Frequency offset | SDR PPM/Doppler/model | waterfall and metadata |
| Decoding fails | signal quality/mode mismatch | raw audio/IQ + mode config |

## Security notes

- Store API keys outside exported station artifacts.
- Never publish private station credentials in LogicHub manifests.
- For institutional deployments, keep a local evidence mirror so students can learn without modifying live station credentials.
