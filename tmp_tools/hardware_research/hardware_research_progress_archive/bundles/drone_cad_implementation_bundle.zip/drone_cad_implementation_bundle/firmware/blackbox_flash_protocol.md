# Blackbox Flash Protocol

## Flash role

The 8 MB SPI NOR stores flight logs, test evidence, and fault traces. It is not required for basic stabilization. Control firmware must tolerate flash absence.

## Record format

```c
typedef struct __attribute__((packed)) {
    uint32_t magic;          // 0x44524F4E = DRON
    uint16_t version;        // 1
    uint16_t record_type;    // sensor, control, fault, event
    uint32_t monotonic_ms;
    uint32_t seq;
    uint16_t payload_len;
    uint16_t header_crc16;
    uint8_t  payload[];
    // uint32_t payload_crc32 follows payload
} blackbox_record_t;
```

## Write rules

1. Never erase inside the high-rate control loop.
2. Buffer records in RAM and write bounded 256-byte pages.
3. Mark sectors as active/closed/corrupt using a small journal.
4. Power loss may lose the latest record but must not corrupt earlier closed records.
5. Host extractor must verify CRC before trusting data.
