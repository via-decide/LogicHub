/*
 * Drone FC Rev-A bring-up scaffold
 * Target: STM32G431-class MCU
 * Purpose: power, USB/serial, SPI flash, IMU, barometer, motor-signal safety tests.
 * This is not flight firmware.
 */

#include <stdint.h>
#include <stdbool.h>

#define BOARD_ID "DRONE_FC_REVA_EVT"
#define FLASH_JEDEC_CMD 0x9F
#define FLASH_SECTOR_SIZE 4096U
#define BLACKBOX_PAGE_SIZE 256U

static volatile bool motors_armed = false;
static volatile bool receiver_valid = false;
static volatile bool imu_ok = false;
static volatile bool power_ok = false;

void board_clock_init(void);
void gpio_init(void);
void spi1_init(void);
void i2c1_init(void);
void usb_serial_init(void);
void adc_init(void);
void motor_outputs_init_safe_low(void);
uint32_t millis(void);

uint8_t spi1_transfer(uint8_t value);
void flash_select(bool active);
void imu_select(bool active);
void serial_write_line(const char *s);

static void motor_outputs_force_safe(void) {
    motors_armed = false;
    /* TODO: drive all motor pins to inactive state. */
}

static bool safety_can_arm(void) {
    return imu_ok && power_ok && receiver_valid && !motors_armed;
}

static void flash_read_jedec(uint8_t out_id[3]) {
    flash_select(true);
    spi1_transfer(FLASH_JEDEC_CMD);
    out_id[0] = spi1_transfer(0x00);
    out_id[1] = spi1_transfer(0x00);
    out_id[2] = spi1_transfer(0x00);
    flash_select(false);
}

static void run_self_test(void) {
    uint8_t jedec[3] = {0};
    flash_read_jedec(jedec);

    /* TODO: read IMU WHOAMI and barometer ID. */
    imu_ok = true;      /* Replace with actual sensor result. */
    power_ok = true;    /* Replace with ADC rail and battery checks. */

    serial_write_line("{\"board\":\"DRONE_FC_REVA_EVT\",\"event\":\"self_test_complete\"}");
}

int main(void) {
    board_clock_init();
    gpio_init();
    motor_outputs_init_safe_low();
    spi1_init();
    i2c1_init();
    adc_init();
    usb_serial_init();

    motor_outputs_force_safe();
    run_self_test();

    while (1) {
        if (!safety_can_arm()) {
            motor_outputs_force_safe();
        }

        /* TODO: non-blocking CLI, sensor polling, blackbox ring, and test commands. */
    }
}
