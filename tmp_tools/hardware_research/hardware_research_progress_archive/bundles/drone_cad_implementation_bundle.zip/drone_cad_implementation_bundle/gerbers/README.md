# Gerber Output Notice

These files are preliminary Gerber-like placeholders generated for CAD implementation planning. They are not a replacement for KiCad-generated fabrication outputs.

Before PCB fabrication:

1. Open the KiCad project.
2. Verify symbols and footprints.
3. Run ERC.
4. Run DRC.
5. Generate fresh Gerbers and Excellon drill files from KiCad.
6. Inspect in an independent Gerber viewer.

Do not send these placeholder Gerbers directly to a factory.
