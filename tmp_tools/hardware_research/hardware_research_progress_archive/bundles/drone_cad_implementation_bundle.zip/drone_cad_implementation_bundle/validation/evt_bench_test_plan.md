# EVT Bench Test Plan

## Required tools

- Current-limited bench supply.
- Multimeter.
- Oscilloscope or logic analyzer.
- ST-Link or CMSIS-DAP probe.
- USB isolator recommended.
- No propellers installed.

## Test sequence

1. Bare board resistance check: 5V-GND and 3V3-GND.
2. Apply 5V with 100mA current limit.
3. Verify 3.3V rail.
4. Increase current limit slowly after no fault.
5. Connect SWD and read MCU ID.
6. Flash bring-up firmware.
7. Enumerate USB serial.
8. Read IMU WHOAMI.
9. Read barometer ID/pressure.
10. Read flash JEDEC ID.
11. Erase/program/read one flash sector and verify CRC.
12. Toggle motor signal outputs into logic analyzer only.
13. Verify receiver UART loopback.
14. Simulate receiver loss and verify failsafe state.
15. Record fixture result JSON.
