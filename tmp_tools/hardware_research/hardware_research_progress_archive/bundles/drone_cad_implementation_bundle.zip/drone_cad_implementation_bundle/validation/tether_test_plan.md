# Tether Test Plan

## Entry requirements

- EVT bench plan passed.
- Props inspected and installed only at this stage.
- Operator has physical kill switch access.
- Test area is open, controlled, legal, and clear of people.
- Drone is physically tethered.
- Throttle limit enabled in firmware.

## Tether test sequence

1. Confirm blackbox logging enabled.
2. Confirm failsafe on receiver-loss simulation.
3. Arm with throttle low.
4. Apply minimal throttle for motor direction verification.
5. Disarm immediately if oscillation, abnormal vibration, or unexpected yaw occurs.
6. Perform short low-throttle hover attempt only after motor order and prop direction verified.
7. Download blackbox log and inspect gyro noise, motor commands, loop time, and failsafe events.
