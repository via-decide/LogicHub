# Air-Gapped Drone Flight Controller — Rev-A CAD Implementation Bundle

This bundle is an EVT/CAD baseline for a small quadcopter flight-controller module and mechanical test enclosure. It is intended for engineering implementation, KiCad review, firmware bring-up, and bench/tether testing.

## What this bundle is

- A preliminary KiCad project for a 36 mm × 36 mm STM32G4-class flight-controller board.
- A 30.5 mm × 30.5 mm mounting pattern compatible with common quadcopter stacks.
- A sensor/storage/control architecture: STM32G431 + SPI IMU + I2C barometer + 8 MB SPI NOR blackbox + USB-C + SWD + UART + ESC signal connector.
- Reference mechanical CAD for the electronics enclosure, stack cover, test frame, arm guards, and battery tray.
- Preliminary Gerber-like outputs, drill files, and manufacturing notes.
- Firmware and host-tool scaffolds for blackbox flash test, sensor self-test, and serial bring-up.

## What this bundle is not

- Not a flight-certified product.
- Not a final KiCad ERC/DRC-clean release.
- Not a KiCad-generated Gerber release. The included Gerbers are preview/placeholders for CAD implementation planning.
- Not a complete ESC, RF link, battery charger, GPS, or autonomous mission-computer design.
- Not a guarantee of compliance with DGCA, CE, FCC, WPC, battery, or aviation regulations.
- Not safe for untethered flight until independent electrical, firmware, mechanical, and legal validation are complete.

## Recommended build sequence

1. Open `kicad/drone_fc_revA.kicad_pro` in KiCad.
2. Verify every symbol and footprint against the exact purchasable parts.
3. Replace placeholder symbols with project libraries or vendor libraries.
4. Run ERC and resolve all violations.
5. Run DRC with your PCB manufacturer's capabilities.
6. Regenerate Gerbers and drill files from KiCad.
7. Fabricate only 2–5 EVT boards first.
8. Bring up power rails with current-limited bench supply.
9. Validate SWD programming, USB enumeration, IMU SPI, barometer I2C, flash JEDEC ID, motor-signal outputs, failsafe logic, and blackbox logging.
10. Perform only prop-off and tethered tests until all safety gates pass.

## Bundle map

- `docs/` — deep research report, architecture, test strategy, risks, compliance.
- `kicad/` — preliminary KiCad project, schematic, PCB, net and pin ledgers.
- `gerbers/` — preliminary Gerber/drill placeholders for review only.
- `mechanical/` — OpenSCAD, STL previews, STEP reference envelopes, DXF plate sketches.
- `firmware/` — embedded C scaffolds for board bring-up.
- `host_tools/` — Python serial validator.
- `bom/` — engineering BOM and alternates.
- `schemas/` — JSON schemas for manifest and test evidence.
- `manufacturing/` — PCBA test plan and DFM checklist.
- `validation/` — EVT checklist, bench test, and tether test plans.
- `compliance/` — India/DGCA and product-safety notes.

## Design posture

This design separates flight-control timing from product/cloud logic. The board is local-first: it logs and validates onboard evidence locally, exposes only structured serial/USB maintenance interfaces, and is designed to be usable without cloud services. `logichub.app` can remain a marketing, checkout, documentation, or provisioning surface; it must not be a dependency for real-time flight control.
