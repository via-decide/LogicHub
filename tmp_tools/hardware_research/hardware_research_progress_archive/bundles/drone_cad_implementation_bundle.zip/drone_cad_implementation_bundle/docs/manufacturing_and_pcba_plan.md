# Manufacturing and PCBA Plan

## Prototype stage

| Stage | Quantity | Purpose |
|---|---:|---|
| Bare PCB EVT | 2–5 | Verify geometry, connector placement, mounting |
| Hand assembly EVT | 2–3 | Power, SWD, USB, sensor bring-up |
| PCBA EVT | 5–10 | Fixture development and process check |
| DVT | 20–50 | Thermal, vibration, tether, firmware tuning |
| PVT | 100+ | Assembly yield, packaging, support process |

## Required PCBA fixture tests

1. Visual inspection.
2. 5 V input current draw.
3. 3.3 V rail tolerance.
4. SWD connect and device ID.
5. Firmware flashing.
6. USB enumeration.
7. IMU WHOAMI / SPI transaction.
8. Barometer I2C transaction.
9. Flash JEDEC ID.
10. UART loopback.
11. Motor-signal pin toggling with props disabled.
12. Buzzer/LED test.
13. ADC VBAT/current sense sanity.
14. Blackbox erase/write/read CRC.

## PCBA acceptance gates

- No board ships from PCBA without logged serial number and fixture result JSON.
- No board enters flight test without passing all electrical fixture tests.
- No board is sold without regulatory and safety review for the target market.
