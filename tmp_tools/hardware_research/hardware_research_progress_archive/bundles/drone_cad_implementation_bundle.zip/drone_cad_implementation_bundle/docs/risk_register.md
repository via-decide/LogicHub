# Risk Register

| ID | Risk | Severity | Likelihood | Mitigation | Gate |
|---|---|---:|---:|---|---|
| R1 | Board boots but IMU noise is too high | High | Medium | Center IMU, solid ground plane, vibration isolation, blackbox analysis | EVT-C |
| R2 | USB VBUS backfeeds ESC/BEC rail | High | Medium | Power ORing/blocking, test USB-only and BEC-only states | EVT-A |
| R3 | SPI flash writes block control loop | High | Medium | Ring buffer, DMA/interrupt strategy, bounded write slices | Firmware EVT |
| R4 | Motor output pinmux invalid | High | Medium | Timer/pinmux review before PCB order | G0/G1 |
| R5 | 5V BEC noise resets MCU | High | Medium | Input filtering, brownout logging, LDO margin test | EVT-B |
| R6 | Mechanical frame resonance corrupts gyro | High | Medium | Soft mount, blackbox FFT, frame material change | Tether |
| R7 | Operator tests with props too early | Critical | Medium | Prop-off gate, checklist, software lockout | All |
| R8 | Regulatory violation during field test | Critical | Low-Medium | DGCA/Digital Sky review, local airspace check | G6 |
| R9 | Enclosure blocks USB or SWD access | Medium | Medium | Print-fit-test before PCBA | Mechanical EVT |
| R10 | PCBA footprint mismatch | High | Medium | 1:1 print check, vendor footprint audit | Preorder |
