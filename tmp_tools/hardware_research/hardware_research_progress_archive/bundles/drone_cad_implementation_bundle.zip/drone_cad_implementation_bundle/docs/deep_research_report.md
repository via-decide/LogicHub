# Deep Research Report — From Prototype to Drone Product Rev-A

## Executive verdict

A drone product can be started from this bundle only as an engineering prototype. The correct first product is not a full autonomous drone; it is a controlled, testable flight-controller module plus enclosure and validation harness. A full aircraft requires much more than the board: ESCs, motors, propellers, RF link, battery safety, frame stiffness, vibration isolation, firmware tuning, regulatory classification, failsafe behavior, and field test evidence.

The recommended Rev-A direction is:

- Flight controller: 36 mm × 36 mm, 30.5 mm mounting, STM32G431-class MCU.
- Sensors: SPI IMU, I2C barometer, optional magnetometer/GPS connector.
- Storage: 8 MB SPI NOR flash for blackbox logs and local evidence records.
- ESC interface: external 4-in-1 ESC connector using DShot/PWM signal outputs.
- Power: external regulated 5 V input from ESC/BEC, onboard low-noise 3.3 V rail.
- Mechanical: protected electronics enclosure and test-frame CAD, not final flight-rated carbon frame.
- Firmware posture: deterministic local control loop, structured logs, no cloud runtime dependency.

## Core feasibility assessment

### What is feasible now

1. A flight-controller PCB can be designed around a modern STM32G4, SPI IMU, barometer, USB-C, SWD, UART, and onboard flash.
2. An 8 MB SPI NOR flash can serve as a blackbox/evidence log, configuration storage, and crash trace store.
3. The board can expose local USB/serial maintenance tools without relying on cloud services.
4. A 3D-printed electronics enclosure and bench-test frame can be produced for EVT.
5. The product can be positioned as a local-first drone controller, evidence logger, or educational UAV module.

### What is not feasible from files alone

1. Safe flight cannot be guaranteed by CAD files.
2. Stability cannot be guaranteed without real IMU noise, vibration, loop-timing, motor/prop, and PID tuning tests.
3. Regulatory compliance cannot be guaranteed without jurisdiction-specific checks.
4. Printed PLA/PETG frames are not recommended for high-power flight loads.
5. A fabricated PCB cannot be ordered directly from this preliminary bundle without KiCad ERC/DRC and footprint verification.

## Product architecture

```mermaid
flowchart TD
    BAT[LiPo Battery]
    ESC[4-in-1 ESC / BEC]
    FC[Drone Flight Controller Rev-A]
    MCU[STM32G431 MCU]
    IMU[SPI IMU]
    BARO[I2C Barometer]
    FLASH[8 MB SPI NOR Blackbox]
    USB[USB-C Local Maintenance]
    SWD[SWD Debug]
    RX[Receiver / Telemetry UART]
    MOT[Motor Signal Outputs]
    LOG[Local Evidence Log]

    BAT --> ESC
    ESC -->|5V regulated| FC
    ESC -->|VBAT sense/current sense| FC
    FC --> MCU
    MCU --> IMU
    MCU --> BARO
    MCU --> FLASH
    MCU --> USB
    MCU --> SWD
    RX --> MCU
    MCU --> MOT
    MOT --> ESC
    FLASH --> LOG
```

## Electrical architecture

### MCU selection

The STM32G431CBU6-class device is chosen as a modern replacement for older F4/F7-oriented educational designs. It provides Cortex-M4 performance, FPU/DSP capability, USB device support, multiple timers, SPI/I2C/UART peripherals, ADC channels, and enough performance for a small multirotor control loop.

### Sensor topology

- IMU on SPI for deterministic high-rate gyro/accelerometer reads.
- Barometer on I2C because its update rate is low compared with gyro control.
- 8 MB SPI NOR on separate chip-select for blackbox logging.
- Optional GPS/magnetometer through UART/I2C headers rather than hard-wired into Rev-A.

### Storage topology

The onboard flash is not flight-critical control memory. It stores blackbox and evidence logs. Control firmware must continue operating if blackbox logging is disabled or flash is unavailable.

Recommended logical flash layout:

| Region | Size | Purpose |
|---|---:|---|
| Header | 4 KB | Device manifest and format version |
| Config journal | 64 KB | Durable configuration records |
| Flight blackbox ring | 7 MB | Time-series control-loop logs |
| Fault log | 512 KB | Crash/failsafe/fault traces |
| Reserved | remainder | Future proofing |

### Power topology

- Main board input: regulated 5 V from external BEC/ESC.
- Onboard 3.3 V LDO for MCU, sensors, flash.
- VBAT must be sensed through a high-value divider into ADC, not fed directly.
- Current sense must be scaled and filtered before ADC input.
- USB VBUS must not backfeed the ESC/BEC rail unless explicitly designed.

## Firmware architecture

```mermaid
flowchart TD
    BOOT[Boot]
    SELF[Power-on self-test]
    SENS[Sensor init]
    LOOP[Control loop]
    MIX[Motor mixer]
    FAIL[Failsafe manager]
    LOG[Blackbox logger]
    USB[USB/serial CLI]

    BOOT --> SELF
    SELF --> SENS
    SENS --> LOOP
    LOOP --> MIX
    LOOP --> FAIL
    LOOP --> LOG
    USB --> SELF
    USB --> LOG
```

Hard firmware rules:

1. Motor outputs remain disabled until IMU, receiver, calibration, and arming gates pass.
2. Loss of receiver signal forces disarm or configured failsafe.
3. Flash failure cannot block attitude stabilization.
4. USB maintenance cannot override armed-state safety gates.
5. Every flight-critical state transition is logged locally.

## Mechanical architecture

The included mechanical files are for electronics protection and bench/prototype use:

- Flight-controller lower tray.
- Top cover with USB-C opening.
- Stack standoff positions.
- Battery tray reference.
- Prop-guard/arm-guard concept.
- Reference X-frame geometry.

For real flight, use carbon fiber, G10, or professionally analyzed composite/nylon-CF structures for arms and main plates. 3D-printed PLA/PETG is acceptable for enclosure, guards, jigs, and tether test fixtures, not high-load final arms.

## Safety gates

| Gate | Required evidence |
|---|---|
| G0 schematic review | ERC clean, pinmux ledger reviewed |
| G1 PCB review | DRC clean, stackup and clearances verified |
| G2 power bring-up | Current-limited supply, 3.3 V ripple, no thermal runaway |
| G3 firmware bring-up | SWD, USB, IMU, baro, flash, motor-signal test |
| G4 prop-off test | All motor outputs correct with no props |
| G5 tether test | Physical tether, low throttle, operator kill switch |
| G6 open-area test | Legal airspace, fail-safe verified, logs reviewed |

## Commercial product path

1. EVT-A: board powers, firmware talks to sensors, no motors connected.
2. EVT-B: ESC connected, prop-off motor signal tests.
3. EVT-C: tethered hover with low power and blackbox review.
4. DVT: redesigned board after noise/vibration/power evidence.
5. PVT: PCBA panelization, fixture tests, enclosure tooling, compliance preparation.
6. Release candidate: only after legal/regulatory review and repeatable flight logs.

## Primary risks

- IMU vibration and board resonance.
- Noisy 5 V rail from ESC/BEC.
- USB VBUS backfeed.
- SPI signal integrity and flash write latency.
- Wrong pinmux for timers, USB, SWD, and SPI.
- ESC protocol timing jitter.
- Brownout during arming or flash writes.
- Operator over-trust in early firmware.
- Regulatory non-compliance.

## Recommended next action

Open the KiCad project, replace placeholder parts with exact vendor symbols/footprints, run ERC/DRC, then order a 2-board bare-PCB test before PCBA. Do not order assembled boards until the footprint and pinmux ledgers are independently reviewed.
