# Electrical Architecture — Drone FC Rev-A

## Board class

- Board size: 36 mm × 36 mm.
- Mounting: 30.5 mm × 30.5 mm, M3 stack holes.
- Layers: 4-layer strongly recommended.
- Prototype fallback: 2-layer possible only for low-speed bring-up, not preferred for flight.

## Suggested stackup

| Layer | Role |
|---|---|
| L1 | Signals and components |
| L2 | Solid ground plane |
| L3 | 3.3 V, 5 V, sensor islands, slow signals |
| L4 | Signals and connectors |

## Power domains

| Domain | Source | Consumers | Notes |
|---|---|---|---|
| USB_VBUS | USB-C | USB detect only | Do not backfeed 5V_BEC |
| 5V_BEC | ESC/BEC connector | LDO input, optional receiver | Add fuse/TVS in production |
| 3V3_DIG | LDO | MCU, flash, baro | Bulk + local decoupling |
| 3V3_IMU | 3V3_DIG via ferrite/0R | IMU | Keep quiet; validate noise |
| VBAT_SENSE | Battery divider | MCU ADC | High-value divider + RC filter |
| CURR_SENSE | ESC current output | MCU ADC | Scale to ADC-safe range |

## Core nets

| Net | MCU pin candidate | Function |
|---|---|---|
| USB_DM | PA11 | USB D- |
| USB_DP | PA12 | USB D+ |
| SWDIO | PA13 | Debug |
| SWCLK | PA14 | Debug |
| SPI1_SCK | PA5 | IMU/flash SCK |
| SPI1_MISO | PA6 | IMU/flash MISO |
| SPI1_MOSI | PA7 | IMU/flash MOSI |
| IMU_CS | PB0 | IMU chip select |
| FLASH_CS | PB1 | Flash chip select |
| I2C1_SCL | PB6 | Barometer/GPS-mag header |
| I2C1_SDA | PB7 | Barometer/GPS-mag header |
| MOTOR1 | PA8 | Timer output |
| MOTOR2 | PA9 | Timer output |
| MOTOR3 | PA10 | Timer output |
| MOTOR4 | PB8 | Timer output candidate |
| RX_UART_TX | PA2 | Receiver/telemetry TX |
| RX_UART_RX | PA3 | Receiver/telemetry RX |
| GPS_TX | PB10 | GPS UART TX |
| GPS_RX | PB11 | GPS UART RX |
| BUZZER | PB9 | Buzzer drive |
| STATUS_LED | PC13 | Status LED |
| VBAT_ADC | PA0 | Battery ADC |
| CURRENT_ADC | PA1 | Current ADC |

## Layout rules

- Place IMU near board center and away from USB connector/standoffs.
- Do not route SPI under switching regulator or motor/ESC harness.
- Use solid ground plane under IMU and MCU.
- Keep USB differential pair short and impedance-aware.
- Route SWD to edge pads or header.
- Separate analog sense traces from motor signal connector.
- Add test pads for 5 V, 3.3 V, GND, BOOT0, NRST, SPI, I2C, and UART.
