# Firmware Architecture — Drone FC Rev-A

## Firmware targets

This bundle is designed for a custom STM32G4 firmware bring-up path first. Later, the board may be mapped to Betaflight/iNav/ArduPilot-style target files if pinmux and sensor support are aligned.

## Control loop model

| Loop | Rate target | Notes |
|---|---:|---|
| Gyro read | 1–8 kHz | Depends on IMU ODR and filtering |
| Attitude estimator | 500 Hz–2 kHz | Begin lower for safety |
| PID controller | 500 Hz–2 kHz | Start conservative |
| Motor update | 500 Hz–4 kHz | DShot/PWM implementation-specific |
| Barometer | 25–100 Hz | Not flight-stabilization critical |
| Blackbox log | configurable | Never block control loop |
| Serial CLI | event-driven | Disabled/restricted while armed |

## Safety state machine

```mermaid
stateDiagram-v2
    [*] --> BOOT
    BOOT --> SELF_TEST
    SELF_TEST --> SAFE_IDLE: sensors_ok and power_ok
    SELF_TEST --> FAULT_LOCKOUT: fail
    SAFE_IDLE --> ARMED: arm_command and rx_valid and throttle_low
    ARMED --> FLIGHT_ACTIVE: motor_output_enabled
    FLIGHT_ACTIVE --> FAILSAFE: rx_lost or imu_fault or brownout_warning
    FAILSAFE --> DISARMED: motors_cut
    DISARMED --> SAFE_IDLE: reset_conditions_clear
    FAULT_LOCKOUT --> SAFE_IDLE: operator_clear and diagnostics_pass
```

## Non-negotiable rules

1. No arming before IMU self-test passes.
2. No arming if receiver absent or throttle is not low.
3. No USB command may force motors while armed unless a bench-test jumper is installed.
4. Blackbox writes must be asynchronous or bounded.
5. Brownout warning must inhibit arming and log evidence.
