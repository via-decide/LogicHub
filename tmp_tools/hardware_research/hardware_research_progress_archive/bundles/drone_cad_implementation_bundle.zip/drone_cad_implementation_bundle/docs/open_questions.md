# Open Engineering Questions Before Fabrication

1. Exact MCU package: LQFP-48 or UFQFPN? Update schematic, footprint, and PCBA process accordingly.
2. IMU choice: ICM-42688-P/MPU6000/BMI270? Firmware support and noise behavior must drive choice.
3. Target firmware: custom firmware first, Betaflight/iNav/ArduPilot target later?
4. ESC protocol: PWM, OneShot, DShot150/300/600? Verify timer/DMA mapping.
5. Barometer required? If product is acro-only, barometer can be depopulated.
6. Flash size: 8MB minimum or 16/32MB for stronger blackbox evidence?
7. RF module and compliance: external receiver only in Rev-A, or onboard receiver later?
8. Power source: external BEC only, or onboard buck from VBAT in DVT?
9. Enclosure material: PETG, PA12, nylon-CF, or injection molded PC/ABS?
10. Product category: educational flight controller, complete drone kit, or local-first evidence logger?
