# Source Bibliography

These are the primary external sources used to shape this CAD implementation bundle. Verify current versions before release.

1. STMicroelectronics — STM32G431CB product family page and datasheet. https://www.st.com/en/microcontrollers-microprocessors/stm32g431cb.html
2. Bosch Sensortec — BMI270 datasheet. https://www.bosch-sensortec.com/media/boschsensortec/downloads/datasheets/bst-bmi270-ds000.pdf
3. Infineon — DPS310 datasheet. https://www.infineon.com/assets/row/public/documents/24/49/infineon-dps310-datasheet-en.pdf
4. Winbond — W25Q64JV SPI NOR flash datasheet. https://www.digikey.com/en/htmldatasheets/production/2091408/0/0/1/w25q64jv.html
5. Betaflight — Hardware reference. https://betaflight.com/docs/wiki/getting-started/hardware
6. Betaflight — Flight-controller manufacturer design guidelines. https://www.betaflight.com/docs/development/manufacturer/manufacturer-design-guidelines
7. Betaflight — Blackbox flight data recorder documentation. https://www.betaflight.com/docs/development/Blackbox
8. Ministry of Civil Aviation / PIB — Drone Rules 2021 announcement. https://www.pib.gov.in/Pressreleaseshare.aspx?PRID=1749154
9. Digital Sky / DGCA — Drone rules and airspace references. https://digitalsky.dgca.gov.in/
10. Cheng, West, Einstein — End-to-end analysis and design of a drone flight controller. https://arxiv.org/abs/1802.05802
11. Koch, Mancuso, Bestavros — Neuroflight. https://arxiv.org/abs/1901.06553
