// Lightweight prop guard concept for low-power testing only.
prop_radius = 64;
ring_width = 4;
ring_height = 3;
strut_width = 4;

module prop_guard(){
    difference(){
        cylinder(h=ring_height, r=prop_radius+ring_width, $fn=128);
        translate([0,0,-1]) cylinder(h=ring_height+2, r=prop_radius, $fn=128);
    }
    for(a=[0,90,180,270]) rotate([0,0,a]) translate([prop_radius/2,0,ring_height/2]) cube([prop_radius, strut_width, ring_height], center=true);
}

prop_guard();
