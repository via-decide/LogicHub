// Reference X-frame geometry for CAD planning only.
// Do not use 3D printed PLA/PETG arms for high-power flight.

arm_len = 125;
arm_width = 14;
arm_thick = 5;
center_plate = 60;
motor_mount_d = 22;
motor_hole_spacing = 16;
hole_d = 3;

module arm(){
    difference(){
        hull(){
            translate([0,0,0]) cube([center_plate/2, arm_width, arm_thick], center=true);
            translate([arm_len,0,0]) cylinder(h=arm_thick, d=motor_mount_d, center=true, $fn=48);
        }
        translate([arm_len,0,-arm_thick]) cylinder(h=arm_thick*3, d=5, center=false, $fn=32);
        for(a=[0,90]) for(s=[-1,1]) rotate([0,0,a]) translate([arm_len, s*motor_hole_spacing/2, -arm_thick]) cylinder(h=arm_thick*3, d=hole_d, $fn=24);
    }
}

module frame(){
    difference(){
        union(){
            for(a=[45,135,225,315]) rotate([0,0,a]) arm();
            cube([center_plate, center_plate, arm_thick], center=true);
        }
        for(ix=[-1,1]) for(iy=[-1,1]) translate([ix*15.25,iy*15.25,-10]) cylinder(h=20,d=3.2,$fn=32);
    }
}

frame();
