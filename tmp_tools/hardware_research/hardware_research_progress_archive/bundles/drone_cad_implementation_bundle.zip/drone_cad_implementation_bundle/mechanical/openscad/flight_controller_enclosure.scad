// Flight Controller Enclosure Rev-A
// Units: mm
// Purpose: prototype protective tray and cover for 36x36 mm board with 30.5x30.5 mounting

board_x = 36;
board_y = 36;
board_z = 1.6;
wall = 1.6;
clearance = 0.5;
tray_z = 5.0;
cover_z = 4.0;
standoff_d = 5.0;
hole_d = 3.2;
mount_pitch = 30.5;

module rounded_box(x,y,z,r=2){
    hull(){
        for(ix=[-1,1]) for(iy=[-1,1])
            translate([ix*(x/2-r), iy*(y/2-r), 0]) cylinder(h=z, r=r, $fn=32);
    }
}

module fc_tray(){
    difference(){
        rounded_box(board_x + 2*wall + 2*clearance, board_y + 2*wall + 2*clearance, tray_z, 2.2);
        translate([0,0,1.2]) rounded_box(board_x + 2*clearance, board_y + 2*clearance, tray_z, 1.4);
        // USB-C side window
        translate([0,-(board_y/2+wall+clearance),2.8]) cube([12,3,4], center=true);
        // Mounting holes
        for(ix=[-1,1]) for(iy=[-1,1])
            translate([ix*mount_pitch/2, iy*mount_pitch/2, -0.5]) cylinder(h=tray_z+1, d=hole_d, $fn=32);
    }
    // standoffs
    for(ix=[-1,1]) for(iy=[-1,1])
        translate([ix*mount_pitch/2, iy*mount_pitch/2, 0])
        difference(){
            cylinder(h=tray_z-0.8, d=standoff_d, $fn=32);
            translate([0,0,-0.5]) cylinder(h=tray_z+1, d=hole_d, $fn=32);
        }
}

module fc_cover(){
    difference(){
        translate([0,0,0]) rounded_box(board_x + 2*wall + 2*clearance, board_y + 2*wall + 2*clearance, cover_z, 2.2);
        translate([0,0,-0.2]) rounded_box(board_x + 2*clearance, board_y + 2*clearance, cover_z-1.0, 1.4);
        translate([0,-(board_y/2+wall+clearance),1.8]) cube([12,3,3.5], center=true);
        for(ix=[-1,1]) for(iy=[-1,1])
            translate([ix*mount_pitch/2, iy*mount_pitch/2, -0.5]) cylinder(h=cover_z+1, d=hole_d, $fn=32);
        // ventilation slots away from IMU center
        for(x=[-12,-6,6,12]) translate([x,10,cover_z-0.6]) cube([3,10,2], center=true);
    }
}

fc_tray();
translate([50,0,0]) fc_cover();
