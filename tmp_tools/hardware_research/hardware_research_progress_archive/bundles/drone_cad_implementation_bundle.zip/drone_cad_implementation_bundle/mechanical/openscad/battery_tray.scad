// Battery tray reference for 4S/3S pack strap mounting.
tray_x = 80;
tray_y = 38;
tray_z = 3;
strap_slot_x = 6;
strap_slot_y = 32;

module battery_tray(){
    difference(){
        cube([tray_x,tray_y,tray_z], center=true);
        for(x=[-22,22]) translate([x,0,0]) cube([strap_slot_x,strap_slot_y,tray_z+2], center=true);
        for(ix=[-1,1]) for(iy=[-1,1]) translate([ix*15.25,iy*15.25,-2]) cylinder(h=6,d=3.2,$fn=32);
    }
}

battery_tray();
