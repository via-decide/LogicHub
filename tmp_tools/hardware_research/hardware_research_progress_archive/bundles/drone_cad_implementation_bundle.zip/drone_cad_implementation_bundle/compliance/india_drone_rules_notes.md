# India Drone Compliance Notes

This file is not legal advice. It is a design checklist to prevent obvious product mistakes.

## Current design posture

The Rev-A bundle should be treated as a prototype/research drone controller. Do not market it as a fully compliant drone aircraft without formal classification, registration, pilot, airspace, and safety review.

## Checklist before outdoor operation in India

- Determine all-up weight category: nano, micro, small, medium, or large.
- Check Digital Sky airspace map for green/yellow/red zone status.
- Confirm whether UIN, type certificate, remote pilot certificate, or operating permissions apply.
- Avoid airports, restricted areas, crowds, and sensitive locations.
- Do not fly beyond visual line of sight unless permitted by applicable rules.
- Maintain flight logs, failsafe evidence, and incident evidence.
- Verify RF module legality separately through applicable Indian rules and WPC requirements.

## Design safety features to consider before commercialization

- Geofence readiness.
- No-permission/no-takeoff compatibility if required for target market.
- Real-time tracking beacon if required.
- Return-to-home only after GPS and failsafe maturity.
- Blackbox evidence preservation after crash.
- Tamper-evident firmware and configuration changes.
