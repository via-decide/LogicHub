#!/usr/bin/env python3
"""Host-side serial validator scaffold for Drone FC Rev-A.

Usage:
  python drone_fc_serial_validator.py --port /dev/ttyACM0 --baud 115200

The board firmware should return newline-delimited JSON events.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass

try:
    import serial  # type: ignore
except ImportError:  # pragma: no cover
    serial = None


@dataclass(frozen=True)
class TestResult:
    name: str
    passed: bool
    evidence: dict


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", required=True)
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--timeout", type=float, default=5.0)
    args = parser.parse_args()

    if serial is None:
        print(json.dumps({"status": "error", "error": "pyserial not installed"}))
        return 2

    ser = serial.Serial(args.port, args.baud, timeout=0.5)
    deadline = time.time() + args.timeout
    events = []

    while time.time() < deadline:
        line = ser.readline().decode("utf-8", errors="replace").strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            events.append({"raw": line, "parse_error": True})

    tests = [
        TestResult(
            name="self_test_event_seen",
            passed=any(e.get("event") == "self_test_complete" for e in events if isinstance(e, dict)),
            evidence={"event_count": len(events), "events": events[:10]},
        )
    ]

    report = {
        "schema_version": "drone_fc_serial_validation.v1",
        "port": args.port,
        "tests": [t.__dict__ for t in tests],
        "passed": all(t.passed for t in tests),
    }
    print(json.dumps(report, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
