# DFM Checklist

## PCB

- 4-layer board selected.
- Manufacturer trace/space capabilities confirmed.
- USB-C footprint verified with exact connector.
- MCU footprint checked against package variant.
- IMU orientation marking visible.
- Test pads accessible after enclosure assembly.
- No copper under antenna area if RF module added later.
- Mounting holes connected to chassis/ground only by explicit design.
- Board edge does not interfere with enclosure or standoffs.

## Assembly

- Component polarities visible.
- Buzzer/LED placement does not block enclosure.
- Connectors have mechanical strain relief.
- No tall components under battery tray.
- PCBA panel tabs do not cut through sensitive traces.

## Mechanical

- USB-C cutout includes cable clearance.
- SWD access available on prototype enclosure.
- Standoffs align with 30.5 mm mounting pattern.
- Venting avoids direct debris path to IMU.
- Snap-fit tabs are not final until material-specific testing.
