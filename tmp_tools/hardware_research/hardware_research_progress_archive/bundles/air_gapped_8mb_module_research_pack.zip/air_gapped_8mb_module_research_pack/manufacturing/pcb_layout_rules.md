# PCB Layout Rules

## Board stack

Prototype: 2-layer acceptable if SPI is slow and layout is compact.  
Production: 4-layer recommended if enclosure, EMI, USB, ESD, or high-speed SPI margin matters.

Recommended 4-layer stack:

```text
L1 Signal + components
L2 Solid GND plane
L3 Power / secondary signals
L4 Signal / test pads
```

## Placement rules

- Place flash within 20–30mm of MCU if possible.
- Place crystal and load capacitors directly next to XTAL pins.
- Place 100nF capacitors on the same side as ICs where possible.
- Place USB ESD device close to connector.
- Place test pads on bottom side for pogo fixture.
- Keep programming access available for EVT and DVT.

## Routing rules

- Route SCK first and keep it short.
- Avoid routing SCK under crystal.
- Avoid routing reset parallel to SCK.
- Use ground reference under SPI traces.
- Add series resistor footprints on SCK and MOSI for tuning.
- Do not route analog rail sensing near SCK if ADC readings matter.
- Maintain clearance around USB connector shell and mounting holes.

## Test points

Required:

```text
5V, 3V3, GND, RESET, TX, RX, DTR,
SCK, MOSI, MISO, CS, WP, HOLD,
factory_mode, status_led
```

## KiCad rule requirements

- net classes: POWER_5V, POWER_3V3, SPI, UART, RESET, CRYSTAL, TEST
- ERC rule: no unconnected WP#/HOLD#/CS
- DRC rule: minimum trace/space according to fab, not default-only
- fabrication output: Gerber, drill, IPC-356 netlist if available, BOM, CPL/XY, assembly drawing
