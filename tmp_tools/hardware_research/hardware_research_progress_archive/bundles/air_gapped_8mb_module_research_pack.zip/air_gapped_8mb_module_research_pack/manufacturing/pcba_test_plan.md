# PCBA and Factory Test Plan

## Incoming inspection

- Confirm PCB revision and Gerber hash.
- Confirm solder mask, silkscreen, drill, and board outline.
- Confirm component reel labels match approved BOM.
- Confirm flash part marking and voltage family.
- Confirm USB-UART part authenticity if using FTDI.

## In-circuit checks

- 5V to GND resistance.
- 3V3 to GND resistance.
- RESET pull-up presence.
- CS#/WP#/HOLD# bias resistors.
- Crystal load capacitor placement.

## Programming flow

```text
connect fixture
-> power current-limit on
-> read MCU signature
-> flash bootloader / firmware
-> set fuses
-> verify flash
-> read W25Q64 JEDEC ID
-> write factory header
-> run flash page test
-> lock if production policy requires
-> print label / record serial
```

## Acceptance tests

| Test | Pass condition |
|---|---|
| MCU signature | expected signature returned |
| Firmware hash | exact expected image hash |
| Flash ID | expected manufacturer/device ID |
| 3V3 rail | within tolerance during erase/program |
| Page write/read | CRC32 match |
| Sector erase | all bytes `0xFF` |
| Manifest A/B | both valid after factory format |
| Serial command parser | rejects malformed frames |
| Reset recovery | boots into valid IDLE_LOCKED or SAFE_MODE |
| Enclosure final | device communicates through final port opening |

## Lot records

Store per-unit:

- serial number,
- PCB revision,
- firmware version/hash,
- flash JEDEC ID,
- test timestamp,
- test fixture version,
- pass/fail result,
- operator or station ID,
- packaging/seal ID.
