# Bench Validation Plan

## Phase B0 — Pre-power inspection

- Confirm no shorts between 5V/GND and 3V3/GND.
- Confirm W25Q64 VCC is not tied to 5V.
- Confirm ATmega VCC/AVCC connected and decoupled.
- Confirm reset pull-up installed.
- Confirm CS# has a safe high state during reset.
- Confirm WP#/HOLD# are not floating.

## Phase B1 — Power validation

Measurements:

- USB 5V no-load
- 3V3 regulator no-load
- ATmega VCC under reset
- flash VCC under active SPI
- current at idle
- current during flash erase/program

Pass gate:

- 3V3 remains inside flash datasheet range during erase/program.
- No regulator thermal issue after 30 minutes idle.

## Phase B2 — Clock and reset validation

- Confirm oscillator frequency with scope or logic analyzer.
- Confirm DTR produces reset pulse.
- Confirm bootloader upload succeeds five consecutive times.
- Confirm reset during flash operation returns to safe state.

## Phase B3 — SPI validation

- Read JEDEC ID 1,000 times.
- Sweep SPI clock down and up.
- Verify no MISO errors.
- Capture SCK/MOSI/MISO/CS waveforms.

## Phase B4 — Flash integrity validation

- Erase sector.
- Verify erased state equals `0xFF`.
- Program walking patterns: `0x00`, `0xFF`, `0xAA`, `0x55`, pseudo-random.
- Read back and compute CRC32.
- Repeat across at least 64 sectors.

## Phase B5 — Power-loss fault injection

Inject reset or power drop during:

- sector erase,
- page program,
- manifest write,
- superblock promotion,
- receipt write.

Pass gate:

- previous valid manifest always remains recoverable.
- no partially written object becomes active.
- device enters SAFE_MODE when metadata cannot be trusted.

## Phase B6 — Long-run test

- 24-hour loop: random write to staging, verify, abort.
- 24-hour loop: read-only random object access.
- USB disconnect/reconnect every 10 minutes.
- Log all CRC mismatches, timeouts, resets, and serial framing errors.
