# Phase-Gate Roadmap

## P0 — Architecture sanity lock

Deliverables:

- Final voltage-domain decision.
- Locked prototype BOM.
- Threat-model statement.
- Memory-map v0.1.
- Serial protocol v0.1.

Exit gate:

- The project no longer claims LLM inference on ATmega328P.
- The product is framed as offline deterministic storage/rule execution.

## P1 — Breadboard proof

Deliverables:

- Breadboard wiring.
- Flash JEDEC ID read.
- Erase/program/read test.
- Host Python validation script.
- Bench log.

Exit gate:

- 10,000 random page read/write verifications pass.
- Reset during staging write never promotes a bad manifest.

## P2 — Proto PCB EVT

Deliverables:

- KiCad schematic.
- PCB v0.1.
- PCBA test fixture.
- Firmware v0.1.
- Enclosure v0.1.

Exit gate:

- 10 EVT boards pass factory test.
- No power or level-shifting defect.
- All test points accessible.

## P3 — DVT reliability

Deliverables:

- Revised PCB v0.2.
- Power-loss test jig.
- Environmental sanity tests.
- Enclosure v0.2.
- Compliance pre-scan.

Exit gate:

- No unrecoverable manifest corruption across 1,000 interrupted writes.
- EMI pre-scan has no major blocker.
- Enclosure survives repeated insertion/removal.

## P4 — PVT pilot

Deliverables:

- Production BOM.
- Assembly instructions.
- Test station scripts.
- Serialization system.
- Packaging.

Exit gate:

- 50–100 units assembled.
- Test yield target met.
- Failure pareto documented.

## P5 — Commercial launch

Deliverables:

- logichub.app product page.
- Local bridge utility.
- User manual.
- Support/recovery process.
- Compliance classification memo.

Exit gate:

- Users can buy, connect, verify, and use module without private data leaving the local host by default.
