# Compliance Checklist

This is not legal advice. Treat it as a planning checklist before lab engagement.

## India

Check BIS CRS applicability before sale/import. BIS currently lists many electronics categories under Scheme II / Compulsory Registration, including categories such as power adaptors, IT/AV equipment, barcode readers, smart card readers, and USB external storage categories. A small 8MB custom cartridge may not fit cleanly into a listed class, but the final marketed category matters.

Actions:

- Ask a BIS/CRS lab or compliance consultant to classify the exact product.
- Avoid bundling a non-certified power adapter.
- Use USB bus power if possible.
- Maintain BOM, labels, test reports, user manual, and importer/manufacturer details.

## United States

A USB digital device may be an unintentional radiator. FCC Part 15 equipment authorization/SDoC planning is required before marketing unless a clear exemption applies.

Actions:

- Pre-scan emissions before tooling.
- Keep clock/SPI edges controlled.
- Add ESD/EMI provisions.
- Prepare user labeling and compliance statement.

## European Union

Common planning items:

- CE marking route,
- EMC Directive,
- RoHS,
- WEEE if selling electronics in the EU,
- USB-C mechanical/electrical requirements if USB-C is used.

Actions:

- Use RoHS-compliant components.
- Maintain technical file.
- Avoid using USB logo without required USB-IF compliance/licensing.

## Manufacturing quality

Use IPC-A-610 acceptance criteria language for assembly inspection and set the expected class with the PCBA vendor.

## Minimum documentation pack

- Schematic PDF
- PCB fabrication outputs
- BOM with manufacturer part numbers
- Assembly drawing
- Firmware version and hash
- Test procedure
- User manual
- Compliance classification memo
- Risk register
