# Bibliography and Source Notes

This pack used current web research plus the supplied project blueprint. The main design conclusions are grounded in official component datasheets/application notes and regulatory/manufacturing references.

## Component and hardware sources

1. Microchip — ATmega328P product page  
   URL: https://www.microchip.com/en-us/product/ATmega328p  
   Used for: 32KB flash, 1KB EEPROM, 2KB SRAM, I/O count, SPI/USART capability, watchdog and power modes.

2. Microchip AN2519 — AVR Microcontroller Hardware Design Considerations  
   URL: https://www.microchip.com/en-us/application-notes/an2519  
   Used for: power, reset, oscillator, decoupling, and layout review guidance.

3. Microchip online AVR hardware guidelines  
   URL: https://onlinedocs.microchip.com/  
   Used for: reset active-low behavior and hardware-design topics.

4. Winbond / DigiKey W25Q64JV Datasheet  
   URL: https://www.digikey.com/en/htmldatasheets/production/2091408/0/0/1/w25q64jv.html  
   Used for: 64Mbit/8MByte density, 2.7V–3.6V supply, SPI modes, 4KB sectors, 256-byte pages, erase/program endurance, operating temperature, security registers.

5. FTDI FT232R Datasheet  
   URL: https://ftdichip.com/Support/Documents/DataSheets/ICs/DS_FT232R.pdf  
   Used for: USB-UART bridge and DTR/handshake capability.

6. Arduino UNO Rev3 documentation  
   URL: https://docs.arduino.cc/hardware/uno-rev3/  
   Used for: ATmega328P board architecture and DTR-to-reset via 100nF capacitor reference.

## Security and reliability sources

7. Power-Based Side-Channel Attack for AES Key Extraction on the ATMega328 Microcontroller  
   URL: https://arxiv.org/abs/2203.08220  
   Used for: warning that ATmega-class MCUs should not be treated as strong physical key vaults.

8. FirmUSB: Vetting USB Device Firmware using Domain Informed Symbolic Execution  
   URL: https://arxiv.org/abs/1708.09114  
   Used for: USB device security risk and BadUSB-style threat framing.

9. USBee: Air-Gap Covert-Channel via Electromagnetic Emission from USB  
   URL: https://arxiv.org/abs/1608.08397  
   Used for: advanced caveat that USB-connected systems are not perfect air gaps.

10. JEDEC JESD47M:2025 — Stress-Test-Driven Qualification of Integrated Circuits  
   URL: https://shop.standards.ie/en-ie/standards/jedec-jesd47m-2025-1137371_saig_jedec_jedec_3652738/  
   Used for: qualification planning language.

## Manufacturing and compliance sources

11. BIS Scheme II / Compulsory Registration  
   URL: https://www.bis.gov.in/product-certification/products-under-compulsory-certification/scheme-ii-registration-scheme/  
   Used for: India compliance screening and product-category caution.

12. FCC Part 15 Scope and Subpart B  
   URL: https://www.law.cornell.edu/cfr/text/47/15.1  
   URL: https://www.law.cornell.edu/cfr/text/47/15.101  
   Used for: unintentional radiator / digital-device marketing requirements.

13. EU CE marking overview  
   URL: https://europa.eu/youreurope/business/product-requirements/labels-markings/ce-marking/  
   Used for: EU manufacturer responsibility and technical-file planning.

14. IPC-A-610 overview  
   URL: https://www.ipc.org/meet-your-standards  
   Used for: assembly acceptance and inspection planning.

## Source caveats

- Current component prices were not treated as fixed because marketplace prices change rapidly.
- Compliance classification depends on final product category, bundled accessories, target geography, and labeling.
- Security recommendations are architecture guidance, not certification or legal advice.
