# Architecture Decision Log

## ADR-001 — Use ATmega328P only as prototype controller

Status: accepted for prototype; not accepted as AI compute engine.

Reason:
The ATmega328P is easy to breadboard and has a mature toolchain, but its RAM and flash are far too small for modern reasoning models. It should control flash, verify manifests, and execute compact deterministic rules.

## ADR-002 — Treat W25Q64 as private object store

Status: accepted.

Reason:
The 8MB flash is sufficient for manifests, rule packs, receipts, license state, small scripts/bytecode, and structured lookup tables. It is not RAM and must be accessed through page/sector operations.

## ADR-003 — Avoid direct web access to private module contents

Status: accepted.

Reason:
A web application with network access is not an air-gap. logichub.app should act as the commercial portal and public demo surface. Private operations should go through a local signed bridge with an export policy.

## ADR-004 — Prototype at 3.3V/8MHz unless 16MHz compatibility is mandatory

Status: recommended.

Reason:
Running the whole logic side at 3.3V avoids damaging the flash and simplifies SPI wiring. The 5V/16MHz path requires careful level shifting and more validation.
