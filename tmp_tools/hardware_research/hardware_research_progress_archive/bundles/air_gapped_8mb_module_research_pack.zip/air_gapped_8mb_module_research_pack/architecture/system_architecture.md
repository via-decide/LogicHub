# System Architecture

## Functional architecture

```mermaid
flowchart TD
    A[logichub.app]
    B[Signed local bridge / offline host utility]
    C[USB-UART bridge: FT232R / CP2102N / CH340C]
    D[ATmega328P controller]
    E[W25Q64 8MB SPI NOR flash]
    F[Manifest + rule assets]
    G[Receipts + local audit log]
    H[Enclosure + tamper evidence]

    A -->|public demo / auth / checkout| B
    B -->|serial protocol| C
    C -->|TX RX DTR RESET| D
    D -->|SPI MOSI MISO SCK CS| E
    E --> F
    E --> G
    D --> H
    E --> H
```

## Data-flow rule

Private module contents must not be automatically sent to logichub.app. The host bridge must enforce an allowlist:

```text
Allowed to web:
- device public ID
- firmware version
- storage capacity
- pass/fail diagnostic status
- signed public receipt hash

Forbidden to web by default:
- raw flash pages
- private rule objects
- customer project data
- local reasoning traces
- device secrets
```

## State machine

```mermaid
stateDiagram-v2
    [*] --> RESET
    RESET --> SELF_TEST
    SELF_TEST --> FLASH_ID_CHECK
    FLASH_ID_CHECK --> SAFE_MODE: flash_missing_or_bad
    FLASH_ID_CHECK --> LOAD_SUPERBLOCK: flash_ok
    LOAD_SUPERBLOCK --> IDLE_LOCKED
    IDLE_LOCKED --> READ_ONLY: public_read_command
    IDLE_LOCKED --> AUTH_SESSION: valid_host_challenge
    AUTH_SESSION --> STAGING_WRITE: write_begin
    STAGING_WRITE --> VERIFY_STAGING: write_complete
    VERIFY_STAGING --> COMMIT_MANIFEST: crc_and_hash_ok
    VERIFY_STAGING --> ABORT_STAGING: verify_fail
    COMMIT_MANIFEST --> RECEIPT_WRITE
    RECEIPT_WRITE --> IDLE_LOCKED
    ABORT_STAGING --> IDLE_LOCKED
    SAFE_MODE --> IDLE_LOCKED: recovery_success
```

## Module identity

Recommended identity fields:

```json
{
  "module_id": "lh8m-<serial>",
  "hardware_revision": "proto0",
  "firmware_revision": "0.1.0",
  "flash_jedec_id": "...",
  "storage_bytes": 8388608,
  "manufacturing_lot": "...",
  "public_receipt_key_id": "optional-secure-element-key-id"
}
```
