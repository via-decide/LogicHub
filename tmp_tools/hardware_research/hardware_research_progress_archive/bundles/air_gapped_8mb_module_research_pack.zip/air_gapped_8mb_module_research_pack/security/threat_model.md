# Security and Threat Model

## Security promise boundaries

Safe promise:

> The module can keep selected project assets and rule data local, offline, and physically under user control.

Unsafe promise without extra security hardware:

> The module prevents all IP extraction or tampering.

The ATmega328P + raw SPI flash system is not tamper-resistant against a motivated physical attacker. Treat it as tamper-evident unless a secure element, encryption, signed manifests, and debug-locking policy are added.

## Assets

- private rule packs,
- local project manifests,
- license/entitlement records,
- validation receipts,
- device identity,
- firmware image,
- optional signing keys.

## Attack surfaces

| Surface | Risk | Mitigation |
|---|---|---|
| USB serial protocol | malformed commands, data exfiltration | length checks, CRC, command allowlist, local bridge policy |
| Remote web app | browser can leak data | web app never reads private pages; local offline bridge |
| SPI flash chip | desolder/read raw contents | encrypt payloads; tamper seal; epoxy; secure element |
| MCU firmware | bootloader rewrite, debug access | lock fuses, ISP access control, signed firmware updates |
| Power/reset | brownout corruption, glitch attacks | BOR, transaction journal, reset-safe metadata |
| Side channel | key extraction from power traces | avoid storing high-value keys in AVR; add secure element |
| Supply chain | cloned modules | serialised labels, signed manifests, factory receipts |

## Host bridge policy

The host bridge must implement a strict export policy.

```text
EXPORT_PUBLIC_STATUS:
  allowed fields: module_id, firmware_version, capacity, health_status

EXPORT_PRIVATE_OBJECT:
  default: denied
  allowed only in explicit offline backup mode

WRITE_UPDATE:
  requires signed update capsule
  requires user physical confirmation if product risk justifies it
```

## Air-gap warning

A USB-connected device is not automatically air-gapped. If the host machine has internet access and a web page can read the device, then the device is not isolated from the network. Production UX must make this clear.

## Production security recommendations

P0:
- CRC32 per frame/page.
- Dual manifest with generation counter.
- Safe reset and power-loss recovery.

P1:
- SHA-256 manifest over stored objects.
- Signed update capsules.
- Locked bootloader or controlled ISP access.

P2:
- Secure element for device identity/signing.
- Encrypted objects at rest.
- Challenge-response write authorization.

P3:
- Tamper-evident enclosure.
- Factory provisioning logs.
- Revocation list for compromised firmware or module IDs.
