# Air-Gapped 8MB Storage Module — Deep Research Pack

Generated: 2026-07-29
Project: Air-gapped / local-first 8MB storage module tied to logichub.app as a commercial and demo surface

## Critical verdict

The proposed ATmega328P + 8MB SPI NOR flash architecture is feasible as:

- an offline tamper-evident storage cartridge,
- a deterministic rule-table / finite-state-machine interpreter,
- a small offline license / manifest / policy execution token,
- a demonstrator for a local-first hardware ecosystem.

It is **not feasible as a modern LLM-style reasoning engine** on the ATmega328P itself. The ATmega328P has only 32KB flash, 2KB SRAM, and 1KB EEPROM. The 8MB SPI flash is useful for assets, rule tables, manifests, logs, and compact bytecode, but not for running a large model or general-purpose AI inference.

The correct production framing is:

> Host app = demo, commerce, onboarding, and signed asset delivery.  
> Hardware module = offline storage, rule interpreter, integrity checker, entitlement/receipt holder, and tamper-evident local state anchor.

## Contents

- `00_deep_research_report.md` — main research report
- `architecture/system_architecture.md` — block diagrams and state model
- `hardware/bom_freeze.csv` — locked prototype and production BOM
- `hardware/pin_map.csv` — ATmega328P DIP-28 pin map
- `hardware/power_tree_and_level_shifting.md` — 5V/3.3V decision, flash protection, decoupling
- `firmware/storage_protocol.md` — serial protocol and memory map
- `firmware/manifest_and_integrity.md` — dual-superblock, CRC/SHA manifest, transaction semantics
- `scripts/flash_integrity_tester.ino` — Arduino-style firmware scaffold
- `scripts/host_flash_test.py` — Python host validation scaffold
- `validation/bench_validation_plan.md` — breadboard and PCB bring-up plan
- `manufacturing/pcb_layout_rules.md` — KiCad/PCB routing rules
- `mechanical/enclosure_dfm_spec.md` — FDM/SLA enclosure and tamper-evident housing guidance
- `manufacturing/pcba_test_plan.md` — factory test and acceptance plan
- `security/threat_model.md` — air-gap limits, USB risk, tamper model
- `commercial/go_to_market.md` — product wedge and monetisation logic
- `commercial/cost_model_inr.csv` — rough India-facing cost model
- `commercial/compliance_checklist.md` — BIS/CE/FCC/RoHS/USB checklist
- `schemas/module_manifest.schema.json` — module manifest contract
- `schemas/test_receipt.schema.json` — validation receipt contract
- `sources/bibliography.md` — source list

## Not included

This pack does not include finished KiCad schematics, PCB layout files, Gerbers, STEP enclosure files, or certified compliance reports. It is a research and engineering blueprint package for moving from breadboard to prototype PCB and eventually production.
