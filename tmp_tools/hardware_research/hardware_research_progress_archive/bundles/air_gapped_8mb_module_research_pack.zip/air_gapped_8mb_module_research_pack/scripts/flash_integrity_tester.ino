/*
  LH8M Flash Integrity Tester
  Target: ATmega328P + W25Q64-class SPI NOR
  Purpose: first bring-up scaffold, not production firmware.

  Wiring defaults:
    CS  -> D8
    MOSI-> D11
    MISO-> D12
    SCK -> D13

  If ATmega is 5V and flash is 3.3V, use level shifting before running this.
*/

#include <SPI.h>

static const uint8_t PIN_FLASH_CS = 8;

uint8_t spi_xfer(uint8_t b) {
  return SPI.transfer(b);
}

void flash_select() {
  digitalWrite(PIN_FLASH_CS, LOW);
}

void flash_deselect() {
  digitalWrite(PIN_FLASH_CS, HIGH);
}

uint32_t read_jedec_id() {
  flash_select();
  spi_xfer(0x9F);
  uint8_t mfg = spi_xfer(0x00);
  uint8_t mem = spi_xfer(0x00);
  uint8_t cap = spi_xfer(0x00);
  flash_deselect();
  return ((uint32_t)mfg << 16) | ((uint32_t)mem << 8) | cap;
}

uint8_t read_status1() {
  flash_select();
  spi_xfer(0x05);
  uint8_t s = spi_xfer(0x00);
  flash_deselect();
  return s;
}

void wait_busy() {
  while (read_status1() & 0x01) {
    delay(1);
  }
}

void write_enable() {
  flash_select();
  spi_xfer(0x06);
  flash_deselect();
}

void read_data(uint32_t addr, uint8_t *buf, uint16_t len) {
  flash_select();
  spi_xfer(0x03);
  spi_xfer((addr >> 16) & 0xFF);
  spi_xfer((addr >> 8) & 0xFF);
  spi_xfer(addr & 0xFF);
  for (uint16_t i = 0; i < len; i++) {
    buf[i] = spi_xfer(0x00);
  }
  flash_deselect();
}

void sector_erase_4k(uint32_t addr) {
  write_enable();
  flash_select();
  spi_xfer(0x20);
  spi_xfer((addr >> 16) & 0xFF);
  spi_xfer((addr >> 8) & 0xFF);
  spi_xfer(addr & 0xFF);
  flash_deselect();
  wait_busy();
}

void page_program(uint32_t addr, const uint8_t *buf, uint16_t len) {
  if (len > 256) len = 256;
  write_enable();
  flash_select();
  spi_xfer(0x02);
  spi_xfer((addr >> 16) & 0xFF);
  spi_xfer((addr >> 8) & 0xFF);
  spi_xfer(addr & 0xFF);
  for (uint16_t i = 0; i < len; i++) {
    spi_xfer(buf[i]);
  }
  flash_deselect();
  wait_busy();
}

uint32_t simple_crc32(const uint8_t *data, uint16_t len) {
  uint32_t crc = 0xFFFFFFFFUL;
  for (uint16_t i = 0; i < len; i++) {
    crc ^= data[i];
    for (uint8_t j = 0; j < 8; j++) {
      crc = (crc >> 1) ^ (0xEDB88320UL & (-(int32_t)(crc & 1)));
    }
  }
  return ~crc;
}

void setup() {
  pinMode(PIN_FLASH_CS, OUTPUT);
  flash_deselect();
  Serial.begin(115200);
  while (!Serial) { ; }
  SPI.begin();
  SPI.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0));

  Serial.println("LH8M flash integrity tester");
  uint32_t id = read_jedec_id();
  Serial.print("JEDEC ID: 0x");
  Serial.println(id, HEX);

  uint32_t test_addr = 0x700000UL;
  uint8_t tx[256];
  uint8_t rx[256];
  for (uint16_t i = 0; i < 256; i++) tx[i] = (uint8_t)(i ^ 0xA5);

  Serial.println("Erase test sector...");
  sector_erase_4k(test_addr);

  Serial.println("Program test page...");
  page_program(test_addr, tx, 256);

  Serial.println("Read back...");
  read_data(test_addr, rx, 256);

  uint32_t c1 = simple_crc32(tx, 256);
  uint32_t c2 = simple_crc32(rx, 256);
  Serial.print("TX CRC32: 0x"); Serial.println(c1, HEX);
  Serial.print("RX CRC32: 0x"); Serial.println(c2, HEX);
  Serial.println(c1 == c2 ? "PASS" : "FAIL");
}

void loop() {
  delay(1000);
}
