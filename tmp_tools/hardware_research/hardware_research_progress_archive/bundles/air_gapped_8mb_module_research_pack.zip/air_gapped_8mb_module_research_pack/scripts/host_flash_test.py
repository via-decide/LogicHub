#!/usr/bin/env python3
"""
Host-side serial test scaffold for LH8M module.
This script assumes the firmware prints JEDEC ID and PASS/FAIL text.
For production, replace line parsing with the binary framed protocol.
"""

from __future__ import annotations

import argparse
import sys
import time

try:
    import serial  # pyserial
except ImportError:  # pragma: no cover
    serial = None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", required=True, help="Serial port, e.g. /dev/ttyUSB0 or COM5")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--timeout", type=float, default=10.0)
    args = parser.parse_args()

    if serial is None:
        print("pyserial is required: pip install pyserial", file=sys.stderr)
        return 2

    with serial.Serial(args.port, args.baud, timeout=0.5) as ser:
        deadline = time.time() + args.timeout
        lines: list[str] = []
        while time.time() < deadline:
            raw = ser.readline()
            if raw:
                line = raw.decode(errors="replace").strip()
                print(line)
                lines.append(line)
                if line == "PASS":
                    return 0
                if line == "FAIL":
                    return 1

    print("Timeout waiting for PASS/FAIL", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
