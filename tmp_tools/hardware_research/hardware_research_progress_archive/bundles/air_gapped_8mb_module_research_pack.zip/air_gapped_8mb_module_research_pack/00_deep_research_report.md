# Deep Research Report: Air-Gapped 8MB Storage Module

## 1. Executive verdict

The concept is commercially interesting but technically must be reframed.

The supplied blueprint says the 8MB module will hold localized code, rule sets, and reasoning assets entirely offline. That is feasible if “reasoning” means deterministic rule evaluation, bytecode interpretation, policy lookup, signed manifest verification, object storage, and local state transitions. It is not feasible if “reasoning engine” means modern LLM inference running on the ATmega328P itself.

The ATmega328P should be treated as a deterministic controller, not an AI compute engine. The W25Q64-class SPI flash should be treated as a private offline asset store, not RAM. The product’s defensible value is a small, physically controlled, tamper-evident trust anchor that prevents private rules, licenses, manifests, and local datasets from being uploaded to a cloud service.

## 2. Main architectural correction

Original framing:

```text
web app -> user authentication / checkout
hardware 8MB cartridge -> private reasoning and code execution
```

Corrected production framing:

```text
logichub.app
  -> marketing, purchase, account, docs, optional signed update delivery
local host bridge
  -> offline serial communication, firmware flashing, diagnostics, backup
8MB module
  -> signed asset store, deterministic rule interpreter, manifest verifier,
     local receipts, tamper-evident state anchor
```

A web page that directly communicates with the module through WebSerial while also having internet access can exfiltrate device data. If IP protection is the thesis, the production workflow must use one of these patterns:

1. **Offline local app:** user downloads a signed local utility, disconnects network, then communicates with the module.
2. **Read-only browser demo:** web app shows marketing/demo behavior but never reads private module contents.
3. **Audited bridge:** a local native app signs and filters every transaction; the remote web page only sees public status.
4. **Air-gapped update capsule:** update files are downloaded separately, copied to an offline machine, verified on-device, and only then installed.

## 3. Hardware feasibility

### 3.1 ATmega328P role

The ATmega328P-PU DIP-28 is excellent for breadboard validation because it is cheap, available, easy to socket, compatible with Arduino tooling, and simple to inspect on a bench. Its production limits are SRAM and lack of hardware security.

Recommended use:

- SPI flash controller
- deterministic command interpreter
- manifest verifier
- page read/write/erase manager
- transaction journal controller
- LED/status/debug outputs
- serial command endpoint
- simple finite-state rules engine

Not recommended:

- LLM inference
- vector search
- compressed database engine
- public-key-heavy protocol without careful optimization
- secure key storage against physical attackers
- high-speed USB native device implementation

### 3.2 Flash role

A W25Q64-class device provides 64Mbit / 8MByte storage with SPI/Dual/Quad SPI capability, 4KB erase sectors, 256-byte programmable pages, 2.7V–3.6V operation, and finite erase endurance. For this design, the flash should contain signed assets and manifests, not executable code that can silently mutate.

Recommended memory layout:

```text
0x000000 - 0x000FFF   boot metadata / manufacturing ID / immutable header mirror
0x001000 - 0x001FFF   superblock A
0x002000 - 0x002FFF   superblock B
0x003000 - 0x00FFFF   manifest, directory, capability table
0x010000 - 0x5FFFFF   object store / rule assets / content-addressed chunks
0x600000 - 0x6FFFFF   transaction scratch / staging slot
0x700000 - 0x77FFFF   validation receipts / logs
0x780000 - 0x7EFFFF   backup manifest / factory test records
0x7F0000 - 0x7FFFFF   bad-sector ledger / reserved
```

### 3.3 Voltage architecture

The most important electrical decision is the 5V/3.3V split.

The supplied blueprint uses ATmega328P at 16MHz. That normally implies 5V operation for full datasheet margin. But W25Q64JV-class flash is a 2.7V–3.6V part. Therefore, one of the following must be locked:

**Option A — prototype-simple / slower:** run ATmega328P at 3.3V and 8MHz. This avoids level shifting but changes bootloader, fuses, and timing assumptions.

**Option B — Arduino-compatible / faster:** run ATmega328P at 5V and 16MHz, power flash at 3.3V, and use proper level shifting for MOSI, SCK, CS, WP#, HOLD#/RESET#. Verify MISO high-level margin or buffer it.

**Recommendation:** use Option A for low-risk storage reliability and Option B only if Arduino bootloader compatibility at 16MHz is a hard requirement.

## 4. Breadboard prototype plan

Breadboard validation should prove electrical communication and state-machine integrity, not cosmetic product readiness.

Minimum bench setup:

- ATmega328P-PU in DIP-28 socket
- 16MHz crystal + 22pF capacitors if using 5V/16MHz path
- 8MHz crystal or internal oscillator calibration if using 3.3V path
- 10k reset pull-up
- 100nF DTR-to-reset capacitor for bootloader auto-reset
- USB-UART bridge with TX/RX/DTR/GND
- W25Q64 flash breakout powered at 3.3V
- 100nF decoupling at MCU VCC/AVCC and flash VCC
- bulk capacitor on 5V and 3.3V rails
- logic analyzer on SCK/MOSI/MISO/CS

Breadboard pass criteria:

1. Flash JEDEC ID reads consistently for 1,000 attempts.
2. Page program / readback passes CRC32 for 10,000 random pages.
3. 4KB sector erase produces all `0xFF` and no adjacent-sector damage.
4. Reset during write never promotes a partially written manifest.
5. Brownout or USB reconnect returns to a known safe state.
6. Serial protocol never accepts malformed length fields or out-of-range writes.
7. WP#/HOLD# do not float during boot, reset, or power transition.

## 5. PCB design implications

Breadboards are not representative for production signal integrity. SPI may work at low speed on a breadboard but fail after clock-rate increase, longer cables, or enclosure-induced grounding changes.

PCB rules:

- Keep SPI SCK short and direct.
- Route SCK away from crystal and reset line.
- Keep flash close to MCU.
- Use a continuous ground reference under SPI and crystal sections where possible.
- Put 100nF decouplers as close as physically possible to VCC/GND pins.
- Use a 3.3V LDO with enough transient margin for flash program/erase current.
- Add series damping resistors, typically 22–47Ω, on SCK/MOSI/CS if ringing appears.
- Pull WP# and HOLD#/RESET# to known inactive states.
- Add test points for 5V, 3V3, GND, RESET, SCK, MOSI, MISO, CS, TX, RX, DTR.
- Keep the UART/programming header accessible in EVT builds.

## 6. Firmware architecture

The firmware must be deterministic and transactional.

Core state machine:

```text
RESET
  -> SELF_TEST
  -> FLASH_ID_CHECK
  -> SUPERBLOCK_SELECT
  -> IDLE_LOCKED
  -> AUTH_SESSION
  -> READ_ONLY
  -> STAGING_WRITE
  -> VERIFY_STAGING
  -> COMMIT_MANIFEST
  -> RECEIPT_WRITE
  -> IDLE_LOCKED
```

Every mutating operation must be two-phase:

1. Write payload into staging area.
2. Verify CRC/SHA.
3. Write new manifest version to inactive superblock.
4. Verify inactive superblock.
5. Atomically promote generation counter.
6. Leave previous generation recoverable.

Do not write final manifest first.

## 7. Security and tamper model

The device can be tamper-evident, not tamper-proof.

Physical attackers can:

- desolder the SPI flash,
- read raw contents using a programmer,
- glitch power/reset,
- inspect UART traffic,
- measure power side channels,
- replace the firmware or bootloader if programming access is exposed.

Minimum controls:

- signed module manifests,
- encrypted private payloads if confidentiality is required,
- secure-element option for production signing keys,
- epoxy/tamper label over debug pads after manufacturing,
- lock fuses after programming when appropriate,
- no private secrets stored only in AVR flash if high-value extraction risk exists,
- host protocol challenge-response for write permission,
- audit receipt per mutation.

If true IP protection is the product promise, add a secure element such as Microchip ATECC-class hardware or move to a microcontroller with a stronger secure-boot and key-storage story. The ATmega328P alone is not a strong tamper-resistant root of trust.

## 8. Commercial position

Best product wedge:

> “A pocket hardware cartridge for offline project manifests, local engineering rules, signed capability packs, and private execution receipts.”

Initial buyers:

- hardware educators,
- makers who want offline firmware/data cartridges,
- local-first developer tool users,
- LogicHub/Zayvora early adopters,
- small manufacturers needing demo hardware tied to a web checkout funnel.

Avoid overclaiming:

- Do not market it as an AI accelerator.
- Do not claim cloud-grade IP protection without a secure-element/encryption architecture.
- Do not call it fully air-gapped while it is connected to an internet browser.
- Do not imply 8MB can hold a general LLM.

## 9. Go / Change / No-Go

### Go

Proceed with a breadboard prototype if the goal is to validate:

- flash read/write reliability,
- offline manifest storage,
- serial protocol,
- local rule-table execution,
- tamper-evident packaging concept.

### Change

Change the architecture if the product requires:

- modern AI inference,
- strong cryptographic identity,
- high-speed USB native transfer,
- secure boot,
- encrypted flash at rest,
- long-term production with firmware updates.

For those, consider a 32-bit MCU with native USB and security features. Keep the 8MB flash cartridge concept as the product surface.

### No-Go

Do not move to production PCB until:

- voltage domain is frozen,
- WP#/HOLD#/CS reset states are proven,
- power-loss transaction tests pass,
- firmware protocol rejects malformed commands,
- manifest recovery is demonstrated,
- PCBA test fixture is defined.

## 10. One next action

Build the breadboard with the **3.3V/8MHz ATmega path** first. Verify W25Q64 JEDEC ID, erase, program, readback, and power-loss recovery. Only after that, decide whether Arduino-style 5V/16MHz compatibility is worth the added level-shifting and signal-integrity risk.
