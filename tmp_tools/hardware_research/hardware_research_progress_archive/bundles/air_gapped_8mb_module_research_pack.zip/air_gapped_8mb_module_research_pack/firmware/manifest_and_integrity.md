# Manifest and Integrity Model

## Object manifest

Every stored object should have a manifest entry:

```json
{
  "object_id": "rulepack.main.v1",
  "object_type": "rulepack",
  "offset": 65536,
  "length": 4096,
  "crc32": "0x12345678",
  "sha256": "hex",
  "version": 1,
  "flags": ["read_only"],
  "created_by": "factory-or-host-bridge",
  "schema_version": "lh8m.manifest.v1"
}
```

## Dual superblock structure

Use two superblocks with generation counters.

```text
Superblock A:
  magic
  schema_version
  generation
  active_manifest_offset
  active_manifest_length
  manifest_crc32
  manifest_sha256
  superblock_crc32

Superblock B:
  same structure
```

Boot selection rule:

1. Read both superblocks.
2. Reject any with invalid magic or CRC.
3. Choose highest valid generation.
4. Verify manifest CRC/SHA.
5. If both fail, enter SAFE_MODE.

## Integrity levels

| Level | Mechanism | Detects | Does not detect |
|---|---|---|---|
| L0 | length/range checks | malformed protocol | malicious payloads |
| L1 | CRC32 per page/object | random corruption | intentional tampering |
| L2 | SHA-256 manifest hash | object substitution | unsigned attacker with write access if manifest rewritten |
| L3 | signature over manifest | unauthorized mutation | physical chip extraction |
| L4 | secure-element signing/encryption | stronger identity and key protection | invasive lab attack |

Minimum viable product should implement L1+L2. Commercial IP-protection product should implement L3 or L4.
