# Firmware Storage Protocol

## Serial framing

Use a binary framed protocol instead of human-readable commands for production. Human-readable commands are useful during first bring-up only.

```text
magic[2] = 0x4C 0x48    // 'LH'
version[1]              // protocol version
command[1]
flags[1]
sequence[2]
payload_len[2]
payload[payload_len]
crc32[4]                // covers header except crc + payload
```

## Command set

| Command | Code | Direction | Mutates flash | Purpose |
|---|---:|---|---|---|
| PING | 0x01 | host -> device | no | confirm device alive |
| GET_INFO | 0x02 | host -> device | no | public module metadata |
| READ_PAGE | 0x10 | host -> device | no | read 256-byte logical page |
| READ_OBJECT | 0x11 | host -> device | no | read object by manifest ID |
| WRITE_BEGIN | 0x20 | host -> device | yes | start staged object write |
| WRITE_CHUNK | 0x21 | host -> device | yes | write to staging area |
| WRITE_VERIFY | 0x22 | host -> device | yes | verify staged object hash |
| COMMIT | 0x23 | host -> device | yes | promote manifest generation |
| ABORT | 0x24 | host -> device | yes | discard staging area |
| ERASE_STAGING | 0x25 | host -> device | yes | erase staging sectors |
| GET_RECEIPT | 0x30 | host -> device | no | return last validation receipt |
| LOCK | 0x40 | host -> device | no | end authenticated session |
| FACTORY_TEST | 0xF0 | host -> device | yes | factory-only diagnostics |

## Error codes

```text
LH_OK = 0
LH_ERR_BAD_MAGIC = 1
LH_ERR_BAD_VERSION = 2
LH_ERR_BAD_CRC = 3
LH_ERR_BAD_LENGTH = 4
LH_ERR_BAD_STATE = 5
LH_ERR_FLASH_ID = 6
LH_ERR_FLASH_TIMEOUT = 7
LH_ERR_VERIFY_FAIL = 8
LH_ERR_AUTH_REQUIRED = 9
LH_ERR_RANGE = 10
LH_ERR_LOCKED = 11
LH_ERR_UNSUPPORTED = 12
```

## Transaction rule

Only `COMMIT` may change the active manifest generation. All other writes target staging sectors or inactive metadata areas.

```text
WRITE_BEGIN -> WRITE_CHUNK* -> WRITE_VERIFY -> COMMIT
```

If reset occurs at any point before `COMMIT`, the previous manifest remains active.
