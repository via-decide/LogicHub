# Enclosure DFM Specification

## Prototype enclosure

Recommended first method: FDM PETG or PLA+.

Design targets:

- PCB clearance: 0.3–0.5mm around board edge for FDM.
- USB port clearance: at least 0.5mm extra on each side for early prints.
- Snap-fit clearance: test coupons before final enclosure.
- Wall thickness: 1.6–2.4mm for small handheld module.
- Boss diameter: design around actual screw insert or self-tapping screw.
- Avoid sharp internal corners near snap features.

## Tamper-evident features

- Breakaway label across seam.
- Hidden screw under serialized seal.
- Internal witness marks that break when opened.
- Optional epoxy over flash and programming pads after production test.
- Serialized enclosure ID matching module public ID.

## Production enclosure paths

| Path | Use when | Risk |
|---|---|---|
| FDM | 1–50 units, early validation | rough finish, tolerance drift |
| SLA | 10–200 units, better finish | brittle resin, aging |
| MJF/SLS | 50–1000 units | higher vendor dependency |
| Injection molding | 1000+ units | high tooling NRE, design freeze required |

## Assembly sequence

1. Program and test PCBA.
2. Record module ID and firmware hash.
3. Insert board into lower shell.
4. Verify USB connector alignment.
5. Close snap/screw enclosure.
6. Apply tamper seal.
7. Run final serial diagnostic through enclosure.
8. Pack with recovery instructions and safety warnings.
