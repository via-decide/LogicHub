# Power Tree and Level Shifting

## Recommended prototype power tree

```text
USB 5V
  -> polyfuse / current limit optional
  -> 5V rail for USB-UART and possibly ATmega328P 16MHz
  -> 3.3V LDO
      -> W25Q64 SPI flash
      -> optional secure element
```

## Voltage-domain choices

### Option A: ATmega328P at 3.3V / 8MHz

Pros:
- no level shifting between MCU and flash
- lower current
- simpler SPI wiring
- less risk of flash over-voltage

Cons:
- Arduino Uno 16MHz bootloader assumptions no longer apply
- serial baud/timing must match correct `F_CPU`
- lower compute throughput

### Option B: ATmega328P at 5V / 16MHz

Pros:
- standard Arduino-style timing
- easier bootloader ecosystem
- full 16MHz AVR throughput

Cons:
- W25Q64 flash requires 2.7V–3.6V supply
- MOSI/SCK/CS/WP#/HOLD# need level shifting or fixed 3.3V pull-ups
- additional layout and BOM complexity

## Hard electrical rules

- Never connect 5V SPI outputs directly to W25Q64 inputs.
- Pull CS# high during reset so the flash is deselected.
- Pull WP# and HOLD#/RESET# to safe inactive states.
- Place one 100nF capacitor at each IC supply pin pair.
- Place a local 1uF or larger bulk capacitor near the flash/regulator.
- Test flash read/write during USB plug/unplug and host reset events.

## Reset/DTR network

```text
USB-UART DTR ---- 100nF ---- RESET
RESET ---- 10k ---- VCC
RESET ---- pushbutton ---- GND optional
```

This produces an auto-reset pulse for bootloader flashing. Add a solder jumper or cut trace in production if unwanted resets become a reliability issue.
