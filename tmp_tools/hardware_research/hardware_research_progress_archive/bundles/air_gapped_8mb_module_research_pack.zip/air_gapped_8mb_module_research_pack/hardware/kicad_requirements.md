# KiCad Project Requirements

## Required sheets

1. Power input and regulation
2. ATmega328P core
3. SPI flash
4. USB-UART / programming bridge
5. Test points and factory fixture
6. Optional secure element

## Required ERC checks

- No floating CS#/WP#/HOLD#/RESET#.
- AVCC connected and decoupled.
- Reset pull-up present.
- Flash powered from 3.3V only.
- If MCU is 5V, flash input nets pass through level shifting.
- Programming header has GND reference.

## Required DRC classes

```text
SPI_FAST
UART
POWER_5V
POWER_3V3
RESET
CRYSTAL
TESTPOINT
```

## Outputs

- schematic PDF,
- interactive BOM,
- fabrication Gerbers,
- drill files,
- pick-and-place CPL/XY,
- assembly drawing,
- test-point map,
- schematic netlist,
- revision manifest.
