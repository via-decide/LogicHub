# FarmBot Architecture Map

## SOURCE -> ENTRY -> INTENT -> STATE/LOGIC -> ACTIONS -> OUTPUT/METRICS

| Pipeline stage | FarmBot expression |
|---|---|
| SOURCE | CAD, BOM, Farmduino schematics, firmware, FarmBot OS, Web App, JS/Python libraries, docs |
| ACCESS / ENTRY | my.farm.bot, self-hosted Web App, FarmBot JS, FarmBot Python, OS image, physical kit |
| INTENT CAPTURE | Farm design, sequence builder, crop operations, manual controls, API commands |
| STATE / LOGIC | Web App resources, CeleryScript, FarmBot OS state tree, firmware parameters, pin maps |
| ACTIONS | Move, home, calibrate, water, seed, read sensor, mount tool, take photo, run sequence |
| OUTPUT / METRICS | Logs, status tree, sensor data, plant growth data, image data, movement success, error codes |

## Data/control flow

```mermaid
flowchart TD
    User[User / Developer]
    Web[FarmBot Web App]
    API[REST API]
    Broker[Message Broker: WebSockets MQTT AMQP]
    OS[FarmBot OS on Raspberry Pi]
    FW[Farmduino Firmware]
    Elec[Farmduino Electronics]
    Machine[XYZ Gantry + UTM + Tools]
    Sensor[Camera / Encoders / Soil Sensor]
    User --> Web
    User --> API
    User --> Broker
    Web --> API
    Web --> Broker
    API --> Broker
    Broker --> OS
    OS --> FW
    FW --> Elec
    Elec --> Machine
    Machine --> Sensor
    Sensor --> Elec
    Elec --> FW
    FW --> OS
    OS --> Broker
    Broker --> Web
```

## Key architectural split

- Web app: planning, data, UI, account/device state.
- FarmBot OS: Raspberry Pi runtime, connectivity, scheduling, command coordination.
- Firmware: motion/peripheral execution on Farmduino.
- Hardware: gantry, UTM, tools, sensors, cabling, raised bed.
