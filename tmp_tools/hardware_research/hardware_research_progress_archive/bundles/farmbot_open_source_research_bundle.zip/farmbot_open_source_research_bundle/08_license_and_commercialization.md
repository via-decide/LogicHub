# FarmBot License and Commercialization Notes

## Source-derived license map

| Work type | FarmBot stated license | Meaning for reuse |
|---|---|---|
| Hardware CAD/models/drawings/supporting docs | CC0 Public Domain Dedication | Broad use, including commercial use, with no attribution requirement according to FarmBot licensing page |
| Software | MIT License | Copy, modify, distribute, sublicense, and sell software subject to MIT terms |
| Documentation | CC0 Public Domain Dedication | Broad reuse |
| Non-functional works | CC BY-NC 4.0 | Non-commercial terms; do not reuse logos/branding/marketing assets as if they were CC0 hardware |

## Commercial caution

Open hardware/source availability does not automatically grant trademark rights, brand rights, warranty claims, distributor status, certification, safety approval, or the right to imply official FarmBot compatibility or endorsement.

## Required before commercialization

- File-level license inventory.
- Trademark review.
- Safety/compliance review.
- Supplier documentation.
- Local warranty/support model.
- Clear separation between “compatible with FarmBot-style UTM” and “official FarmBot product”.
