# FarmBot Software Stack Analysis

## Web App

FarmBot Web App contains a web UI, RESTful JSON API, Dockerized MQTT server, user/account/device data, farm designs, sequences, authorization tokens, and realtime browser-to-device messaging.

Risk: self-hosting is technically possible but the README explicitly warns that self-hosting is not easy and can cause accidental security issues or data loss if operated incorrectly.

## FarmBot OS

FarmBot OS is written in Elixir, built with Nerves, compiled into a binary image, responsible for low-level device runtime on Raspberry Pi, connected to the Web App through HTTP and AMQP, and bundled with compiled Arduino firmware.

Security-relevant detail: the v15 developer docs state SSH access has been completely removed from FarmBot OS.

## Firmware

The Arduino/Farmduino firmware receives G-code-like and FarmBot-specific F-code commands, executes movement and pin-control handlers, reports result codes, supports multiple Farmduino board variants, and is bundled into FarmBot OS for production use.

## Developer libraries

FarmBot JS and FarmBot Python allow external programs to send commands and interact with FarmBot. FarmBot JS wraps common MQTT/CeleryScript operations into a JavaScript API.

## Extension paths

| Extension | Best layer |
|---|---|
| Custom dashboard | Web App / FarmBot JS |
| External automation | FarmBot Python / MQTT |
| Local-first control | FarmBot OS fork or companion Pi service |
| Custom tool | UTM + firmware pin commands |
| Crop vision | Camera + OS + external compute |
| Phenotyping | Custom UTM end-effector + FarmBot Python |
| LogicHub integration | Source manifest + API/broker interface + firmware pin graph |
