# India Productization and Service Strategy

## Best-fit customer segments

1. Engineering colleges and robotics labs.
2. Agricultural universities.
3. Controlled-environment agriculture startups.
4. Hydroponics/aeroponics demonstration farms.
5. STEM schools and makerspaces.
6. Plant phenotyping researchers.
7. Accessibility gardening pilots.

## Do not start with

- Broad-acre farming.
- Low-margin consumer gardening.
- Unsafe high-power custom rotary tools.
- Cloning entire FarmBot for resale without support model.
- Promising crop yield improvements before agronomic testing.

## Service packages

| Package | Description |
|---|---|
| Source intake audit | Export, hash, and map official FarmBot open-source assets |
| Setup service | Assemble/calibrate a FarmBot kit |
| UTM custom tool | Design compatible sensor/tool adapters |
| Local-first control research | Add deterministic local sequence cache and audit logs |
| Phenotyping pipeline | Camera end-effector, image capture path, data processing |
| Education curriculum | FarmBot + coding + electronics + agriculture robotics |

## Pricing structure template

Use ₹ after local supplier quoting.

- Setup service fee.
- Annual maintenance.
- Custom tooling design fee.
- Source-audit report fee.
- Education curriculum package.
- Replacement-parts procurement markup.
- Local server/self-hosting support, only for advanced customers.
