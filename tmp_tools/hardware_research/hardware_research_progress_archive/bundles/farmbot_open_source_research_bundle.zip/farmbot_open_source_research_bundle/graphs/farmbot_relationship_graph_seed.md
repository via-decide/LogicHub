# FarmBot Relationship Graph Seed

Each edge should later become canonical NDJSON.

```json
{"from":"webapp::sequence","type":"SENDS_COMMAND_VIA","to":"broker::celeryscript_node","evidence":"developer docs"}
{"from":"broker::celeryscript_node","type":"ROUTED_TO","to":"farmbot_os::runtime","evidence":"developer docs"}
{"from":"farmbot_os::runtime","type":"SENDS_GCODE_TO","to":"firmware::gcode_processor","evidence":"firmware README"}
{"from":"firmware::gcode_processor","type":"CONTROLS","to":"farmduino::pin","evidence":"firmware README + pinout docs"}
{"from":"farmduino::pin::D63","type":"CONNECTED_TO","to":"utm::pin::C","evidence":"UTM pin mapping"}
{"from":"utm::pin::C","type":"VALIDATES","to":"tool::mounted_tool","evidence":"tool verification docs"}
{"from":"bom::Farmduino_v1_6","type":"REALIZED_BY","to":"electronics::farmduino_pcb","evidence":"BOM + Farmduino docs"}
```
