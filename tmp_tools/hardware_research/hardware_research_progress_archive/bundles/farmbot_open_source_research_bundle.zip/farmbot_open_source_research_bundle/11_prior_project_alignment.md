# Alignment With Earlier Project Bundles

## Air-gapped 8MB storage module

FarmBot sequences and tool manifests could be compiled into small deterministic local manifests. An offline cartridge can store tool IDs, permitted commands, crop recipes, or audit logs. Best research direction: local-first FarmBot command cartridge, not full cloud replacement.

## Drone CAD bundle

Drone work mapped flight-controller hardware, validation, and regulatory risk. FarmBot has slower motion but stronger cross-domain CAD/BOM/software traceability. Both need deterministic safety gates before actuation.

## Pupper V3 bundle

Pupper V3 is ROS2/locomotion-heavy. FarmBot is CNC/agriculture/app-heavy. Together they form two strong LogicHub demos: mobile robot dog and fixed gantry agriculture robot.

## Strong LogicHub demo story

```text
Pupper V3: locomotion + ROS2 + neural controller
FarmBot: CAD/BOM + API + firmware + physical production
Drone: flight safety + embedded validation
8MB cartridge: local-first storage + tamper-evident manifests
```
