# FarmBot Validation and Test Plan

## Source validation

- Confirm every repository clone URL and default branch.
- Record commit SHA.
- Record license file and package metadata.
- Hash all source files.
- Record documentation page version.

## CAD validation

- Export STEP and 2D drawings from Onshape.
- Verify units in millimeters.
- Run interference checks.
- Check gantry squareness.
- Confirm UTM magnet/pogo-pin positions.
- Map every fastener to BOM row.

## Electronics validation

- Confirm Farmduino revision.
- Inspect Farmduino schematic and PCB layout.
- Map pinout table to firmware board config.
- Verify power domains: 24V, 5V, logic, protected earth.
- Verify peripheral outputs and load sense lines.
- Verify encoder connections.

## Firmware validation

- Compile stable release tag.
- Compile board variant for exact Farmduino revision.
- Build command coverage table for G/F-codes.
- Run dry command tests before motor power.
- Confirm emergency stop and movement abort.

## Mechanical validation

- Rail alignment.
- Belt tension.
- V-wheel preload.
- Gantry equalization.
- Z-axis motion.
- UTM docking and undocking.
- Cable carrier movement.

## Operational validation

- Install FarmBot OS.
- Connect to Web App or test server.
- Confirm firmware version.
- Run homing sequence.
- Run camera test.
- Run watering nozzle without plants.
- Run soil sensor reading.
- Run seed injector dry test.
- Run tool verification.
- Run supervised 24-hour soak with E-stop available.
