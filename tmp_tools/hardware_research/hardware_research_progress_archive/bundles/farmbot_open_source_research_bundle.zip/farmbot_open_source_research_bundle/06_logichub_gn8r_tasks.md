# LogicHub / GN8R FarmBot Task Blocks

/task
repo: via-decide/LogicHub
mode: farmbot-source-intake-v0.1
tier: T5
estimated_time: 360
version: 1
depends_on: none
task: Build FarmBot source intake. Collect official docs, GitHub repos, CAD export links, BOM pages, Farmduino pinouts, UTM mappings, firmware command docs. Preserve URLs, versions, hashes, and unknowns.

CAUSATION:
FarmBot spans CAD, BOM, electronics, firmware, OS, API, and manufacturing. Without deterministic source intake, later CAD/BOM validation and productization will attach claims to mutable links.

CONVERGENCE:
same source URL + same exported file -> same SHA256 manifest. Unknown or externally hosted files remain unresolved until manually exported.

EXECUTION_CONTRACT:
Create farmbot-source-manifest.json, SHA256SUMS.txt, source-gaps.md, and license-inventory.md. Do not claim CAD/Gerbers are collected unless files exist locally.

---

/task
repo: via-decide/LogicHub
mode: farmbot-crossdomain-graph-v0.1
tier: T5
estimated_time: 480
version: 1
depends_on: farmbot-source-intake-v0.1
task: Build FarmBot cross-domain graph. Map BOM items to CAD parts, Farmduino pins to firmware commands, UTM pogo pins to tools, Web App resources to broker messages, and OS commands to firmware G/F-code.

CAUSATION:
A FarmBot tool or pin change crosses mechanical, electrical, firmware, and software boundaries. Plain Git diffs cannot explain physical consequences.

CONVERGENCE:
Every edge has evidence: source path, URL, semantic locator, confidence class. Heuristic edges are never promoted to direct.

EXECUTION_CONTRACT:
Emit farmbot-graph.edges.ndjson, farmbot-impact-index.json, unresolved-mappings.csv, and Graphviz/Mermaid diagram.

---

/task
repo: via-decide/electronics
mode: farmbot-compatible-utm-tool-v0.1
tier: T5
estimated_time: 420
version: 1
depends_on: farmbot-source-intake-v0.1
task: Design a FarmBot-compatible UTM tool concept using official UTM pin mapping. Start with a passive tool-ID/soil-sensor adapter, then define enclosure, connector, cable, firmware command, and validation protocol.

CAUSATION:
The UTM is FarmBot’s highest-value extension boundary. A safe custom tool proves CAD + electronics + firmware + API integration without cloning the full machine.

CONVERGENCE:
Tool design passes mechanical fit, pin mapping, voltage/current limit, tool verification, and dry-run sequence validation before any live plant operation.

EXECUTION_CONTRACT:
Deliver KiCad schematic, OpenSCAD/STEP enclosure, BOM, firmware command map, test plan, and risk register. No powered tool actuation until bench validation passes.
