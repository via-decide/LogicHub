# FarmBot Deep Research Report

## 1. Executive synthesis

FarmBot is a production-grade open-source CNC farming platform built around a Cartesian XYZ gantry, a raised-bed growing area, a Raspberry Pi running FarmBot OS, a Farmduino electronics controller, tool-changing hardware, and a web-connected control plane.

For a LogicHub or Daxini-style engineering platform, FarmBot is valuable because it spans almost every domain needed for hardware collaboration: CAD and mechanical assemblies, BOM and manufacturing documentation, embedded electronics and wiring, firmware and G-code/F-code control, Linux/Raspberry Pi OS image build flow, Web app, REST API, MQTT/AMQP/WebSocket messaging, tooling, sensors, watering, seeding, and crop-operation workflows.

FarmBot should not be treated only as a gardening robot. It is better understood as an open-source cyber-physical product reference: a CNC machine, IoT device, agricultural automation system, robotics API platform, and commercial open hardware case study.

## 2. Source-derived facts

### 2.1 Open-source position

FarmBot states that its hardware resources include assembly instructions, CAD models, schematics, and bill of materials for modification, repair, and building upon the machine. The licensing page states that FarmBot is legally bound to openly share products at public release, including hardware, software, and documentation. It lists hardware and documentation under CC0, software under MIT, and non-functional works under Creative Commons Attribution-NonCommercial 4.0.

Implication: FarmBot is unusually permissive for engineering reuse, especially compared with GPL-style or noncommercial hardware ecosystems. The main caution is that logos, images, branding, marketing material, and non-functional works are not the same as hardware CAD or software code.

### 2.2 Product generation and mechanical scope

FarmBot Genesis v1.8 and Genesis XL v1.8 are documented as current shipping products. Genesis v1.8 covers 1.5m x 3m / 4.5m² and Genesis XL covers 3m x 6m / 18m². The product uses anodized aluminum extrusions and plates, UV-stabilized ABS plastic parts, stainless steel and aluminum hardware, and a Universal Tool Mount.

The Genesis product page identifies standard tools: watering nozzle, soil sensor, rotary tool, seed injector, seed bin, and seed tray.

The UTM enables automatic tool changing and custom tooling. It uses magnets for mechanical coupling and 12 pogo-pin electrical contacts for ground, 5V, 24V, analog/digital I/O, and I2C-style expansion.

### 2.3 Electronics architecture

FarmBot Genesis electronics center on Raspberry Pi as communications/application brain and Farmduino as motor/peripheral controller. The documented connection is USB/serial between Pi and Farmduino using a G-code-like language. The Farmduino controls stepper drivers, motors, UTM, peripherals, and power/control to electronic components.

The v1.8 Farmduino is documented as using ATmega2560 plus an STM32 coprocessor, integrated TMC2130 drivers, 24V input, a 7.5A blade fuse, five stepper driver channels, peripheral current sensing, and encoder-related features.

### 2.4 Software architecture

FarmBot’s software stack includes FarmBot Web App, FarmBot OS, Arduino/Farmduino firmware, a RabbitMQ-backed message broker, FarmBot JS, and FarmBot Python.

The Web App stores account data, farm designs, sequences, authorization tokens, and other resources. FarmBot OS communicates with the Web App via HTTP and AMQP. The firmware receives G-code/F-code commands and reports results.

### 2.5 Firmware control model

The firmware receives G-codes from Raspberry Pi, executes them, and reports back results. The firmware README identifies `src.ino` as containing setup and main loop and shows the command path:

`farmbot_arduino_controller -> Command -> GCodeProcessor -> Handler -> Movement / PinControl`.

The firmware supports movement commands such as G00, homing commands, calibration commands, pin read/write commands, servo commands, emergency stop, and movement abort. The README warns that FarmBot will not move until configuration is approved.

### 2.6 Academic/research extension

A 2025 paper used a customized FarmBot Genesis v1.7 for 3D flower pose estimation in small-scale urban farming and robotic pollination. The paper describes FarmBot as a scalable XYZ gantry robot covering up to 18m² and used a custom 2-DOF camera end-effector mounted to the UTM. It reports approximately 80% flower detection and 7.7 degree mean pose error for the best method.

Implication: FarmBot is not limited to consumer gardening. It is already being adapted as a repeatable robotic phenotyping and data-acquisition platform.

## 3. System architecture

```text
User / Browser / Tablet
        |
        v
FarmBot Web App
  - farm designer
  - sequence builder
  - logs
  - REST API
  - user/account/device data
        |
        +--> REST API for persistent resources
        |
        +--> Message Broker: WebSockets / MQTT / AMQP
                |
                v
Raspberry Pi running FarmBot OS
  - Elixir/Nerves OS image
  - WiFi configurator
  - schedule sync
  - command execution
  - camera/image capture
  - device status/log upload
        |
        v
USB/Serial G-code/F-code bridge
        |
        v
Farmduino
  - ATmega2560 command execution
  - STM32 encoder coprocessor
  - TMC2130 stepper control
  - peripheral outputs
  - sensor input
        |
        v
Physical machine
  - X/Y/Z gantry
  - UTM
  - watering / seeding / soil sensor / rotary tool
  - raised bed infrastructure
```

## 4. LogicHub intake model

| Domain | Source target | LogicHub object type |
|---|---|---|
| Mechanical CAD | Onshape assemblies, STEP, drawings | mechanical.part, assembly, mate, drawing |
| PCB/electronics | Farmduino schematic/layout, UTM PCB, wiring | schematic.symbol, pcb.footprint, net, connector |
| BOM | Genesis v1.8 BOM table and component pages | bom.item, supplier, quantity, cost basis |
| Firmware | farmbot-arduino-firmware | firmware.module, command, pin map |
| Device OS | farmbot_os | embedded.os, service, release image |
| Web app | Farmbot-Web-App | web.api, sequence, resource, token, broker |
| Libraries | farmbot-js, farmbot-py | sdk.command, API binding |
| Operations | assembly/manufacturing docs | process.step, QA gate, packing gate |

### Cross-domain relationships to extract

- BOM item -> CAD part.
- BOM item -> manufacturing process.
- Farmduino pin -> peripheral connector.
- Farmduino pin -> firmware command.
- UTM pogo pin -> tool function.
- Tool -> sequence command.
- Web app sequence -> CeleryScript node -> broker message -> FarmBot OS action -> firmware G/F-code.
- Firmware movement command -> X/Y/Z stepper channel -> physical gantry axis.
- Sensor reading -> firmware response -> FarmBot OS state tree -> web app log.

## 5. Build feasibility

### What can be built from public sources

A technically capable team can use the public sources to study or modify FarmBot software, build add-on scripts using FarmBot JS/Python, customize sequences and tools, export CAD from Onshape after creating a copy, inspect BOM categories and part-level specs, replicate parts where the manufacturing path is practical, design compatible UTM tools, and build a deterministic source manifest for the platform.

### What cannot be assumed without manual export

This bundle does not prove that all fabrication-ready data has been collected. You still need to manually export and verify STEP files, 2D drawings, production drawings, Farmduino PCB source files, Gerbers, pick-and-place, BOM spreadsheets, supplier alternates, electrical test fixtures, firmware release version compatibility, and exact hardware revision mapping.

## 6. Productization opportunities

### India/education/agri lab wedge

FarmBot’s strongest near-term fit is controlled-scale agriculture automation: schools, universities, agri-tech labs, plant phenotyping, greenhouse R&D, hydroponics/aeroponics experiments, agriculture automation demos, accessibility gardening, and STEM robotics education.

### LogicHub.app wedge

FarmBot can become the reference “GitHub for hardware” demo because it has deep cross-domain sources, visible mechanical motion, electronics/firmware/software boundaries, multiple versions, BOM and manufacturing concerns, and custom tool extension points.

### Daxini OS/local-first wedge

FarmBot is web/cloud-connected by default. A Daxini experiment can ask which control logic can run offline, whether garden sequences can be compiled into a local deterministic AST, whether Raspberry Pi can run a local state machine with signed recipe/tool manifests, and whether command execution can be replayed and validated before actuation.

### Hanuman.solutions service wedge

Potential services: setup and calibration, custom UTM tool design, FarmBot-to-local-server deployment, data logging and phenotyping pipeline, CAD/BOM source intake and version-control service, replacement part sourcing, and local fabrication support.

## 7. Risks and failure modes

| Risk | Why it matters | Mitigation |
|---|---|---|
| Outdoor environment | Water, UV, dust, soil, insects, cable fatigue | IP-rated enclosures, UV materials, strain relief, inspection |
| Mains electricity | 110/220V supply and water proximity | GFCI, certified power supply, isolation, no live rewiring |
| Mechanical binding | Misaligned gantry causes wear and stalls | Gantry equalization, rail alignment, belt tension QA |
| Tool misidentification | Wrong tool can damage plants or machine | UTM verification, tool manifest, electrical ID check |
| Cloud dependency | Internet required for normal control path | Local-first sequence cache and fail-safe manual control research |
| Self-hosting risk | Data loss/security issues if operated incorrectly | Avoid production self-hosting until audited |
| Firmware/hardware mismatch | Wrong board selection can damage behavior | Pinout manifest and revision-specific firmware |
| Licensing confusion | Hardware/software/branding have different terms | File-level license inventory before commercialization |
| Agriculture outcome uncertainty | Robotics does not guarantee yield | Treat as automation/R&D platform, not ROI guarantee |

## 8. Go / No-Go

**Go** for a FarmBot research/intake bundle, LogicHub source graph, and productization study.

**No-Go** for direct commercial cloning without full license inventory, exported source files, design-revision confirmation, safety review, electrical compliance review, supplier QA, local support model, and respect for trademark/non-functional licensing boundaries.

## 9. Next action

Start with deterministic source intake: export Onshape CAD, download Farmduino/UTM electronics sources, export BOM to CSV, clone software repos, hash all files, then build a FarmBot engineering relationship graph.
