# FarmBot Open-Source Research Bundle

Generated: 2026-07-30

This is a deep-research and implementation-planning bundle for FarmBot as an open-source hardware/software product reference. It does **not** contain exported official CAD, Gerbers, STEP, or complete BOM spreadsheets, because FarmBot's primary CAD/manufacturing assets are hosted through external documentation links such as Onshape and Google Drive. The bundle instead provides a source map, architecture analysis, intake checklist, LogicHub/GN8R implementation tasks, productization notes, and validation plans.

## Core verdict

FarmBot is one of the strongest open-source hardware/software products for a LogicHub-style engineering intake study because it combines mechanical gantry hardware, open CAD/BOM/schematic references, Raspberry Pi based embedded software, Farmduino firmware, REST API and realtime message broker architecture, interchangeable tooling through the Universal Tool Mount, education/research/commercial positioning, and documented manufacturing and assembly flow.

## Recommended next action

Create a FarmBot source-intake workspace:

1. Export official Onshape assemblies and drawings.
2. Download Farmduino schematic/layout sources from the official docs.
3. Export the v1.8 BOM table into CSV.
4. Clone the relevant GitHub repositories.
5. Generate a deterministic source manifest with hashes.
6. Build a cross-domain relationship graph: CAD part -> BOM row -> wiring -> Farmduino pin -> firmware command -> web app/API resource.

## Bundle contents

See `bundle_manifest.json` and `source_manifest.csv`.
