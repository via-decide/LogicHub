# FarmBot GitHub Repository Map

## High-priority repositories

| Repository | Role | Intake action |
|---|---|---|
| FarmBot/Farmbot-Web-App | Web UI, RESTful JSON API, Dockerized MQTT server | Clone, parse Rails/React/TS/Ruby surfaces, extract API resources and broker topics |
| FarmBot/farmbot_os | Raspberry Pi OS image/runtime | Clone, extract Elixir/Nerves modules, release config, update flow, hardware support |
| FarmBot/farmbot-arduino-firmware | Farmduino microcontroller firmware | Clone, parse G/F-code handlers, board configs, pin maps, motion/peripheral commands |
| FarmBot/farmbot-js | JavaScript client/RPC wrapper | Extract public command surface and examples |
| FarmBot/farmbot-py | Python client | Extract public command surface and examples |
| FarmBot/farmbot-mqtt-py | MQTT examples/library | Extract broker access examples |

## Source-intake commands

```bash
mkdir -p farmbot-source-intake/repos
cd farmbot-source-intake/repos

git clone https://github.com/FarmBot/Farmbot-Web-App.git
git clone https://github.com/FarmBot/farmbot_os.git
git clone https://github.com/FarmBot/farmbot-arduino-firmware.git
git clone https://github.com/FarmBot/farmbot-js.git
git clone https://github.com/FarmBot/farmbot-py.git
git clone https://github.com/FarmBot/farmbot-mqtt-py.git
```

## Hash manifest command

```bash
find farmbot-source-intake -type f -print0 | sort -z | xargs -0 shasum -a 256 > farmbot-source-intake/SHA256SUMS.txt
```

## Must not miss

- Firmware stable release tag, not only `main`.
- Farmduino hardware revision, not only software branch.
- v1.8 BOM rows, not old v1.6/v1.7 rows.
- CAD export version and Onshape document/version ID.
- License per asset type.
