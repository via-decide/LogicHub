# FarmBot CAD, BOM, and Manufacturing Intake Plan

## Objective

Create a deterministic source bundle suitable for LogicHub CAD/BOM/electronics implementation.

## Manual export requirements

| Asset | Source | Export format | Required verification |
|---|---|---|---|
| Top-level CAD assembly | Onshape | STEP, Parasolid, STL preview, PDF drawings | Confirm version and document ID |
| Tracks | Onshape | STEP + drawings | Extrusion length, hole pattern, fasteners |
| Gantry | Onshape | STEP + drawings | Squareness, belt path, motor placement |
| Cross-slide | Onshape | STEP + drawings | V-wheel spacing, carriage stiffness |
| Z-axis | Onshape | STEP + drawings | Tool mount interface, cable routing |
| UTM | Onshape | STEP + PCB/mechanical drawings | Magnet placement, pogo pin layout, liquid/gas ports |
| Tools | Onshape | STL/STEP + drawings | Watering, seeding, soil sensor, rotary tool |
| Farmduino | Google Drive/source link from docs | Schematic, board file, Gerbers, BOM, pick-place | Revision match to v1.8 Farmduino v1.6 |
| UTM PCB | BOM part page/source link | Schematic/Gerber/BOM | Pinout matches UTM table |
| BOM | Genesis v1.8 BOM page | CSV/XLSX | Quantity, price, cost, part revision, notes |
| Manufacturing docs | Genesis manufacturing docs | Markdown/PDF/screenshots | Process sequence and QA gates |

## Acceptance criteria

- Every exported file has SHA-256.
- Every CAD export records source URL/document/version.
- Every BOM row maps to a part category.
- Every electronics connector maps to a pinout source.
- Every firmware pin action maps to a Farmduino pin or reports unknown.
- No asset is treated as current v1.8 unless the source page proves it.
