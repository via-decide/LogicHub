# SiC MOSFET Basics

## Why silicon carbide reshapes power switching

A SiC MOSFET is a **normally-off, insulated-gate, voltage-controlled power transistor** built on silicon carbide rather than silicon. Under IEC 60747-8, field-effect transistors include insulated-gate enhancement devices as **type C**, which is the category that matches commercial normally-off power MOSFET behavior; the older IEC 60747-8-4 publication also explicitly covered MOSFETs for power switching with inverse diodes. Current SiC product lines from Wolfspeed, STMicroelectronics, onsemi, and Infineon all fit that practical pattern: N-channel, enhancement-mode, high-voltage switches intended for hard- or resonant-switching power conversion. citeturn20search1turn20search0turn11view0turn11view1turn23view1turn27search10

What changes with SiC is not the switching principle, but the material limits. Toshiba’s comparative wide-bandgap materials table gives representative intrinsic values of about **1.12 eV** bandgap and **3.0×10^5 V/cm** breakdown field for silicon, versus about **3.26 eV** and **2.8×10^6 V/cm** for 4H-SiC; it also lists thermal conductivity of **1.5 W/cmK** for silicon and **4.9 W/cmK** for 4H-SiC. Those larger margins are the reason SiC can support high blocking voltage with a thinner, more heavily doped drift region and still keep conduction loss low enough to remain attractive as a **unipolar** device at voltages where silicon often shifts toward IGBTs. Review literature and Baliga’s framework tie the same outcome to the material figure-of-merit for power switching. citeturn34search2turn19search1turn8search3turn30search0

A compact starting comparison is below.

| Representative material property | Si | 4H-SiC | GaN | Why it matters |
|---|---:|---:|---:|---|
| Bandgap | 1.12 eV | 3.26 eV | 3.39 eV | Lower leakage and better high-temperature behavior |
| Critical electric field | 0.3 MV/cm | 2.8 MV/cm | 3.3 MV/cm | Higher blocking voltage with thinner drift region |
| Thermal conductivity | 1.5 W/cmK | 4.9 W/cmK | 2.0 W/cmK | Easier heat spreading |
| Saturated electron drift velocity | lower | higher | higher | Supports faster switching |

These are representative intrinsic values from Toshiba’s materials reference for Si, 4H-SiC, and GaN; exact numbers vary somewhat across sources and measurement assumptions, but the ordering is stable. citeturn34search2

That physics explains the market position. Baliga’s 2023 review describes SiC power devices as already commercialized and broadly adopted; Infineon’s current discrete portfolio spans **400 V to 2300 V**, with 650 V, 1200 V, and 2300 V product families explicitly marketed for server PSUs, EV charging, UPS, renewables, ESS, and industrial power stages. In practice, the mainstream “learn SiC” zone is still centered around roughly **650 V to 1700 V**, even though portfolios are now extending lower and higher. citeturn30search0turn27search10turn27search13turn14search12turn27search5

The economic consequence is system-level, not device-level. Wolfspeed’s design note argues that, although SiC switches cost more than IGBTs, a frequency-optimized design can move the cost optimum from about **18 kHz** for IGBTs to about **60 kHz** for SiC MOSFETs, with roughly **20% to 25%** system-level cost savings once cooling and passive components are included. That is the right “basics” lens: compare **converter BOM, efficiency, and density**, not only the transistor ASP. citeturn31view0turn31view1turn31view2

## What the device physically is

Commercial SiC MOSFETs are typically built on **4H-SiC**, the dominant commercial polytype because of its favorable carrier mobility and breakdown characteristics. Review literature continues to describe 4H-SiC as the practical substrate and epitaxial platform for high-voltage SiC MOSFET production. citeturn18view1turn18view3

The standard device is a **vertical N-channel MOSFET**. Current enters at the source metallization on the top of the die, is modulated by an inversion channel formed under the gate oxide in the p-body, then flows through the JFET constriction and n-drift region to the drain at the backside. A recent wide-bandgap review describes that same top-to-bottom current path and notes that the vertical architecture is what lets SiC MOSFETs handle voltages above roughly 900 V in compact die footprints. citeturn18view3

A useful simplified cross-section is:

```text
Source metal
n+ source
p-body
gate oxide + gate
channel at SiO2/SiC interface
JFET region
n- drift region
n+ substrate / drain
drain metal
```

That model is enough to understand most first-order trade-offs. The drift region is where SiC wins against silicon on specific on-resistance; the channel and gate oxide are where SiC remains more demanding than silicon. A 2022 processing review summarizes the central point directly: SiC’s much higher critical field enables a thinner, more highly doped drift region for the same breakdown voltage, which lowers specific on-resistance and shrinks die size. citeturn19search1

The main beginner trap is to assume that this is simply “a faster silicon MOSFET.” It is not. The SiO2/SiC interface remains a major reliability and performance constraint. Recent reviews on positive-bias temperature instability and gate oxide degradation describe threshold-voltage instability, charge trapping in interface and border defects, and oxide-related degradation as central SiC MOSFET concerns; other reliability reviews continue to flag gate-oxide deterioration, threshold instability, and body-diode degradation as mainstream failure themes. citeturn17view4turn26search13turn19search14turn25search20

That interface problem shows up immediately in gate-drive recommendations. ROHM’s 2024 drive-voltage note warns that SiC MOSFETs should be driven according to the data-sheet-recommended gate window, and states plainly that too-low drive voltage can cause performance and reliability problems. Its example recommendation is **15 V to 18 V** for turn-on, while Infineon’s 2025 CoolSiC datasheet interpretation note recommends **15 V to 18 V** for turn-on and **-5 V to 0 V** for turn-off, depending on the application and chosen safety margin. citeturn11view5turn23view3

Every practical SiC MOSFET also includes reverse-conduction behavior that matters in real bridge legs. Vendors either publish an internal freewheeling diode or provide full reverse-recovery/body-diode data. Infineon explicitly says its discrete CoolSiC MOSFETs include a fast internal freewheeling diode suitable for hard switching without additional diode chips, while onsemi’s ELiteSiC datasheet publishes reverse-recovery time, reverse-recovery charge, and diode current limits. citeturn14search8turn13view2

Planar and trench structures are the other core architectural split. Baliga’s 2023 review notes that shielded planar MOSFETs became the basic commercial structure earlier, while shielded trench-gate SiC MOSFETs have reached commercial products more recently. The old shorthand that “planar is reliable and trench is risky” is now too simple: trench designs clearly reduce conduction loss and are now explicitly marketed by vendors such as Infineon for **superior gate oxide reliability** and stronger immunity against parasitic turn-on, but trench-corner field management and shielding are still central design topics in the literature. citeturn30search1turn14search12turn26search4turn26search12

## How losses, reverse conduction, and part choice work

For first-pass design, the useful decomposition is still the classic one:

\[
P_{\mathrm{cond}} \approx I_{\mathrm{RMS}}^2 \cdot R_{\mathrm{DS(on)}}(T_J)
\]

\[
P_{\mathrm{sw}} \approx f_{\mathrm{sw}} \cdot (E_{\mathrm{on}} + E_{\mathrm{off}})
\]

\[
P_{\mathrm{gate}} \approx Q_g \cdot V_g \cdot f_{\mathrm{sw}}
\]

TI’s gate-driver fundamentals note separates MOSFET power loss into conduction, switching, and gate-related mechanisms, while Infineon’s switching-characteristics guidance defines the switching times and the energy integrals used for \(E_{\mathrm{on}}\) and \(E_{\mathrm{off}}\). For thermal closure, Infineon also gives the steady-state relation \(T_j \approx T_c + P_{\mathrm{dis}}R_{\theta(j-c)}\), which is the minimum useful thermal model for a first spreadsheet. citeturn22search2turn13view7turn13view6

That leads to the first real selection rule. **Low \(R_{\mathrm{DS(on)}}\)** matters most when RMS current dominates. **Low \(Q_g\), \(Q_{gd}\), and \(C_{oss}\)** matter more as switching frequency rises and dv/dt becomes the dominant pain point. Wolfspeed’s design note states that trade directly: lower \(R_{\mathrm{DS(on)}}\) reduces conduction losses, lower \(Q_g\) reduces switching losses, and the relevant figure of merit is their product, not either number alone. citeturn31view1turn31view3

Representative current devices make that trade visible.

| Device | Voltage class | Package | Highlights | Source |
|---|---:|---|---|---|
| Wolfspeed C3M0016120K | 1200 V | TO-247-4 | 16 mΩ typ, \(Q_g\) 211 nC, \(C_{oss}\) 230 pF, \(R_{\theta JC}\) 0.27 °C/W, separate driver source pin, \(T_J\) to 175 °C | citeturn13view0turn12view1turn12view3 |
| ST SCTWA60N120G2-4 | 1200 V | HiP247-4 | 35 mΩ typ, \(Q_g\) 94 nC, \(C_{oss}\) 113 pF, \(R_{\theta JC}\) 0.45 °C/W, recommended \(V_{GS}\) -5 to 18 V, \(T_J\) to 200 °C | citeturn23view0turn13view1 |
| onsemi NTH4L060N090SC1 | 900 V | TO-247-4L | 60 mΩ typ at 15 V, \(Q_g\) 87 nC, \(C_{oss}\) 113 pF, \(R_{\theta JC}\) 0.68 °C/W, recommended \(V_{GS}\) -5/+15 V, avalanche energy 162 mJ | citeturn13view2turn23view1 |

The lesson from that table is straightforward: **do not compare milliohms in isolation**. The Wolfspeed part is optimized extremely hard for conduction loss, but carries substantially higher gate charge. The ST part gives up on-resistance to cut charge and capacitance dramatically. The onsemi part illustrates a lower-voltage class with a conservative **-5/+15 V** drive window and explicit avalanche data. Depending on switching frequency, current, dead-time strategy, and thermal limits, any of the three can be the right answer. citeturn13view0turn23view0turn13view2

Third-quadrant behavior is part of the same decision. During dead time in a half bridge, current has to commutate somewhere. SiC MOSFETs can use the intrinsic body diode, synchronous channel conduction, or an alternative current path depending on topology and control. That choice matters because body-diode degradation in commercial SiC MOSFETs is still linked to **basal-plane-dislocation-induced stacking faults**, and recent work continues to investigate how repeated bipolar conduction affects long-term drift. In parallel, Wolfspeed’s own application material highlights how much smaller reverse-recovery charge can be for SiC than for silicon; one Wolfspeed comparison cites roughly **11 nC** and **16 ns** for a 650 V SiC MOSFET versus roughly **13 µC** and **725 ns** for a typical 650 V silicon MOSFET. citeturn25search1turn31view0turn28search3

That is why reverse-conduction strategy is not an afterthought. Use the body diode only because the commutation requires it, not because it is “free.” Dead time, gate bias, and synchronous conduction policy belong in the first design review, not the last one. citeturn25search1turn14search8

## How to keep a half bridge stable

SiC’s system advantage disappears quickly if the gate loop is sloppy. Wolfspeed’s 2024 layout note states the core problem directly: the higher dv/dt and di/dt of SiC MOSFETs, coupled with parasitic capacitances and loop inductances, make circuits more sensitive to crosstalk, false turn-on, voltage overshoot, ringing, and EMI. The same note recommends a compact low-inductance gate loop, minimizing parasitic capacitance, and placing the driver as close as possible to the MOSFET. ROHM’s 2024 layout note says the same thing in board-language: fast SiC switching needs explicit countermeasures against gate-source and drain-source surges and false triggering in bridge configurations. citeturn13view3turn11view4

Gate-bias practice reflects that reality. Infineon’s current CoolSiC guidance recommends **15 V to 18 V** for turn-on and **-5 V to 0 V** for turn-off, while its isolated SiC-ready driver portfolio highlights **100 kV/µs** common-mode transient immunity plus features such as active Miller clamp and soft turn-off. ROHM’s gate-voltage note adds a practical warning: driving too low can increase loss and, in some regions, push the device toward an unfavorable temperature coefficient that complicates parallel operation and can raise thermal-runaway risk. citeturn23view3turn3search2turn3search4turn11view5

The **Kelvin source** is one of the highest-leverage improvements in discrete SiC hardware. Wolfspeed’s datasheets and product material, onsemi’s TO-247-4L documents, and Wolfspeed’s E-series package comparison all show why: separating the power source from the driver return reduces common-source inductance seen by the gate loop. Wolfspeed’s example with the same die in a 3-pin versus 4-pin package shows a very large reduction in total switching energy when the Kelvin source is used, and its design note calls the Kelvin source critical for preserving SiC’s high-frequency advantage. citeturn11view0turn23view1turn28search5turn31view0

PCB distances matter too. Wolfspeed’s layout note gives concrete example numbers: for an **850 V** DC link, the minimum drain-to-source PCB trace spacing in the IPC-2221 example is **2.6 mm**, while the IPC-9592-style example in the same note yields **4.85 mm**. The same note also points out that TO-247-4 and TO-267-7 footprints offer greater creepage than TO-247-3. In other words, packaging, pad geometry, and creepage/clearance are part of the electrical design, not purely mechanical cleanup. citeturn24view0turn24view2turn24view4

A minimal discrete half-bridge scaffold therefore looks like this:

```text
DC bus
  ├─ bulk capacitor bank
  ├─ local film / ceramic decoupling
  ├─ high-side SiC MOSFET
  ├─ low-side SiC MOSFET
  ├─ isolated gate drivers
  │    ├─ split RGon / RGoff
  │    ├─ local decoupling
  │    ├─ Miller clamp or equivalent anti-false-turn-on strategy
  │    └─ fast fault detection and soft turn-off
  └─ current, voltage, and temperature sensing
```

This is not an “advanced” architecture. It is the practical minimum for a serious SiC half bridge. The reason is short-circuit protection speed: Infineon has published that CoolSiC short-circuit pulse duration can be on the order of **2–3 µs**, which makes slow detection methods a real risk. citeturn27search1turn17view6

The measurement method that ties these choices together is the **double-pulse test**. Keysight defines DPT as a standard method for characterizing dynamic switching performance, switching losses, voltage overshoots, recovery characteristics, and transient behavior; it explains the usual two-pulse sequence in which the first pulse establishes the desired inductor current and the second measures the actual switching event. For SiC design work, the DPT is the shortest path from datasheet assumptions to hardware truth. citeturn32view0turn32view1

## Reliability, qualification, and simulation workflow

Reliability deserves its own chapter because SiC’s benefits do not erase its specific failure modes. Recent review literature and device studies continue to converge on the same top issues: **threshold-voltage instability**, **gate-oxide degradation**, **body-diode degradation**, **short-circuit ruggedness**, **power cycling**, and **radiation-induced destructive failures**. citeturn17view4turn26search13turn25search1turn17view6turn17view2turn25search4

Threshold-voltage shift is largely a trapping problem near the oxide/interface system. A 2024 PBTI study on SiC power MOSFETs attributes \(\Delta V_{TH}\) to both trapping in pre-existing interface/border defects and the creation of deeper oxide-related defects under stress, while broader gate-oxide degradation reviews emphasise that SiC MOSFETs are more susceptible than silicon devices because the SiC/SiO2 interface is more defective and the gate oxide is often pushed to high field to keep channel resistance acceptable. citeturn25search3turn26search13

Body-diode reliability remains a distinctly SiC topic. A 2024 investigation of commercial devices ties body-diode degradation to **BPD-induced stacking faults**, and Baliga’s 2023 review highlights architectures such as JBS-integrated MOSFET concepts precisely to suppress current through the body diode. The practical design implication is simple: reduce unnecessary bipolar stress wherever the topology and control permit. citeturn25search1turn30search1

Short-circuit robustness is a second major difference versus IGBTs. A 2024 review of short-circuit protection methods summarizes why SiC MOSFETs break so fast: smaller chip area, lower heat capacity, thinner oxide, and very high short-circuit current density can drive failure within only a few microseconds. Infineon’s own protection article similarly cites **2–3 µs** short-circuit pulse duration for CoolSiC MOSFETs. That is why the gate driver, detection path, and soft-turn-off strategy are design primitives, not accessories. citeturn17view6turn27search1

Radiation is also real for high-reliability systems. JEDEC **JEP151A:2022** is the current test procedure for terrestrial cosmic-ray-induced destructive effects in power semiconductor devices, including SEB, SEL, and SEGR testing. Infineon’s recent knowledge-base article likewise treats cosmic-radiation FIT rate as a practical power-semiconductor concern rather than a niche academic issue. citeturn33view1turn5search8

Qualification language matters because “qualified” rarely means “qualified for my waveform.” AEC’s standards index lists **AEC-Q101** as the stress-test qualification framework for discrete semiconductors; **JESD22-A108G** is JEDEC’s active “Temperature, Bias, and Operating Life” method used for accelerated device qualification and reliability monitoring; and JEP151A covers terrestrial cosmic-ray destructive effects. Recent SiC power-cycling reviews also point out that there is still no globally unified international standard dedicated specifically to SiC power-cycling tests, so application-relevant dynamic stress often matters as much as formal JEDEC/AEC screening. citeturn5search6turn33view2turn33view1turn17view2

The simulation stack is now mature enough that there is no excuse to skip it.

| Tool class | Best use in SiC work | Official signal |
|---|---|---|
| LTspice | fast schematic iteration, gate-loop what-ifs, snubbers, startup behavior | ADI describes LTspice as a fast, free SPICE simulator with schematic capture and waveform viewing. citeturn6search0 |
| PLECS | system-level converter and electrothermal studies | Plexim positions PLECS as the standard simulation software for power electronics. citeturn6search1 |
| PSIM | converter, motor-drive, loss, EMI, and control studies | Altair describes PSIM as an all-in-one power electronics and motor-drive simulation/design environment. citeturn6search2 |
| MATLAB / Simscape Electrical | control co-design and SPICE-to-lookup-table device modeling | MathWorks provides an official SiC MOSFET example that converts SPICE subcircuits to lookup tables. citeturn7search0turn7search14 |
| Vendor online tools | application-parasitic-aware loss estimation and part selection | onsemi’s Elite Power Simulator and Self-Service PLECS Model Generator are explicitly built for custom, high-fidelity power-stage modeling. citeturn7search1turn7search2turn7search4 |

The correct workflow is not complicated. Start with an ideal half bridge. Replace ideal switches with vendor SPICE or lookup-table models. Add package and bus parasitics. Tune \(R_G\), dead time, and clamping against DPT-like stress. Then move into EMI, thermal stack-up, and fault handling. MathWorks, onsemi, Plexim, Altair, and ADI all support parts of that sequence directly in their official tool flows. citeturn6search0turn6search1turn6search2turn7search0turn7search1turn7search2

## Operator pipeline and verdict

**Source**  
This report is grounded in current IEC, AEC, and JEDEC standards references; peer-reviewed reviews and device studies on SiC materials, reliability, and short-circuit behavior; and current official datasheets and application notes from Wolfspeed, STMicroelectronics, onsemi, Infineon, ROHM, TI, Keysight, Analog Devices, Plexim, Altair, MathWorks, and onsemi’s simulation-tool pages. That source mix is the right one for a fundamentals report because SiC behavior is set first by material physics, then by MOSFET structure, then by drive/layout, and finally by qualification practice. citeturn20search1turn5search6turn33view2turn33view1turn11view0turn11view1turn23view1turn13view3turn6search0turn6search1turn6search2turn7search0turn7search1

**Access / Entry**  
The fastest clean entry into SiC is through material limits, not converter topology. Once you understand that 4H-SiC has a much wider bandgap, much higher critical electric field, and much higher thermal conductivity than silicon, the rest follows naturally: lower specific on-resistance at high voltage, faster hard switching, higher useful temperature margin, and a stronger incentive to shrink magnetics and cooling. citeturn34search2turn19search1turn8search3

**Intent Capture**  
The practical question behind “SiC MOSFET basics” is: what does an engineer need to know before laying out a real half bridge? The essential answer is device structure, loss buckets, reverse-conduction behavior, gate-drive windows, Kelvin-source packaging, compact gate loops, DPT workflow, and the specific reliability map of oxide stress, short-circuit stress, and body-diode stress. citeturn18view3turn31view1turn13view3turn32view0turn17view6turn25search1

**State / Logic Engine**  
The logic chain is linear. Material properties set the drift-region advantage. The MOS structure adds channel and oxide constraints. Those constraints set the gate-drive voltage window and the layout discipline. Layout and packaging then determine whether the device actually achieves the switching energies promised in the datasheet. Reliability and standards define whether the result is product-grade or only lab-grade. citeturn19search1turn17view4turn23view3turn28search5turn17view2

**Actions**  
The actionable sequence for a first serious design cycle is: choose a voltage class and package; compare \(R_{\mathrm{DS(on)}}\), \(Q_g\), \(Q_{gd}\), \(C_{oss}\), and \(R_{\theta JC}\) together; choose a driver that can support the vendor’s recommended gate window and high CMTI; keep the gate loop compact and Kelvin referenced; run DPT across at least two \(R_G\) values and two dead-time values; then validate thermal rise, fault handling, and qualification assumptions. citeturn13view0turn23view0turn13view2turn3search2turn13view3turn32view0

**Output / Metrics**  
“Good enough” for a first pass means: acceptable \(E_{\mathrm{on}}\) and \(E_{\mathrm{off}}\), controlled overshoot and ringing, no parasitic turn-on, reverse-conduction behavior that matches the control strategy, steady-state junction temperature inside margin, and protection reaction time consistent with SiC’s short-circuit window. For product work, add qualification evidence against AEC-Q101-style stress, JESD22-A108 operating-life stress, and radiation derating if the mission profile requires it. citeturn32view1turn17view6turn5search6turn33view2turn33view1

**Block explanations**  
The material block explains *why* SiC is attractive. The device block explains *what the transistor is*. The loss block explains *when one part beats another*. The gate-drive/layout block explains *whether the board will switch cleanly*. The reliability block explains *whether it will survive beyond the bench*. citeturn34search2turn18view3turn31view1turn13view3turn17view4turn17view6

**Risks / failure modes**  
The canonical SiC risk map is: gate-oxide degradation and threshold shift, parasitic turn-on from Miller current and common-source inductance, drain overshoot and ringing from commutation-loop inductance, body-diode degradation under repeated bipolar conduction, and short-circuit failure in only a few microseconds. In higher-reliability deployments, add terrestrial cosmic-ray-induced destructive effects to the list. citeturn26search13turn13view3turn25search1turn17view6turn33view1

**Monetisation logic**  
SiC monetizes when it improves the **system**, not when it is treated as a drop-in silicon substitute. The major levers are higher switching frequency, smaller magnetics, lower cooling burden, lower enclosure cost, and better efficiency at partial load. That is why SiC is strongest in EV charging and traction, UPS, solar and storage, industrial drives, server/telecom power, and hard-switched PFC. Wolfspeed’s own cost trade study is the cleanest shorthand: more expensive die, lower total system cost when the converter is re-optimized around SiC. citeturn31view2turn27search10turn14search12turn7search13

**Feasibility + effort**  
Reaching first competence is realistic. One discrete half bridge, one isolated driver pair, one clean PCB, and one DPT workflow are enough to build real intuition. The jump from “works in the lab” to “qualified product” is much larger because AEC/JEDEC stress, humidity bias, power cycling, repetitive dynamic stress, and application-specific derating quickly become gating workstreams. citeturn32view0turn17view2turn5search6turn33view2

**Verdict**  
**Go** when the bus is roughly **650 V and above**, switching frequency and power density matter, and the team can execute disciplined gate-drive, Kelvin-source packaging, compact layout, and fast protection. **Change** to silicon or a simpler topology when switching frequency is modest, passives are already small enough, or the organization cannot yet support the measurement and protection discipline SiC requires. That is the correct fundamentals-level decision rule. citeturn30search0turn27search10turn31view1turn13view3turn17view6

**One next action**  
Build or simulate a single **800 V to 900 V half bridge** and run a proper double-pulse characterization loop. Extract \(E_{\mathrm{on}}\), \(E_{\mathrm{off}}\), overshoot, ringing, reverse-conduction behavior, and gate-voltage margin across at least two gate-resistor settings and two dead-time settings before touching a full converter. That one exercise compresses most of the practical SiC learning curve. citeturn32view0turn32view1turn7search1turn7search2