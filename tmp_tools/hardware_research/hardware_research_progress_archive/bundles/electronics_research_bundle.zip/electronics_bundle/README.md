# Electronics Research Bundle

Contents:

1. `SiC_MOSFET_Basics.md` — SiC MOSFET fundamentals, architecture, losses, gate drive, layout, reliability, simulation workflow, operator pipeline and verdict.
2. `Embedded_Linux_Engineering_Report.md` — Embedded Linux production engineering report, architecture, BSP/build systems, boot chain, security, OTA, real-time behavior, vendor platform landscape and implementation roadmap.
