# License and Commercialization Notes

## Source-derived license position

Voron Design forum resources state that Voron Design does not sell anything and releases its designs under GPLv3. The GitHub repository pages also commonly show GPL-3.0 licensing.

## Practical implication

GPLv3 does not prevent commercial activity, but it creates obligations when distributing modified covered works. For a Voron-derived hardware/CAD/product project, treat the following as likely compliance surfaces:

- modified CAD/printed parts,
- derived STL/STEP/panel/DXF assets,
- electronics PCB designs derived from Voron-Hardware,
- modified manuals or source documents,
- firmware/config files if distributed as covered source.

## Safer commercialization models

| Model | Why safer |
|---|---|
| Build service | Uses official open-source design; charges labor, QA, calibration |
| Sourcing verification service | Produces BOM checks and local supplier validation |
| Printed-part QA service | Sells printing quality + receipts, not hidden derivative CAD |
| Calibration service | Produces performance receipts and maintenance plans |
| Training/course/content | Educational value around building and maintaining machines |
| LogicHub source-intake tooling | Adds independent value around validation and provenance |

## Higher-risk models

| Model | Risk |
|---|---|
| White-label Voron printer with obscured source | GPL and community trust risk |
| Modified parts released without source | License violation risk |
| Using Voron marks/logos as product branding | trademark/community confusion risk |
| Complete kit without support infrastructure | high customer-support burden |
| Unverified mains wiring kit | safety and liability risk |

## Recommended commercial posture

Do not claim to be Voron. Build as:

- “Voron-compatible source-intake and validation service”
- “Voron build QA and calibration receipt service”
- “India-localized sourcing verification for open 3D printers”
- “LogicHub manufacturing-readiness workflow for open hardware”

Always preserve source attribution and separate your brand from the original project.
