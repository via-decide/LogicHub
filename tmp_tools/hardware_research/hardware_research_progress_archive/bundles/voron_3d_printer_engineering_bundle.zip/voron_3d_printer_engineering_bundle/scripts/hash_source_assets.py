#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    if len(sys.argv) != 2:
        print("usage: hash_source_assets.py <asset_root>", file=sys.stderr)
        return 2
    root = Path(sys.argv[1]).resolve()
    rows = []
    for p in sorted([x for x in root.rglob("*") if x.is_file()]):
        rows.append({
            "path": p.relative_to(root).as_posix(),
            "sha256": sha256_file(p),
            "size": p.stat().st_size,
        })
    print(json.dumps({"schemaVersion": "asset-hashes.v1", "root": str(root), "files": rows}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
