#!/usr/bin/env python3
from __future__ import annotations
import json
import re
import sys
from pathlib import Path

SHA_RE = re.compile(r"^[a-f0-9]{64}$")

def main() -> int:
    if len(sys.argv) != 2:
        print("usage: validate_voron_asset_manifest.py <manifest.json>", file=sys.stderr)
        return 2
    doc = json.loads(Path(sys.argv[1]).read_text())
    errors = []
    if doc.get("schemaVersion") != "voron.asset-manifest.v1":
        errors.append("schemaVersion must be voron.asset-manifest.v1")
    if not doc.get("model"):
        errors.append("model missing")
    if not doc.get("release"):
        errors.append("release missing")
    for i, asset in enumerate(doc.get("assets", [])):
        if not asset.get("path"):
            errors.append(f"assets[{i}].path missing")
        if not SHA_RE.match(asset.get("sha256", "")):
            errors.append(f"assets[{i}].sha256 invalid")
    if errors:
        print(json.dumps({"ok": False, "errors": errors}, indent=2))
        return 1
    print(json.dumps({"ok": True, "asset_count": len(doc.get("assets", []))}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
