# Voron Validation and Commissioning Plan

## Stage 0 — Source validation

- Confirm model, release, size, and controller board.
- Hash CAD/STLs/manual/BOM/config files.
- Compare BOM line counts with sourced components.
- Confirm printed-part quantity suffixes.
- Check panel material and thickness.
- Confirm all controller wiring references are for the selected board.

## Stage 1 — Mechanical dry build

- Frame squareness: measure diagonals.
- Rail smoothness: carriage moves without binding.
- Pulley check: no visible wobble.
- Belt routing: correct path, equal lengths, no rubbing.
- Gantry squareness: equal diagonals.
- Bed movement: free, no lead-screw binding.
- Toolhead movement: cable chain/umbilical not binding.

## Stage 2 — Electrical pre-power

- Continuity check for power rails.
- Heater resistance check.
- Thermistor sanity check.
- Fan polarity check.
- Endstop/probe continuity.
- Stepper coil-pair identification.
- Controller wiring against official selected-board wiring guide.
- No loose copper, uncrimped ferrules, or exposed mains terminals.

## Stage 3 — Firmware bring-up

- Flash MCU firmware.
- Load minimal printer.cfg.
- Verify MCU connection.
- Confirm endstop/probe state changes.
- Confirm thermistor temperatures at ambient.
- Confirm fan control.
- Confirm heater control with low-power test.
- Confirm stepper movement direction at low current.

## Stage 4 — Safety validation

- Emergency stop.
- Heater fault behavior.
- Thermistor disconnect behavior.
- Thermal runaway behavior.
- Axis limit behavior.
- Homing override behavior.
- Door/panel/interlock policy if added.
- Smoke/odor/heat inspection during first thermal cycle.

## Stage 5 — Calibration

- PID tune hotend and bed.
- Probe/bed mesh validation.
- Z offset.
- Extruder rotation distance.
- Pressure advance.
- Input shaping.
- First-layer test.
- Dimensional cube.
- Voron test cube or controlled benchmark model.
- ABS/ASA enclosure heat soak.

## Stage 6 — Product/fleet validation

- Repeatable startup checklist.
- Print-quality baseline.
- Configuration backup hash.
- Print receipt schema.
- Maintenance ledger.
- Belt retension interval.
- Nozzle/hotend spare policy.
- Controller firmware rollback plan.
- Operator training proof.
