# Prior Project Alignment

## Air-gapped 8MB storage module

Shared pattern:
- manifest hashing,
- deterministic object storage,
- offline validation,
- hardware/firmware boundary control.

Voron application:
- store machine configuration, calibration receipts, and source manifests as signed offline artifacts.

## Drone CAD implementation bundle

Shared pattern:
- host/MCU split,
- motion-control safety,
- sensor/actuator validation,
- pre-power and staged bring-up.

Voron application:
- validate printer motion and heaters in staged gates before allowing autonomous print jobs.

## Pupper V3 bundle

Shared pattern:
- real-time control concerns,
- actuator mapping,
- simulation vs hardware gap,
- telemetry and safety limits.

Voron application:
- treat Klipper config as the bridge between high-level intent and physical actuator behavior.

## FarmBot bundle

Shared pattern:
- machine axis control,
- web/device split,
- BOM/CAD/firmware source surface,
- G-code-like command model,
- agricultural/physical automation business.

Voron application:
- use FarmBot-style device/web split thinking to reason about printer fleet management.

## OpenFlexure bundle

Shared pattern:
- precision printed mechanisms,
- Raspberry Pi control,
- OpenSCAD/CAD/manufacturing intake,
- calibration receipts.

Voron application:
- formalize dimensional and motion calibration as a source-linked receipt.

## SatNOGS bundle

Shared pattern:
- distributed open hardware network,
- Raspberry Pi station control,
- source manifests,
- reproducible station deployment.

Voron application:
- create a print-farm node model with machine identity, calibration, and job receipts.
