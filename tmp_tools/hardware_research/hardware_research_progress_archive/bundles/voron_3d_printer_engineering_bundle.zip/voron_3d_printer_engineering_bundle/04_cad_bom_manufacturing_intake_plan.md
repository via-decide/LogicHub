# CAD, BOM, and Manufacturing Intake Plan

## Objective

Convert Voron release assets into a deterministic manufacturing-source package for LogicHub.

## Required asset classes

| Asset class | Expected source | Validation |
|---|---|---|
| CAD assembly | Voron GitHub release/repository | STEP/F3D/source hash + model release |
| STL printed parts | Voron GitHub STL folder | count, filename suffix quantities, material settings |
| Assembly manual | GitHub/docs linked PDF | manual revision hash |
| BOM | Voron configurator | compare with manual and CAD |
| Panel DXF | repository/panel directory | material, thickness, cut profile |
| Printer config | repo/docs/example configs | controller board and size match |
| Wiring guide | docs.vorondesign.com | controller-specific match |
| Hardware PCB assets | Voron-Hardware | KiCad/Gerber/BOM mapping |
| Mods | mods.vorondesign.com / user repos | quarantine until baseline complete |

## Printed part policy

Official printed-part settings from the docs include:
- 0.2 mm layer height
- 0.4 mm forced extrusion width
- 40% infill
- 4 walls
- 5 solid top/bottom layers
- no supports

Manufacturing intake should store these as production constraints, not loose recommendations.

## File naming semantics

Voron printed-part naming includes important production metadata:

| Pattern | Meaning |
|---|---|
| `[a]_` prefix | recommended accent part |
| `_x2`, `_x4`, etc. | multiple prints required |
| model folder | target printer/release |
| toolhead folder | may be shared between printers |
| mod folder | not baseline unless explicitly selected |

## Canonical asset manifest model

```json
{
  "schemaVersion": "voron.asset-manifest.v1",
  "model": "Voron Trident",
  "release": "pinned-release-or-commit",
  "sourceAssets": [
    {
      "path": "STLs/example_x2.stl",
      "assetType": "printed_part",
      "quantity": 2,
      "sha256": "..."
    }
  ],
  "bomAuthority": "Voron configurator export",
  "manualAuthority": "official manual PDF",
  "validationStatus": "intake_only"
}
```

## Manufacturing gates

| Gate | Required evidence |
|---|---|
| Source intake | all official assets downloaded, hashed, manifest created |
| BOM lock | model/size/configurator export pinned |
| Print readiness | STL count, material constraints, print settings locked |
| Panel readiness | DXF material/thickness confirmed |
| Electronics readiness | controller wiring guide matches selected board |
| Assembly readiness | BOM/manual/STL/panel consistency checked |
| Calibration readiness | printer.cfg and tuning plan locked |
| Release readiness | first printed cube, resonance, PID, thermal safety, dimensional coupons complete |
