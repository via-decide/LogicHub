# Voron Software and Firmware Stack Analysis

## Core architecture

Voron printers use Klipper as the motion-control architecture. Klipper splits responsibilities:

```text
Host computer
  - parses G-code
  - runs kinematics and configuration
  - handles macros and high-level control
  - communicates with MCU

MCU controller board
  - produces step pulses
  - reads sensors
  - controls heaters/fans/IO
  - executes precise low-level timing
```

## Typical stack

| Layer | Example |
|---|---|
| Web/control UI | Mainsail, Fluidd, KlipperScreen |
| API/service bridge | Moonraker |
| Host motion engine | Klippy |
| Configuration | printer.cfg, macros, board config |
| MCU firmware | Klipper microcontroller firmware |
| Electronics | BTT Octopus, SKR, Manta, Spider, FLY, etc. |
| Motion hardware | steppers, drivers, belts, rails |
| Thermal hardware | hotend heater, bed heater, thermistors, fans |

## Why it is valuable for LogicHub

Voron/Klipper is a strong host/MCU split reference:

- Configuration-as-source controls real hardware behavior.
- Pin mappings are explicit in config.
- Kinematics and mechanics are connected.
- Controller board selection affects wiring and firmware.
- Calibration changes are meaningful engineering state changes.
- A printer can have multiple MCUs and auxiliary boards.

## Validation targets

| Validator | What it checks |
|---|---|
| config parser | printer.cfg syntax and section names |
| pin-map checker | selected controller board vs pins used |
| heater safety checker | min/max temp, sensor type, shutdown behavior |
| macro checker | override/homing routines, unsafe macros |
| mechanical checker | model size vs travel limits |
| calibration checker | PID, input shaper, pressure advance receipt |
| build manifest checker | CAD/BOM/manual/config consistency |

## Input shaping and motion quality

Klipper supports input shaping for resonance compensation. For productized Voron builds, input shaping should produce a signed calibration receipt:

```json
{
  "printer": "Voron Trident 300",
  "axis": "x",
  "accelerometer": "adxl345",
  "measured_frequency_hz": 0,
  "selected_shaper": "pending",
  "max_accel": "pending",
  "receipt_hash": "sha256..."
}
```

## Security and safety notes

A high-performance printer is an electromechanical system with heaters, motors, moving parts, and firmware. Treat firmware and configuration changes as safety-relevant.

Recommended checks:
- Never disable thermal runaway protections.
- Never accept unreviewed firmware/config changes on production machines.
- Keep known-good configuration backups.
- Treat remote UI access as a control-plane risk.
- Log all print jobs and configuration changes.
- For print farms, separate operator UI from administrative firmware update authority.
