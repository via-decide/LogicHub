# Voron Architecture Map

## System block diagram

```mermaid
flowchart TD
    USER[User / Operator]
    SLICER[Slicer]
    UI[Mainsail / Fluidd / Web UI]
    HOST[Klipper host on Raspberry Pi / SBC]
    CFG[printer.cfg + macros]
    MCU[Controller MCU firmware]
    DRIVERS[Stepper drivers]
    THERMAL[Heaters / thermistors / fans]
    SENSORS[Endstops / probe / filament / accelerometer]
    MOTION[CoreXY / CoreXZ motion system]
    TOOLHEAD[Extruder + hotend + cooling]
    FRAME[Frame / rails / belts / panels]
    PART[Printed part]
    RECEIPT[Calibration + print-quality receipt]

    USER --> SLICER
    SLICER --> UI
    UI --> HOST
    HOST --> CFG
    HOST --> MCU
    MCU --> DRIVERS
    MCU --> THERMAL
    MCU --> SENSORS
    DRIVERS --> MOTION
    MOTION --> TOOLHEAD
    FRAME --> MOTION
    TOOLHEAD --> PART
    SENSORS --> HOST
    PART --> RECEIPT
```

## Family comparison

| Family | Kinematics | Bed / gantry model | Primary value | Productization difficulty |
|---|---|---|---|---|
| Voron Zero | CoreXY | Bed moves Z | compact enclosed printer | Medium |
| Voron Trident | CoreXY | fixed gantry + 3-point Z bed | practical serious enclosed printer | Medium-high |
| Voron 2.4 | modified CoreXY | static bed + Z-moving gantry | flagship high-performance architecture | High |
| Switchwire | CoreXZ | bedslinger-style platform | conversion/education/hybrid machine | Medium |
| Legacy | classic RepRap style | rods/bearings heritage | historical/educational | Medium |

## Engineering graph seed

```text
BOM item -> mechanical part -> CAD/STL file -> assembly step
Controller board -> Klipper config -> MCU firmware -> physical pins
Toolhead PCB -> connector -> fan/heater/thermistor/extruder
Frame extrusion -> panel DXF -> enclosure/chamber behavior
Belts/rails/pulleys -> motion quality -> resonance test -> input shaper config
Thermistor/heater -> thermal safety -> PID tune -> print receipt
```

## Critical interfaces

| Interface | Failure impact |
|---|---|
| host ↔ MCU | printer dead, command loss, unsafe stall if not fail-safe |
| MCU ↔ heater | fire/thermal runaway risk |
| MCU ↔ stepper drivers | lost steps, skipped motion, crash |
| thermistor ↔ firmware | runaway, false temperature, failed prints |
| belts ↔ gantry | ringing, dimensional error, layer shift |
| toolhead wiring ↔ carriage | intermittent heater/fan/probe failure |
| BOM ↔ manual ↔ CAD | missing parts, wrong fasteners, build deadlock |
