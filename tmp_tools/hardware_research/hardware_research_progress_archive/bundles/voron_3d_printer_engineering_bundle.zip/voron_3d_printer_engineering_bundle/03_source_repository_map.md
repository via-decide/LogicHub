# Voron Source and Repository Map

## Primary repositories

| Repository | Role | Source-intake priority |
|---|---|---|
| VoronDesign/Voron-2 | Voron 2.4 release assets: CAD/STL/manual/config-style source | High |
| VoronDesign/Voron-Trident | Trident release assets and recommended printer sizes | High |
| VoronDesign/Voron-0 | Voron Zero release assets, compact CoreXY machine | High |
| VoronDesign/Voron-Switchwire | Switchwire release assets | Medium-high |
| VoronDesign/Voron-Stealthburner | StealthBurner toolhead source maintained separately | High |
| VoronDesign/Voron-Hardware | PCBs and auxiliary hardware boards | High |
| VoronDesign/VoronUsers | Community mods and contributed hardware | Medium |

## Documentation authorities

| Source | Authority |
|---|---|
| docs.vorondesign.com | build, sourcing, electrical, mechanical, software documentation |
| vorondesign.com configurator | model-specific generated BOM authority |
| GitHub repositories | CAD/STL/manual/source files |
| Voron forum / Discord | community support, troubleshooting, but not primary manufacturing authority |
| mods.vorondesign.com | user mods and derivative designs |

## Intake policy

1. Start with one model and one release.
2. Download official repository ZIP or tagged release.
3. Generate BOM from the official configurator.
4. Download/copy exact build manual.
5. Download panel DXFs and STL directories.
6. Collect printer.cfg templates and controller wiring guide.
7. Hash every file.
8. Create a canonical asset manifest.
9. Validate manual references against STL/CAD/BOM inventory.
10. Only then start sourcing or fabrication.

## Source-risk classification

| Source type | Trust level | Use |
|---|---:|---|
| official release repository | High | manufacturing source baseline |
| official configurator BOM | High | purchasing authority |
| official docs | High | process authority |
| vendor kit listing | Medium | sourcing comparison only |
| community mod | Medium | optional extension after baseline build |
| forum advice | Low-medium | troubleshooting evidence, not design authority |
| social media post | Low | discovery only |
